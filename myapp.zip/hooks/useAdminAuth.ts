
import { useState, useCallback, useEffect } from 'react';
import { 
  ADMIN_PASSWORD, 
  DEFAULT_ADMIN_USERNAME,
  LOCAL_STORAGE_ADMIN_USERNAME_KEY,
  LOCAL_STORAGE_ADMIN_PASSWORD_KEY 
} from '../constants';

export const useAdminAuth = () => {
  const [adminUsername, setAdminUsername] = useState<string>(DEFAULT_ADMIN_USERNAME);
  const [adminPassword, setAdminPassword] = useState<string>(ADMIN_PASSWORD);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState<boolean>(true);

  useEffect(() => {
    setIsLoadingAuth(true);
    try {
      const storedUsername = localStorage.getItem(LOCAL_STORAGE_ADMIN_USERNAME_KEY);
      const storedPassword = localStorage.getItem(LOCAL_STORAGE_ADMIN_PASSWORD_KEY);

      if (storedUsername) {
        setAdminUsername(storedUsername);
      } else {
        
        localStorage.setItem(LOCAL_STORAGE_ADMIN_USERNAME_KEY, DEFAULT_ADMIN_USERNAME);
      }

      if (storedPassword) {
        setAdminPassword(storedPassword);
      } else {
        
        localStorage.setItem(LOCAL_STORAGE_ADMIN_PASSWORD_KEY, ADMIN_PASSWORD);
      }
    } catch (e) {
      console.error("Error loading admin credentials from localStorage:", e);
      setAuthError("خطا در بارگذاری مشخصات ورود ادمین.");
      
      setAdminUsername(DEFAULT_ADMIN_USERNAME);
      setAdminPassword(ADMIN_PASSWORD);
    }
    setIsLoadingAuth(false);
  }, []);

  const login = useCallback((usernameInput: string, passwordInput: string): boolean => {
    setAuthError(null);
    
    if (usernameInput.toLowerCase() === adminUsername.toLowerCase() && passwordInput === adminPassword) {
      setIsAdminLoggedIn(true);
      return true;
    }
    
    if (!usernameInput.trim() && passwordInput === adminPassword) {
        setIsAdminLoggedIn(true);
        return true;
    }
    setAuthError('نام کاربری یا رمز عبور ادمین نامعتبر است.');
    return false;
  }, [adminUsername, adminPassword]);

  const logout = useCallback(() => {
    setIsAdminLoggedIn(false);
    setAuthError(null);
  }, []);

  const changeCredentials = useCallback((
    currentUsernameInput: string, 
    currentPasswordInput: string, 
    newUsernameInput: string, 
    newPasswordInput: string
  ): boolean => {
    setAuthError(null);
    if (currentUsernameInput.toLowerCase() !== adminUsername.toLowerCase() || currentPasswordInput !== adminPassword) {
      setAuthError('نام کاربری یا رمز عبور فعلی صحیح نیست.');
      return false;
    }
    if (!newUsernameInput.trim() || !newPasswordInput.trim()) {
      setAuthError('نام کاربری و رمز عبور جدید نمی‌توانند خالی باشند.');
      return false;
    }

    try {
      localStorage.setItem(LOCAL_STORAGE_ADMIN_USERNAME_KEY, newUsernameInput.trim());
      localStorage.setItem(LOCAL_STORAGE_ADMIN_PASSWORD_KEY, newPasswordInput);
      setAdminUsername(newUsernameInput.trim());
      setAdminPassword(newPasswordInput);
      
      return true;
    } catch (e) {
      console.error("Error saving new admin credentials to localStorage:", e);
      setAuthError("خطا در ذخیره‌سازی مشخصات جدید.");
      return false;
    }
  }, [adminUsername, adminPassword]);
  
  const updateSetAuthError = useCallback((message: string | null) => {
    setAuthError(message);
  }, []);

  return {
    isAdminLoggedIn,
    adminUsername, 
    isLoadingAuth,
    authError,
    login,
    logout,
    changeCredentials,
    setAuthError: updateSetAuthError,
  };
};
