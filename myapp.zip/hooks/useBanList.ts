
import { useState, useCallback, useEffect } from 'react';
import type { BannedUser } from '../types';
import { LOCAL_STORAGE_BAN_LIST_KEY } from '../constants';

export const useBanList = () => {
  const [bannedUsers, setBannedUsers] = useState<BannedUser[]>([]);
  const [isLoadingBanList, setIsLoadingBanList] = useState<boolean>(true);
  const [banListError, setBanListError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingBanList(true);
    try {
      const savedData = localStorage.getItem(LOCAL_STORAGE_BAN_LIST_KEY);
      if (savedData) {
        const parsedData: BannedUser[] = JSON.parse(savedData);
        if (Array.isArray(parsedData) && parsedData.every(u => u.platoUsername && typeof u.timestamp === 'number')) {
          setBannedUsers(parsedData.sort((a, b) => b.timestamp - a.timestamp));
        } else {
          localStorage.removeItem(LOCAL_STORAGE_BAN_LIST_KEY);
        }
      }
    } catch (e) {
      console.error("Failed to load ban list from local storage:", e);
      setBanListError("خطا در بارگذاری لیست مسدودی.");
      localStorage.removeItem(LOCAL_STORAGE_BAN_LIST_KEY);
    }
    setIsLoadingBanList(false);
  }, []);

  const saveBanList = useCallback((updatedList: BannedUser[]) => {
    const sortedList = updatedList.sort((a, b) => b.timestamp - a.timestamp);
    setBannedUsers(sortedList);
    localStorage.setItem(LOCAL_STORAGE_BAN_LIST_KEY, JSON.stringify(sortedList));
  }, []);

  const addBannedUser = useCallback((platoUsername: string, adminUsername?: string, reason?: string): boolean => {
    setBanListError(null);
    if (!platoUsername.trim()) {
      setBanListError("نام کاربری پلاتو برای مسدود کردن نمی‌تواند خالی باشد.");
      return false;
    }
    if (bannedUsers.some(u => u.platoUsername.toLowerCase() === platoUsername.trim().toLowerCase())) {
      setBanListError("این کاربر قبلاً به لیست مسدودی اضافه شده است.");
      return false;
    }
    const newBannedEntry: BannedUser = {
      platoUsername: platoUsername.trim(),
      timestamp: Date.now(),
      bannedBy: adminUsername,
      reason: reason?.trim(),
    };
    saveBanList([newBannedEntry, ...bannedUsers]);
    return true;
  }, [bannedUsers, saveBanList]);

  const removeBannedUser = useCallback((platoUsername: string): boolean => {
    setBanListError(null);
    const updatedList = bannedUsers.filter(u => u.platoUsername.toLowerCase() !== platoUsername.toLowerCase());
    if (updatedList.length === bannedUsers.length) {
      setBanListError("کاربر مورد نظر در لیست مسدودی یافت نشد.");
      return false;
    }
    saveBanList(updatedList);
    return true;
  }, [bannedUsers, saveBanList]);

  const isUserBanned = useCallback((platoUsername: string): boolean => {
    return bannedUsers.some(u => u.platoUsername.toLowerCase() === platoUsername.toLowerCase());
  }, [bannedUsers]);

  const getBanList = useCallback((): BannedUser[] => {
    return bannedUsers;
  }, [bannedUsers]);
  
  const updateSetBanListError = useCallback((message: string | null) => {
    setBanListError(message);
  }, []);


  return {
    bannedUsers,
    isLoadingBanList,
    banListError,
    addBannedUser,
    removeBannedUser,
    isUserBanned,
    getBanList,
    setBanListError: updateSetBanListError,
  };
};
