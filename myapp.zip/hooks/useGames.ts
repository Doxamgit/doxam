
import { useState, useCallback, useEffect } from 'react';
import type { Game } from '../types';
import { LOCAL_STORAGE_GAMES_KEY, DEFAULT_GAMES_LIST } from '../constants';

export const useGames = () => {
  const [games, setGames] = useState<Game[]>([]);
  const [isLoadingGames, setIsLoadingGames] = useState<boolean>(true);
  const [gamesError, setGamesError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingGames(true);
    let loadedGames: Game[] = [];
    try {
      const savedGamesData = localStorage.getItem(LOCAL_STORAGE_GAMES_KEY);
      if (savedGamesData) {
        const parsedGames: Game[] = JSON.parse(savedGamesData);
        if (Array.isArray(parsedGames) && parsedGames.every(game => game.id && game.name)) {
          loadedGames = parsedGames;
        } else {
          // Invalid data, will proceed to default initialization if loadedGames is empty
          localStorage.removeItem(LOCAL_STORAGE_GAMES_KEY);
        }
      }

      if (loadedGames.length === 0) {
        // Initialize with default games if local storage was empty or invalid
        loadedGames = DEFAULT_GAMES_LIST.map((name, index) => ({
          id: `default-game-${index}-${Date.now()}`,
          name: name,
        }));
        localStorage.setItem(LOCAL_STORAGE_GAMES_KEY, JSON.stringify(loadedGames));
      }
      setGames(loadedGames.sort((a, b) => a.name.localeCompare(b.name, 'fa')));

    } catch (e) {
      console.error("Failed to load games from local storage:", e);
      setGamesError("خطا در بارگذاری لیست بازی‌ها.");
      // Fallback to default games if error during loading/parsing
      const defaultGamesOnInitError = DEFAULT_GAMES_LIST.map((name, index) => ({
        id: `default-game-error-${index}-${Date.now()}`,
        name: name,
      }));
      setGames(defaultGamesOnInitError.sort((a, b) => a.name.localeCompare(b.name, 'fa')));
      localStorage.setItem(LOCAL_STORAGE_GAMES_KEY, JSON.stringify(defaultGamesOnInitError));
    }
    setIsLoadingGames(false);
  }, []);

  const saveGamesToStorage = useCallback((updatedGames: Game[]) => {
    const sortedGames = updatedGames.sort((a, b) => a.name.localeCompare(b.name, 'fa'));
    setGames(sortedGames);
    localStorage.setItem(LOCAL_STORAGE_GAMES_KEY, JSON.stringify(sortedGames));
  }, []);

  const addGame = useCallback((name: string): Game | null => {
    setGamesError(null);
    if (!name.trim()) {
      setGamesError("نام بازی نمی‌تواند خالی باشد.");
      return null;
    }
    if (games.some(game => game.name.toLowerCase() === name.trim().toLowerCase())) {
      setGamesError("بازی با این نام قبلاً اضافه شده است.");
      return null;
    }
    const newGame: Game = {
      id: `game-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
    };
    saveGamesToStorage([newGame, ...games]);
    return newGame;
  }, [games, saveGamesToStorage]);

  const updateGameName = useCallback((id: string, newName: string): Game | null => {
    setGamesError(null);
    if (!newName.trim()) {
      setGamesError("نام جدید بازی نمی‌تواند خالی باشد.");
      return null;
    }
    const gameIndex = games.findIndex(game => game.id === id);
    if (gameIndex === -1) {
      setGamesError("بازی مورد نظر برای ویرایش یافت نشد.");
      return null;
    }
    if (games.some(game => game.id !== id && game.name.toLowerCase() === newName.trim().toLowerCase())) {
      setGamesError("بازی دیگری با این نام جدید وجود دارد.");
      return null;
    }

    const updatedGames = [...games];
    updatedGames[gameIndex] = { ...updatedGames[gameIndex], name: newName.trim() };
    saveGamesToStorage(updatedGames);
    return updatedGames[gameIndex];
  }, [games, saveGamesToStorage]);

  const deleteGame = useCallback((id: string): boolean => {
    setGamesError(null);
    const updatedGames = games.filter(game => game.id !== id);
    if (updatedGames.length === games.length) {
      setGamesError("بازی مورد نظر برای حذف یافت نشد.");
      return false;
    }
    saveGamesToStorage(updatedGames);
    return true;
  }, [games, saveGamesToStorage]);
  
  const getGames = useCallback((): Game[] => {
    return games;
  }, [games]);

  const updateSetGamesError = useCallback((message: string | null) => {
    setGamesError(message);
  }, []);


  return {
    games,
    isLoadingGames,
    gamesError,
    addGame,
    updateGameName,
    deleteGame,
    getGames,
    setGamesError: updateSetGamesError,
  };
};
