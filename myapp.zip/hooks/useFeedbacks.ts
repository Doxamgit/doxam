
import { useState, useCallback, useEffect } from 'react';
import type { FeedbackEntry } from '../types';
import { LOCAL_STORAGE_FEEDBACKS_KEY } from '../constants';

export const useFeedbacks = () => {
  const [feedbacks, setFeedbacks] = useState<FeedbackEntry[]>([]);
  const [isLoadingFeedbacks, setIsLoadingFeedbacks] = useState<boolean>(true);
  const [feedbacksError, setFeedbacksError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingFeedbacks(true);
    try {
      const savedData = localStorage.getItem(LOCAL_STORAGE_FEEDBACKS_KEY);
      if (savedData) {
        const parsedData: FeedbackEntry[] = JSON.parse(savedData);
        if (Array.isArray(parsedData) && parsedData.every(fb => fb.id && fb.platoId && fb.userCode && fb.message && typeof fb.timestamp === 'number')) {
          setFeedbacks(parsedData.sort((a, b) => b.timestamp - a.timestamp));
        } else {
          console.warn("Invalid feedback data found in localStorage. Clearing feedbacks.");
          localStorage.removeItem(LOCAL_STORAGE_FEEDBACKS_KEY);
        }
      }
    } catch (e) {
      console.error("Failed to load feedbacks from local storage:", e);
      setFeedbacksError("خطا در بارگذاری بازخوردها.");
      localStorage.removeItem(LOCAL_STORAGE_FEEDBACKS_KEY);
    }
    setIsLoadingFeedbacks(false);
  }, []);

  const saveFeedbacks = useCallback((updatedFeedbacks: FeedbackEntry[]) => {
    const sortedFeedbacks = updatedFeedbacks.sort((a, b) => b.timestamp - a.timestamp);
    setFeedbacks(sortedFeedbacks);
    localStorage.setItem(LOCAL_STORAGE_FEEDBACKS_KEY, JSON.stringify(sortedFeedbacks));
  }, []);

  const addFeedback = useCallback((platoId: string, userCode: string, message: string): FeedbackEntry | null => {
    setFeedbacksError(null);
    if (!platoId.trim() || !userCode.trim() || !message.trim()) {
      setFeedbacksError("اطلاعات بازخورد ناقص است.");
      return null;
    }
    const newFeedback: FeedbackEntry = {
      id: `feedback-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      platoId: platoId.trim(),
      userCode: userCode.trim(),
      message: message.trim(),
      timestamp: Date.now(),
      isRead: false,
      isArchived: false,
    };
    saveFeedbacks([newFeedback, ...feedbacks]);
    return newFeedback;
  }, [feedbacks, saveFeedbacks]);

  const toggleReadStatus = useCallback((id: string) => {
    setFeedbacksError(null);
    const updated = feedbacks.map(fb => fb.id === id ? { ...fb, isRead: !fb.isRead } : fb);
    saveFeedbacks(updated);
  }, [feedbacks, saveFeedbacks]);

  const toggleArchiveStatus = useCallback((id: string) => {
    setFeedbacksError(null);
    const updated = feedbacks.map(fb => fb.id === id ? { ...fb, isArchived: !fb.isArchived } : fb);
    saveFeedbacks(updated);
  }, [feedbacks, saveFeedbacks]);

  const deleteFeedbackEntry = useCallback((id: string): boolean => {
    setFeedbacksError(null);
    const updated = feedbacks.filter(fb => fb.id !== id);
    if (updated.length === feedbacks.length) {
      setFeedbacksError("بازخورد مورد نظر برای حذف یافت نشد.");
      return false;
    }
    saveFeedbacks(updated);
    return true;
  }, [feedbacks, saveFeedbacks]);

  const updateSetFeedbacksError = useCallback((message: string | null) => {
    setFeedbacksError(message);
  }, []);

  return {
    feedbacks,
    isLoadingFeedbacks,
    feedbacksError,
    addFeedback,
    toggleReadStatus,
    toggleArchiveStatus,
    deleteFeedbackEntry,
    setFeedbacksError: updateSetFeedbacksError,
  };
};
