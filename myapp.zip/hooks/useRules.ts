
import { useState, useCallback, useEffect } from 'react';
import { LOCAL_STORAGE_RULES_KEY } from '../constants';

export const useRules = () => {
  const [rulesContent, setRulesContent] = useState<string>('');
  const [isLoadingRules, setIsLoadingRules] = useState<boolean>(true);
  const [rulesError, setRulesError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingRules(true);
    try {
      const savedRules = localStorage.getItem(LOCAL_STORAGE_RULES_KEY);
      if (savedRules !== null) { 
        setRulesContent(savedRules);
      }
    } catch (e) {
      console.error("Failed to load rules from local storage:", e);
      setRulesError("خطا در بارگذاری قوانین.");
    }
    setIsLoadingRules(false);
  }, []);

  const saveRulesContent = useCallback((newContent: string) => {
    setRulesError(null);
    try {
      setRulesContent(newContent);
      localStorage.setItem(LOCAL_STORAGE_RULES_KEY, newContent);
      return true;
    } catch (e) {
      console.error("Failed to save rules to local storage:", e);
      setRulesError("خطا در ذخیره‌سازی قوانین.");
      return false;
    }
  }, []);
  
  const updateSetRulesError = useCallback((message: string | null) => {
    setRulesError(message);
  }, []);

  return {
    rulesContent,
    isLoadingRules,
    rulesError,
    saveRulesContent,
    setRulesError: updateSetRulesError, 
  };
};
