
import { useState, useCallback, useEffect } from 'react';
import type { AkoAdmin, AkoAdminRole, Gender } from '../types';
import { LOCAL_STORAGE_AKO_ADMINS_KEY } from '../constants';

const calculateAverageRating = (scores: (number | undefined)[]): number => {
  const validScores = scores.filter(score => typeof score === 'number') as number[];
  if (validScores.length === 0) return 0;
  const sum = validScores.reduce((acc, score) => acc + score, 0);
  return parseFloat((sum / validScores.length).toFixed(1)); 
};

const generateUserCode = (): string => {
  return Math.floor(10000 + Math.random() * 90000).toString(); 
};

export const useAkoAdmins = () => {
  const [akoAdmins, setAkoAdmins] = useState<AkoAdmin[]>([]);
  const [isLoadingAkoAdmins, setIsLoadingAkoAdmins] = useState<boolean>(true);
  const [akoAdminsError, setAkoAdminsError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingAkoAdmins(true);
    try {
      const savedData = localStorage.getItem(LOCAL_STORAGE_AKO_ADMINS_KEY);
      if (savedData) {
        const parsedData: AkoAdmin[] = JSON.parse(savedData);
        if (Array.isArray(parsedData) && parsedData.every(item => item.id && item.name && item.role)) {
          const migratedData = parsedData.map(admin => {
            const migratedAdmin: AkoAdmin = {
              id: admin.id,
              name: admin.name, 
              role: admin.role,
              platoUsername: admin.platoUsername,
              age: admin.age,
              gender: admin.gender,
              userCode: admin.userCode, 
            };
            if (admin.role === 'admin' || admin.role === 'moderator') {
              migratedAdmin.professionalismScore = admin.professionalismScore ?? 0;
              migratedAdmin.activityAvailabilityScore = admin.activityAvailabilityScore ?? 0;
              migratedAdmin.problemSolvingScore = admin.problemSolvingScore ?? 0;
              migratedAdmin.averageRating = admin.averageRating ?? calculateAverageRating([migratedAdmin.professionalismScore, migratedAdmin.activityAvailabilityScore, migratedAdmin.problemSolvingScore]);
            } else if (admin.role === 'user') {
              migratedAdmin.ruleAdherenceScore = admin.ruleAdherenceScore ?? 0;
              migratedAdmin.respectScore = admin.respectScore ?? 0;
              migratedAdmin.contentAccuracyScore = admin.contentAccuracyScore ?? 0;
            }
            return migratedAdmin;
          });
          setAkoAdmins(migratedData);
        } else {
          localStorage.removeItem(LOCAL_STORAGE_AKO_ADMINS_KEY);
        }
      }
    } catch (e) {
      console.error("Failed to load Ako Admins from local storage:", e);
      setAkoAdminsError("خطا در بارگذاری لیست مدیران آکو.");
      localStorage.removeItem(LOCAL_STORAGE_AKO_ADMINS_KEY);
    }
    setIsLoadingAkoAdmins(false);
  }, []);

  const saveAkoAdmins = useCallback((updatedAdmins: AkoAdmin[]) => {
    const sortedAdmins = updatedAdmins.sort((a, b) => {
        const roleOrder: Record<AkoAdminRole, number> = { owner: 0, admin: 1, moderator: 2, user: 3 };
        if (roleOrder[a.role] !== roleOrder[b.role]) {
            return roleOrder[a.role] - roleOrder[b.role];
        }
        return a.name.localeCompare(b.name);
    });
    setAkoAdmins(sortedAdmins);
    localStorage.setItem(LOCAL_STORAGE_AKO_ADMINS_KEY, JSON.stringify(sortedAdmins));
  }, []);

  const addAkoAdmin = useCallback((
    name: string, 
    role: AkoAdminRole,
    details?: {
      platoUsername?: string;
      age?: number;
      gender?: Gender;
    }
  ): AkoAdmin | null => {
    setAkoAdminsError(null);
    if (!name.trim()) {
      setAkoAdminsError("نام واقعی نمی‌تواند خالی باشد.");
      return null;
    }
    if (role === 'user' && details?.platoUsername && !details.platoUsername.trim()) {
      setAkoAdminsError("نام کاربری پلاتو برای کاربر نمی‌تواند خالی باشد.");
      return null;
    }
    if (role === 'user' && details?.platoUsername) {
        const existingUser = akoAdmins.find(admin => admin.role === 'user' && admin.platoUsername === details.platoUsername);
        if (existingUser) {
            setAkoAdminsError(`کاربری با نام کاربری پلاتو '${details.platoUsername}' قبلا ثبت نام کرده است.`);
            return null;
        }
    }

    const newAdmin: AkoAdmin = {
      id: `ako-admin-${Date.now()}`,
      name: name.trim(),
      role,
      platoUsername: details?.platoUsername?.trim(),
      age: details?.age,
      gender: details?.gender,
      userCode: role === 'user' ? generateUserCode() : undefined,
    };

    if (role === 'admin' || role === 'moderator') {
      newAdmin.professionalismScore = 0;
      newAdmin.activityAvailabilityScore = 0;
      newAdmin.problemSolvingScore = 0;
      newAdmin.averageRating = 0;
    } else if (role === 'user') {
      newAdmin.ruleAdherenceScore = 0;
      newAdmin.respectScore = 0;
      newAdmin.contentAccuracyScore = 0;
    }

    saveAkoAdmins([newAdmin, ...akoAdmins]);
    return newAdmin;
  }, [akoAdmins, saveAkoAdmins]);

  const updateAkoAdmin = useCallback((id: string, updatedData: Partial<AkoAdmin>): AkoAdmin | null => {
    setAkoAdminsError(null);
    const adminIndex = akoAdmins.findIndex(admin => admin.id === id);
    if (adminIndex === -1) {
      setAkoAdminsError("مورد نظر یافت نشد.");
      return null;
    }

    const updatedAdmins = [...akoAdmins];
    const existingAdmin = updatedAdmins[adminIndex];
    
    if (updatedData.name && !updatedData.name.trim()) {
        setAkoAdminsError("نام واقعی نمی‌تواند خالی باشد.");
        return null;
    }
    if (updatedData.role === 'user' && updatedData.platoUsername && !updatedData.platoUsername.trim()) {
        setAkoAdminsError("نام کاربری پلاتو برای کاربر نمی‌تواند خالی باشد.");
        return null;
    }
    if (updatedData.role === 'user' && updatedData.platoUsername && updatedData.platoUsername !== existingAdmin.platoUsername) {
        const duplicateExists = akoAdmins.some(admin => admin.id !== id && admin.role === 'user' && admin.platoUsername === updatedData.platoUsername);
        if (duplicateExists) {
            setAkoAdminsError(`کاربر دیگری با نام کاربری پلاتو '${updatedData.platoUsername}' وجود دارد.`);
            return null;
        }
    }

    let finalUserCode = existingAdmin.userCode;
    if ((updatedData.role === 'user' || (existingAdmin.role === 'user' && !updatedData.role)) && !existingAdmin.userCode) {
        finalUserCode = generateUserCode();
    } else if (updatedData.role && updatedData.role !== 'user') {
        finalUserCode = undefined;
    }

    const newAdminState: AkoAdmin = {
      ...existingAdmin,
      name: updatedData.name?.trim() ?? existingAdmin.name,
      role: updatedData.role ?? existingAdmin.role,
      platoUsername: updatedData.platoUsername?.trim() ?? existingAdmin.platoUsername,
      age: updatedData.age ?? existingAdmin.age,
      gender: updatedData.gender ?? existingAdmin.gender,
      userCode: finalUserCode,
    };

    if (newAdminState.role === 'admin' || newAdminState.role === 'moderator') {
      newAdminState.professionalismScore = updatedData.professionalismScore ?? existingAdmin.professionalismScore ?? 0;
      newAdminState.activityAvailabilityScore = updatedData.activityAvailabilityScore ?? existingAdmin.activityAvailabilityScore ?? 0;
      newAdminState.problemSolvingScore = updatedData.problemSolvingScore ?? existingAdmin.problemSolvingScore ?? 0;
      newAdminState.averageRating = calculateAverageRating([
        newAdminState.professionalismScore,
        newAdminState.activityAvailabilityScore,
        newAdminState.problemSolvingScore
      ]);
      newAdminState.ruleAdherenceScore = undefined;
      newAdminState.respectScore = undefined;
      newAdminState.contentAccuracyScore = undefined;
    } else if (newAdminState.role === 'user') {
      newAdminState.ruleAdherenceScore = updatedData.ruleAdherenceScore ?? existingAdmin.ruleAdherenceScore ?? 0;
      newAdminState.respectScore = updatedData.respectScore ?? existingAdmin.respectScore ?? 0;
      newAdminState.contentAccuracyScore = updatedData.contentAccuracyScore ?? existingAdmin.contentAccuracyScore ?? 0;
      newAdminState.professionalismScore = undefined;
      newAdminState.activityAvailabilityScore = undefined;
      newAdminState.problemSolvingScore = undefined;
      newAdminState.averageRating = undefined;
    } else {
      newAdminState.professionalismScore = undefined;
      newAdminState.activityAvailabilityScore = undefined;
      newAdminState.problemSolvingScore = undefined;
      newAdminState.averageRating = undefined;
      newAdminState.ruleAdherenceScore = undefined;
      newAdminState.respectScore = undefined;
      newAdminState.contentAccuracyScore = undefined;
    }
    
    updatedAdmins[adminIndex] = newAdminState;
    saveAkoAdmins(updatedAdmins);
    return newAdminState;
  }, [akoAdmins, saveAkoAdmins]);
  
  const deleteAkoAdmin = useCallback((id: string): boolean => {
    setAkoAdminsError(null);
    const updatedAdmins = akoAdmins.filter(admin => admin.id !== id);
    if (updatedAdmins.length === akoAdmins.length) {
      setAkoAdminsError("مورد نظر برای حذف یافت نشد.");
      return false;
    }
    saveAkoAdmins(updatedAdmins);
    return true;
  }, [akoAdmins, saveAkoAdmins]);

  const updateSetAkoAdminsError = useCallback((message: string | null) => {
    setAkoAdminsError(message);
  }, []);

  const getAkoUserByPlatoUsername = useCallback((platoUsername: string): AkoAdmin | undefined => {
    return akoAdmins.find(admin => admin.role === 'user' && admin.platoUsername?.toLowerCase() === platoUsername.toLowerCase());
  }, [akoAdmins]);

  const verifyUserByPlatoAndCode = useCallback((platoUsername: string, userCode: string): boolean => {
    const user = akoAdmins.find(
      admin => admin.role === 'user' &&
               admin.platoUsername?.toLowerCase() === platoUsername.toLowerCase() &&
               admin.userCode === userCode
    );
    return !!user;
  }, [akoAdmins]);

  return {
    akoAdmins,
    isLoadingAkoAdmins,
    akoAdminsError,
    addAkoAdmin,
    updateAkoAdmin,
    deleteAkoAdmin,
    setAkoAdminsError: updateSetAkoAdminsError,
    getAkoUserByPlatoUsername,
    verifyUserByPlatoAndCode,
  };
};
