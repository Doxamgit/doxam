
import { useState, useCallback, useEffect } from 'react';
import type { Tournament, ArchivedTournament, TournamentType, Participant, Player } from '../types';
import { LOCAL_STORAGE_HISTORY_KEY } from '../constants';

export const useTournamentHistory = () => {
  const [archivedTournaments, setArchivedTournaments] = useState<ArchivedTournament[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(true);
  const [historyError, setHistoryError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingHistory(true);
    try {
      const savedHistoryData = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
      if (savedHistoryData) {
        const parsedItems: any[] = JSON.parse(savedHistoryData);
        
        if (Array.isArray(parsedItems) && parsedItems.every(t => t.id && t.customName && t.status === 'completed')) {
          const historyWithCorrectTypes: ArchivedTournament[] = parsedItems.map((t: any): ArchivedTournament | null => {
            // If it's an old league tournament, skip it
            if (t.tournamentType === 'league') {
              // console.warn(`Skipping archived league tournament (ID: ${t.id}) as they are no longer supported.`);
              return null; // Skip league tournaments
            }
             // Ensure tournamentType is valid, otherwise default or skip
            if (t.tournamentType !== 'individual' && t.tournamentType !== 'team') {
                // console.warn(`Archived tournament (ID: ${t.id}) has invalid type "${t.tournamentType}". Skipping.`);
                return null; 
            }


            let participants: Participant[] = [];
            let finalWinnerObj: Participant | null = null;
            
            participants = (t.participants || []).map((p_any: any): Participant => ({
              id: p_any.id,
              name: p_any.name,
              members: p_any.members ? p_any.members.map((m: any) => ({ id: m.id, name: m.name })) : undefined,
            }));
            if (t.finalWinner) {
                finalWinnerObj = {
                    id: t.finalWinner.id,
                    name: t.finalWinner.name,
                    members: t.finalWinner.members ? t.finalWinner.members.map((m: any) => ({ id: m.id, name: m.name })) : undefined,
                };
            }

            return {
              id: t.id,
              customName: t.customName,
              eventDateTime: t.eventDateTime,
              participants: participants, 
              initialParticipantCount: t.initialParticipantCount, 
              rounds: t.rounds, 
              finalWinner: finalWinnerObj, 
              status: 'completed',
              completedTimestamp: t.completedTimestamp,
              participantEntryMode: 'manual', 
              tournamentType: t.tournamentType as TournamentType, // Cast as it's now validated
            };
          }).filter(Boolean) as ArchivedTournament[]; // Filter out nulls (skipped league or invalid tournaments)
          setArchivedTournaments(historyWithCorrectTypes.sort((a, b) => b.completedTimestamp - a.completedTimestamp));
        } else {
          console.warn("Invalid tournament history data found in localStorage. Clearing history.");
          localStorage.removeItem(LOCAL_STORAGE_HISTORY_KEY);
        }
      }
    } catch (e) {
      console.error("Failed to load tournament history from local storage:", e);
      setHistoryError("خطا در بارگذاری تاریخچه تورنومنت‌ها.");
      localStorage.removeItem(LOCAL_STORAGE_HISTORY_KEY); 
    }
    setIsLoadingHistory(false);
  }, []);

  const saveHistory = useCallback((updatedHistory: ArchivedTournament[]) => {
    const sortedHistory = updatedHistory.sort((a,b) => b.completedTimestamp - a.completedTimestamp);
    setArchivedTournaments(sortedHistory);
    localStorage.setItem(LOCAL_STORAGE_HISTORY_KEY, JSON.stringify(sortedHistory));
  }, []);

  const addTournamentToHistory = useCallback((tournamentToAdd: Tournament) => {
    setHistoryError(null);
    if (tournamentToAdd.status !== 'awaiting_archival' && tournamentToAdd.status !== 'completed') {
      setHistoryError("فقط تورنومنت‌های تکمیل شده می‌توانند به تاریخچه اضافه شوند.");
      console.error("Attempted to archive a non-completed tournament:", tournamentToAdd);
      return false;
    }
    
    // 'league' type is already excluded by TournamentType definition for tournamentToAdd
    if (!tournamentToAdd.finalWinner) {
        setHistoryError("تورنومنت (حذفی) برنده نهایی ندارد و نمی‌تواند آرشیو شود.");
        console.error("Attempted to archive bracket tournament without a final winner:", tournamentToAdd);
        return false;
    }

    const newArchivedTournament: ArchivedTournament = {
      id: tournamentToAdd.id,
      customName: tournamentToAdd.customName,
      eventDateTime: tournamentToAdd.eventDateTime,
      participants: tournamentToAdd.participants.map(p => ({ 
        id: p.id,
        name: p.name,
        members: p.members ? p.members.map(m => ({id: m.id, name: m.name})) : undefined
      })), 
      initialParticipantCount: tournamentToAdd.initialParticipantCount, 
      rounds: tournamentToAdd.rounds, 
      finalWinner: tournamentToAdd.finalWinner ? { 
        id: tournamentToAdd.finalWinner.id,
        name: tournamentToAdd.finalWinner.name,
        members: tournamentToAdd.finalWinner.members ? tournamentToAdd.finalWinner.members.map(m => ({id: m.id, name: m.name})) : undefined
      } : null, 
      status: 'completed',
      completedTimestamp: Date.now(),
      participantEntryMode: 'manual',
      tournamentType: tournamentToAdd.tournamentType, 
    };

    const existingIndex = archivedTournaments.findIndex(t => t.id === newArchivedTournament.id);
    let updatedHistory;
    if (existingIndex > -1) {
      updatedHistory = [...archivedTournaments];
      updatedHistory[existingIndex] = newArchivedTournament;
    } else {
      updatedHistory = [newArchivedTournament, ...archivedTournaments];
    }
    
    saveHistory(updatedHistory);
    return true;
  }, [archivedTournaments, saveHistory]);

  const deleteTournamentFromHistory = useCallback((tournamentId: string) => {
    setHistoryError(null);
    const updatedHistory = archivedTournaments.filter(t => t.id !== tournamentId);
    if (updatedHistory.length === archivedTournaments.length) {
      setHistoryError("تورنومنتی با این شناسه برای حذف در تاریخچه یافت نشد.");
      return;
    }
    saveHistory(updatedHistory);
  }, [archivedTournaments, saveHistory]);

  const updateSetHistoryError = useCallback((message: string | null) => {
    setHistoryError(message);
  }, []);

  return {
    archivedTournaments,
    isLoadingHistory,
    historyError,
    addTournamentToHistory,
    deleteTournamentFromHistory,
    setHistoryError: updateSetHistoryError,
  };
};
