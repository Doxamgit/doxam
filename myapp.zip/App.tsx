
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useTournament } from './hooks/useTournament';
import { useNews } from './hooks/useNews';
import { useTournamentHistory } from './hooks/useTournamentHistory';
import { useRules } from './hooks/useRules';
import { useAdminAuth } from './hooks/useAdminAuth';
import { useAkoAdmins } from './hooks/useAkoAdmins';
import { useFeedbacks } from './hooks/useFeedbacks';
import { useBanList } from './hooks/useBanList';
import { useGames } from './hooks/useGames'; // Import useGames hook

import type { Participant, Tournament, AkoAdmin, AkoAdminRole, Gender, TournamentType, Game } from './types';
import { ViewState } from './types';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import TournamentSetup from './components/TournamentSetup';
// import LeagueTournamentSetup from './components/LeagueTournamentSetup'; // Removed
import AdminBanListPanel from './components/AdminBanListPanel';
import AdminGamesPanel from './components/AdminGamesPanel'; // Import AdminGamesPanel

import BracketDisplay from './components/BracketDisplay';
import Header from './components/Header';
import Footer from './components/Footer';
import Button from './components/Button';
import AdminNewsPanel from './components/AdminNewsPanel';
import NewsDisplaySection from './components/NewsDisplaySection';
import TournamentHistoryPanel from './components/TournamentHistoryPanel';
import LoadingScreen from './components/LoadingScreen';
import AdminRulesPanel from './components/AdminRulesPanel';
import RulesDisplaySection from './components/RulesDisplaySection';
import AdminCredentialsPanel from './components/AdminCredentialsPanel';
import AdminAkoAdminsPanel from './components/AdminAkoAdminsPanel';
import AkoAdminsDisplaySection from './components/AkoAdminsDisplaySection';
import UserSelfProfileForm from './components/UserSelfProfileForm';
import { APP_TITLE } from './constants';
import UserPanelSection from './components/UserPanelSection';
import UserProfileIcon from './components/UserOutlineIcon';
import NewspaperIcon from './components/NewspaperIcon';
import ScaleIcon from './components/ScaleIcon';
import UsersGroupIcon from './components/UsersGroupIcon';
import PulseIcon from './components/PulseIcon';
import TrophyIcon from './components/TrophyIcon';
import ProfileModal from './components/ProfileModal';
import UserCodeModal from './components/UserCodeModal';
import ArrowLeftIcon from './components/ArrowLeftIcon';
import FeedbackForm from './components/FeedbackForm';
import AdminFeedbacksPanel from './components/AdminFeedbacksPanel';
import ChevronDownIcon from './components/ChevronDownIcon';

import TournamentTypeSelectionModal from './components/TournamentTypeSelectionModal';


const App: React.FC = () => {
  const [appInitialLoading, setAppInitialLoading] = useState(true);
  const [loadingScreenFadingOut, setLoadingScreenFadingOut] = useState(false);
  const [view, setView] = useState<ViewState>(ViewState.HOME);
  const [heroScrolled, setHeroScrolled] = useState(false);

  const [userProfileFormError, setUserProfileFormError] = useState<string | null>(null);
  const [userProfileFormSuccess, setUserProfileFormSuccess] = useState<string | null>(null);
  const [isProfileFormLoading, setIsProfileFormLoading] = useState<boolean>(false);
  const [currentUserProfile, setCurrentUserProfile] = useState<AkoAdmin | undefined>(undefined);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const [showUserCodeModal, setShowUserCodeModal] = useState(false);
  const [currentUserCode, setCurrentUserCode] = useState<string | null>(null);

  const [feedbackPlatoId, setFeedbackPlatoId] = useState('');
  const [feedbackUserCode, setFeedbackUserCode] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [isFeedbackSubmitting, setIsFeedbackSubmitting] = useState(false);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [feedbackSuccess, setFeedbackSuccess] = useState<string | null>(null);

  const [isTournamentTypeModalOpen, setIsTournamentTypeModalOpen] = useState(false);
  const [prospectiveTournamentType, setProspectiveTournamentType] = useState<TournamentType | null>(null);


  const {
    isAdminLoggedIn,
    adminUsername,
    isLoadingAuth,
    authError,
    login: loginAdmin,
    logout: logoutAdmin,
    changeCredentials,
    setAuthError: clearAuthErrorFromHook, // Renamed to avoid conflict
  } = useAdminAuth();

  const {
    tournament,
    isLoading: tournamentLoading,
    error: tournamentError,
    createTournamentShell,
    finalizeAndStartTournament,
    selectWinner,
    advanceToNextRound,
    resetActiveTournament,
    setError: setTournamentError,
    // finalizeLeagueTournament,  // Removed
  } = useTournament();

  const {
    newsItems,
    isLoadingNews,
    newsError,
    addNewsItem,
    deleteNewsItem,
    setNewsError: clearNewsErrorFromHook,  // Renamed
  } = useNews();

  const {
    archivedTournaments,
    isLoadingHistory,
    historyError,
    addTournamentToHistory,
    deleteTournamentFromHistory,
    setHistoryError: clearHistoryErrorFromHook, // Renamed
  } = useTournamentHistory();

  const {
    rulesContent,
    isLoadingRules,
    rulesError,
    saveRulesContent,
    setRulesError: clearRulesErrorFromHook, // Renamed
  } = useRules();

  const {
    akoAdmins,
    isLoadingAkoAdmins,
    akoAdminsError,
    addAkoAdmin,
    updateAkoAdmin,
    deleteAkoAdmin,
    setAkoAdminsError: clearAkoAdminsErrorFromHook, // Renamed
    getAkoUserByPlatoUsername,
    verifyUserByPlatoAndCode,
  } = useAkoAdmins();

  const {
    feedbacks,
    isLoadingFeedbacks,
    feedbacksError: feedbacksHookError,
    addFeedback: addFeedbackEntry,
    toggleReadStatus,
    toggleArchiveStatus,
    deleteFeedbackEntry: deleteFeedbackFromList,
    setFeedbacksError: clearFeedbacksErrorFromHook, // Renamed
  } = useFeedbacks();

  const {
    bannedUsers,
    isLoadingBanList,
    banListError,
    addBannedUser,
    removeBannedUser,
    setBanListError: clearBanListErrorFromHook, // Renamed
  } = useBanList();

  const {
    games,
    isLoadingGames,
    gamesError,
    addGame,
    updateGameName,
    deleteGame,
    setGamesError: clearGamesErrorFromHook,
  } = useGames();


  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      setLoadingScreenFadingOut(true);
      const removeTimer = setTimeout(() => {
        setAppInitialLoading(false);
      }, 700);
      return () => clearTimeout(removeTimer);
    }, 3500);
    return () => clearTimeout(loadingTimer);
  }, []);

  const clearAllErrors = useCallback(() => {
    setTournamentError(null);
    clearNewsErrorFromHook(null);
    clearHistoryErrorFromHook(null);
    clearRulesErrorFromHook(null);
    clearAuthErrorFromHook(null);
    setUserProfileFormError(null);
    setFeedbackError(null);
    setFeedbackSuccess(null);
    clearFeedbacksErrorFromHook(null);
    clearBanListErrorFromHook(null);
    clearGamesErrorFromHook(null);
  }, [setTournamentError, clearNewsErrorFromHook, clearHistoryErrorFromHook, clearRulesErrorFromHook, clearAuthErrorFromHook, clearFeedbacksErrorFromHook, clearBanListErrorFromHook, clearGamesErrorFromHook]);


  const handleGoHome = useCallback(() => {
    clearAllErrors();
    setHeroScrolled(false);
    setView(ViewState.HOME);
    setUserProfileFormSuccess(null);
  }, [clearAllErrors]);

  const handleGoToAdminDashboard = useCallback(() => {
    clearAllErrors();
    setHeroScrolled(false);
    if (isAdminLoggedIn) {
      setView(ViewState.ADMIN_DASHBOARD);
    } else {
      setView(ViewState.ADMIN_LOGIN);
    }
  }, [isAdminLoggedIn, clearAllErrors]);


  const handleNavigateFromAdminMenu = useCallback((targetView: ViewState) => {
    clearAllErrors();
    setHeroScrolled(false);
    if (!isAdminLoggedIn && targetView !== ViewState.ADMIN_LOGIN && targetView !== ViewState.HOME && !userPanelDetailViews.includes(targetView) && targetView !== ViewState.USER_PANEL_VIEW) {
      setView(ViewState.ADMIN_LOGIN);
      return;
    }

    if (targetView === ViewState.TOURNAMENT_SETUP) {
      if (tournament && tournament.status === 'setup' && (tournament.tournamentType === 'individual' || tournament.tournamentType === 'team')) {
        setView(ViewState.TOURNAMENT_SETUP);
        setIsTournamentTypeModalOpen(false);
        setProspectiveTournamentType(null);
      } else {
        setIsTournamentTypeModalOpen(true);
        setProspectiveTournamentType(null);
      }
    } else {
        setIsTournamentTypeModalOpen(false);
        setView(targetView);
    }
  }, [isAdminLoggedIn, clearAllErrors, tournament]);

  const handleTournamentTypeSelected = (type: TournamentType) => {
    setProspectiveTournamentType(type);
    setIsTournamentTypeModalOpen(false);

    if (tournament && (tournament.tournamentType !== type || (tournament.status !== 'pending' && tournament.status !== 'setup'))) {
      console.warn("Selected new tournament type while another tournament might be in progress or of a different type. Recommended to reset existing tournament shell first if it's not active.");
    }
    // Since 'league' is removed, this will always go to TOURNAMENT_SETUP for 'individual' or 'team'
    setView(ViewState.TOURNAMENT_SETUP);
  };


  const handleArchiveActiveTournament = useCallback(() => {
    if (tournament && (tournament.status === 'awaiting_archival' || tournament.status === 'completed')) {
       if (!tournament.finalWinner) { // This check is now general for bracket tournaments
         setTournamentError("تورنومنت برنده نهایی ندارد و نمی‌تواند آرشیو شود.");
         return;
       }

      const success = addTournamentToHistory(tournament);
      if (success) {
        resetActiveTournament();
        setView(ViewState.ADMIN_DASHBOARD);
      }
    } else {
      setTournamentError("تورنومنت فعلی برای آرشیو آماده نیست.");
    }
  }, [tournament, addTournamentToHistory, resetActiveTournament, setTournamentError]);

  const handleResetActiveTournamentWithoutArchive = useCallback(() => {
    resetActiveTournament();
    setView(ViewState.ADMIN_DASHBOARD);
  }, [resetActiveTournament]);


  const handleSaveUserProfile = useCallback(async (
    realName: string,
    platoUsername: string,
    age: number,
    gender: Gender
  ): Promise<boolean> => {
    setIsProfileFormLoading(true);
    setUserProfileFormError(null);
    setUserProfileFormSuccess(null);

    let resultingUser: AkoAdmin | null = null;
    const existingUserByPlato = getAkoUserByPlatoUsername(platoUsername);

    if (existingUserByPlato) {
      resultingUser = updateAkoAdmin(existingUserByPlato.id, {
        name: realName,
        age: age,
        gender: gender,
        role: 'user',
      });
    } else {
      resultingUser = addAkoAdmin(realName, 'user', { platoUsername, age, gender });
    }

    setIsProfileFormLoading(false);

    if (resultingUser) {
      setUserProfileFormSuccess("پروفایل شما با موفقیت ثبت/به‌روز شد!");
      setCurrentUserProfile(resultingUser);
      if (resultingUser.userCode && resultingUser.role === 'user') {
        setCurrentUserCode(resultingUser.userCode);
        setIsProfileModalOpen(false);
        setShowUserCodeModal(true);
      } else {
         setTimeout(() => {
            setIsProfileModalOpen(false);
            if (userProfileFormSuccess) setUserProfileFormSuccess(null);
        }, 1500);
      }
    } else {
      setUserProfileFormError(akoAdminsError || "خطا در ثبت/به‌روزرسانی پروفایل.");
    }
    return !!resultingUser;
  }, [addAkoAdmin, updateAkoAdmin, getAkoUserByPlatoUsername, akoAdminsError, userProfileFormSuccess]);

  const handleFeedbackSubmit = useCallback(async () => {
    setFeedbackError(null);
    setFeedbackSuccess(null);
    clearFeedbacksErrorFromHook(null);

    if (!feedbackPlatoId.trim() || !feedbackUserCode.trim() || !feedbackMessage.trim()) {
      setFeedbackError("تمام فیلدها (شناسه پلاتو، کد کاربری و پیام) الزامی هستند.");
      return;
    }
    if (feedbackUserCode.length !== 5 || !/^\d{5}$/.test(feedbackUserCode)) {
      setFeedbackError("کد کاربری باید یک عدد ۵ رقمی باشد.");
      return;
    }

    setIsFeedbackSubmitting(true);

    await new Promise(resolve => setTimeout(resolve, 700));

    const userIsValid = verifyUserByPlatoAndCode(feedbackPlatoId, feedbackUserCode);

    if (!userIsValid) {
      setFeedbackError("شناسه پلاتو یا کد کاربری نامعتبر است یا با هم تطابق ندارند.");
      setIsFeedbackSubmitting(false);
      return;
    }

    const newFeedback = addFeedbackEntry(feedbackPlatoId, feedbackUserCode, feedbackMessage);

    if (newFeedback) {
      setFeedbackSuccess("از اینکه نظر خود را با ما در میان گذاشتید سپاسگزاریم! پیام شما دریافت شد.");
      setFeedbackPlatoId('');
      setFeedbackUserCode('');
      setFeedbackMessage('');
    } else {
      setFeedbackError(feedbacksHookError || "خطا در ذخیره سازی بازخورد.");
    }

    setIsFeedbackSubmitting(false);
    setTimeout(() => setFeedbackSuccess(null), 5000);
  }, [feedbackPlatoId, feedbackUserCode, feedbackMessage, verifyUserByPlatoAndCode, addFeedbackEntry, feedbacksHookError, clearFeedbacksErrorFromHook]);


  const adminViewsRequiringSoftUI = [
    ViewState.ADMIN_DASHBOARD,
    ViewState.TOURNAMENT_SETUP,
    // ViewState.LEAGUE_TOURNAMENT_SETUP, // Removed
    ViewState.ADMIN_NEWS_MANAGEMENT,
    ViewState.ADMIN_RULES_MANAGEMENT,
    ViewState.ADMIN_CREDENTIALS_MANAGEMENT,
    ViewState.ADMIN_AKO_ADMINS_MANAGEMENT,
    ViewState.ADMIN_GAMES_MANAGEMENT,
    ViewState.TOURNAMENT_HISTORY,
    ViewState.ADMIN_FEEDBACKS_VIEW,
    ViewState.ADMIN_BAN_LIST_MANAGEMENT,
  ];

  const userPanelDetailViews = [
    ViewState.USER_PANEL_TOURNAMENT_DETAILS_VIEW,
    ViewState.USER_PANEL_NEWS_DETAILS_VIEW,
    ViewState.USER_PANEL_RULES_DETAILS_VIEW,
    ViewState.USER_PANEL_TEAM_DETAILS_VIEW,
  ];

  const isSoftUIThemeActive = isAdminLoggedIn && (adminViewsRequiringSoftUI.includes(view) || (view === ViewState.BRACKET_VIEW && isAdminLoggedIn));
  const isUserPanelThemeActive = view === ViewState.USER_PANEL_VIEW || userPanelDetailViews.includes(view);
  const isFoodieHomeThemeActive = view === ViewState.HOME;


  useEffect(() => {
    const bodyClassList = document.body.classList;
    bodyClassList.remove('soft-ui-theme-active', 'versace-theme-active', 'autumn-grays-theme-active', 'user-panel-active', 'foodie-home-active');

    if (isFoodieHomeThemeActive) {
      bodyClassList.add('foodie-home-active');
    } else if (isSoftUIThemeActive) {
      bodyClassList.add('soft-ui-theme-active');
    } else if (isUserPanelThemeActive) {
      bodyClassList.add('user-panel-active');
    }
  }, [isSoftUIThemeActive, isUserPanelThemeActive, isFoodieHomeThemeActive, view]);


  useEffect(() => {
    if (view === ViewState.HOME && !heroScrolled) {
      document.body.style.overflowY = 'hidden';
    } else {
      document.body.style.overflowY = 'auto';
    }

    return () => {
      document.body.style.overflowY = 'auto';
    };
  }, [view, heroScrolled]);


  useEffect(() => {
    if (appInitialLoading || isLoadingAuth) return;

    if (isAdminLoggedIn) {
      if ([ViewState.HOME, ViewState.USER_PANEL_VIEW, ViewState.ADMIN_LOGIN, ...userPanelDetailViews].includes(view)) {
        setView(ViewState.ADMIN_DASHBOARD);
      }
    } else {
      if (adminViewsRequiringSoftUI.includes(view) && view !== ViewState.BRACKET_VIEW && view !== ViewState.ADMIN_LOGIN) {
         setView(ViewState.HOME);
      } else if (view === ViewState.BRACKET_VIEW && !tournament && !isAdminLoggedIn) {
         setView(ViewState.USER_PANEL_VIEW);
         const tournamentErrorMessage = "تورنومنت فعالی برای مشاهده وجود ندارد.";
         setTournamentError(tournamentErrorMessage);
         // return null; // Original line 432 was here if error was at this line. Not returning null from useEffect.
      }
    }
  }, [isAdminLoggedIn, view, appInitialLoading, isLoadingAuth, tournament, setView, setTournamentError]);

  const prevViewRef = useRef<ViewState>();
  useEffect(() => {
    prevViewRef.current = view;
  });

  useEffect(() => {
    if (
      prevViewRef.current === ViewState.TOURNAMENT_SETUP && // prevView could have been LEAGUE_TOURNAMENT_SETUP, but it's removed
      view === ViewState.TOURNAMENT_SETUP &&
      tournament && tournament.status === 'active' && !tournamentError && isAdminLoggedIn
    ) {
        if (!isTournamentTypeModalOpen) {
             setView(ViewState.BRACKET_VIEW);
        }
    }
  }, [tournament, tournamentError, view, isAdminLoggedIn, isTournamentTypeModalOpen, prospectiveTournamentType, setView]);

  const clearTournamentSetupHookError: () => void = useCallback(() => {
    setTournamentError(null);
  }, [setTournamentError]);


  const renderContent = () => {
    if (tournamentLoading || isLoadingNews || isLoadingHistory || isLoadingRules || isLoadingAuth || isLoadingAkoAdmins || isLoadingFeedbacks || isLoadingBanList || isLoadingGames) {
      let loadingTextColor = 'text-text-cosmicSecondary';
      if (isFoodieHomeThemeActive) loadingTextColor = 'text-foodieTheme-textSecondary';
      else if (isSoftUIThemeActive) loadingTextColor = 'text-softUI-textSecondary';
      else if (isUserPanelThemeActive) loadingTextColor = 'text-userPanel-textSecondary';
      return <div className={`min-h-[calc(100vh-150px)] flex items-center justify-center text-xl ${loadingTextColor}`}>در حال بارگذاری داده‌ها...</div>;
    }

    switch (view) {
      case ViewState.HOME:
        return (
          <div className="flex flex-col items-center">
            <section className="min-h-screen w-full flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
              <h1 className="text-5xl sm:text-6xl font-extrabold text-foodieTheme-textPrimary mb-10 leading-tight">
                به محیط آکو خوش آمدید
              </h1>
              <Button
                variant="custom"
                onClick={() => {
                  setHeroScrolled(true);
                  document.getElementById('home-content-section')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="p-4 bg-foodieTheme-accent text-foodieTheme-onAccent rounded-full shadow-lg hover:bg-foodieTheme-accentHover focus:outline-none focus:ring-2 focus:ring-foodieTheme-focusRing focus:ring-offset-2 focus:ring-offset-foodieTheme-bgPage animate-home-hero-scroll-pulse active:scale-90 transform transition-transform duration-150 ease-in-out"
                aria-label="اسکرول به محتوای اصلی"
              >
                <ChevronDownIcon className="w-10 h-10" />
              </Button>
            </section>

            <section id="home-content-section" className="w-full flex flex-col items-center py-16 px-6 space-y-12">
              <div className="w-full max-w-sm space-y-5">
                <Button onClick={() => { clearAllErrors(); setHeroScrolled(false); setView(ViewState.USER_PANEL_VIEW); }} variant="foodieHomePrimary" size="lg" fullWidth className="!py-3.5 !text-lg"> ورود به پنل کاربران آکو </Button>
                <Button onClick={() => { clearAllErrors(); setHeroScrolled(false); setView(ViewState.ADMIN_LOGIN);}} variant="foodieHomeSecondary" size="lg" fullWidth className="!py-3.5 !text-lg"> ورود به پنل ادمین </Button>
              </div>

              <div className="w-full max-w-xl p-6 sm:p-8 bg-foodieTheme-cardBg rounded-2xl shadow-xl border border-foodieTheme-inputBorder animate-fadeIn" style={{animationDelay: '0.2s'}}>
                <h2 className="text-2xl font-semibold text-foodieTheme-textPrimary mb-6 text-center"> انتقادات و پیشنهادات شما </h2>
                <FeedbackForm platoId={feedbackPlatoId} onPlatoIdChange={setFeedbackPlatoId} userCode={feedbackUserCode} onUserCodeChange={setFeedbackUserCode} message={feedbackMessage} onMessageChange={setFeedbackMessage} onSubmit={handleFeedbackSubmit} isLoading={isFeedbackSubmitting} error={feedbackError} successMessage={feedbackSuccess} theme="foodieHome" clearError={() => { setFeedbackError(null); clearFeedbacksErrorFromHook(null); }} />
              </div>
                 {tournamentError && !tournament && view === ViewState.HOME &&
                  <p className="text-red-400 bg-red-100 border border-red-300 p-3 rounded-md mt-8 text-sm animate-fadeIn">{tournamentError}</p>}
            </section>
          </div>
        );
      case ViewState.USER_PANEL_VIEW:
        return (
          <>
            <div className="min-h-[calc(100vh-160px)] bg-user-panel-gradient text-userPanel-textPrimary flex flex-col items-center justify-start pt-10 sm:pt-16 pb-20 px-4 animate-fadeIn">
              <div className="mb-10 sm:mb-12 text-center">
                <div className="w-24 h-24 sm:w-28 sm:h-28 bg-userPanel-logoCircleBg rounded-full mx-auto flex items-center justify-center shadow-xl mb-4 border-4 border-userPanel-iconContainerBg">
                  <PulseIcon className="w-14 h-14 sm:w-16 sm:h-16 text-userPanel-logoPulseColor animate-userPanelLogoPulse" />
                </div>
                <h1 className="text-3xl sm:text-4xl font-bold text-userPanel-textPrimary">پنل کاربران آکو</h1>
              </div>

              <div className="w-full max-w-lg space-y-4">
                <UserPanelSection icon={<TrophyIcon className="w-6 h-6" />} label="تورنومنت فعال" onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_TOURNAMENT_DETAILS_VIEW); }} isCollapsible={false} />
                <UserPanelSection icon={<UserProfileIcon className="w-6 h-6" />} label="پروفایل کاربری" onClick={() => { const user = currentUserProfile || akoAdmins.find(admin => admin.role === 'user' && admin.platoUsername); setCurrentUserProfile(user); setUserProfileFormError(null); setUserProfileFormSuccess(null); setIsProfileModalOpen(true); }} isCollapsible={false} />
                <UserPanelSection icon={<NewspaperIcon className="w-6 h-6" />} label="اخبار گروه" onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_NEWS_DETAILS_VIEW); }} isCollapsible={false} />
                <UserPanelSection icon={<ScaleIcon className="w-6 h-6" />} label="قوانین آکو" onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_RULES_DETAILS_VIEW); }} isCollapsible={false} />
                <UserPanelSection icon={<UsersGroupIcon className="w-6 h-6" />} label="تیم آکو" onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_TEAM_DETAILS_VIEW); }} isCollapsible={false} />
                {tournamentError && view === ViewState.USER_PANEL_VIEW && <p className="text-userPanel-textSecondary bg-userPanel-cardBg/50 p-3 rounded-lg mt-6 text-sm text-center animate-fadeIn">{tournamentError}</p>}
              </div>
            </div>
            <ProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} title="پروفایل کاربری">
              <UserSelfProfileForm onSaveProfile={handleSaveUserProfile} existingProfile={currentUserProfile} isLoading={isProfileFormLoading} error={userProfileFormError} clearError={() => setUserProfileFormError(null)} successMessage={userProfileFormSuccess} setSuccessMessage={setUserProfileFormSuccess} currentTheme="userPanelInput" />
            </ProfileModal>
            {showUserCodeModal && currentUserCode && ( <UserCodeModal isOpen={showUserCodeModal} onClose={() => setShowUserCodeModal(false)} userCode={currentUserCode} /> )}
          </>
        );
      case ViewState.USER_PANEL_TOURNAMENT_DETAILS_VIEW:
        return (
          <div className="min-h-[calc(100vh-160px)] bg-user-panel-gradient text-userPanel-textPrimary flex flex-col items-center justify-start pt-8 sm:pt-12 pb-12 px-4 animate-fadeIn">
            <div className="w-full max-w-3xl xl:max-w-4xl">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-userPanel-pageTitle">تورنومنت فعال</h1>
                <Button onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_VIEW); }} variant="custom" className="p-2 rounded-full bg-userPanel-backButtonBg hover:bg-userPanel-backButtonHoverBg text-userPanel-backButtonText shadow-md" aria-label="بازگشت به پنل کاربری"> <ArrowLeftIcon className="w-6 h-6" /> </Button>
              </div>
              {tournament && (tournament.status === 'active' || tournament.status === 'awaiting_archival' || tournament.status === 'setup') ? (
                 <BracketDisplay tournament={tournament} isAdmin={false} error={tournamentError} currentTheme="userPanel" />
              ) : (
                <div className="text-center text-userPanel-textSecondary bg-userPanel-cardBg/60 p-6 rounded-xl shadow-lg">
                  <TrophyIcon className="w-16 h-16 mx-auto mb-4 text-userPanel-iconContainerBg opacity-70" />
                  <p className="text-lg">{tournamentError || "در حال حاضر تورنومنتی فعال نیست. منتظر ایجاد تورنومنت توسط ادمین باشید."}</p>
                </div>
              )}
            </div>
          </div>
        );
      case ViewState.USER_PANEL_NEWS_DETAILS_VIEW:
        return (
          <div className="min-h-[calc(100vh-160px)] bg-user-panel-gradient text-userPanel-textPrimary flex flex-col items-center justify-start pt-8 sm:pt-12 pb-12 px-4 animate-fadeIn">
            <div className="w-full max-w-2xl">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-userPanel-pageTitle">اخبار گروه</h1>
                <Button onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_VIEW); }} variant="custom" className="p-2 rounded-full bg-userPanel-backButtonBg hover:bg-userPanel-backButtonHoverBg text-userPanel-backButtonText shadow-md" aria-label="بازگشت"><ArrowLeftIcon className="w-6 h-6" /></Button>
              </div>
              <NewsDisplaySection newsItems={newsItems} isLoading={isLoadingNews} theme="userPanelContent" error={newsError} />
            </div>
          </div>
        );
      case ViewState.USER_PANEL_RULES_DETAILS_VIEW:
        return (
          <div className="min-h-[calc(100vh-160px)] bg-user-panel-gradient text-userPanel-textPrimary flex flex-col items-center justify-start pt-8 sm:pt-12 pb-12 px-4 animate-fadeIn">
            <div className="w-full max-w-2xl">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-userPanel-pageTitle">قوانین آکو</h1>
                <Button onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_VIEW); }} variant="custom" className="p-2 rounded-full bg-userPanel-backButtonBg hover:bg-userPanel-backButtonHoverBg text-userPanel-backButtonText shadow-md" aria-label="بازگشت"><ArrowLeftIcon className="w-6 h-6" /></Button>
              </div>
              <RulesDisplaySection rulesContent={rulesContent} isLoadingRules={isLoadingRules} rulesError={rulesError} theme="userPanelContent" isStandalonePage={true} />
            </div>
          </div>
        );
      case ViewState.USER_PANEL_TEAM_DETAILS_VIEW:
        return (
          <div className="min-h-[calc(100vh-160px)] bg-user-panel-gradient text-userPanel-textPrimary flex flex-col items-center justify-start pt-8 sm:pt-12 pb-12 px-4 animate-fadeIn">
            <div className="w-full max-w-2xl">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-userPanel-pageTitle">تیم آکو</h1>
                <Button onClick={() => { clearAllErrors(); setView(ViewState.USER_PANEL_VIEW); }} variant="custom" className="p-2 rounded-full bg-userPanel-backButtonBg hover:bg-userPanel-backButtonHoverBg text-userPanel-backButtonText shadow-md" aria-label="بازگشت"><ArrowLeftIcon className="w-6 h-6" /></Button>
              </div>
              <AkoAdminsDisplaySection akoAdmins={akoAdmins} isLoading={isLoadingAkoAdmins} error={akoAdminsError} theme="userPanelContent" isStandalonePage={true} />
            </div>
          </div>
        );
      case ViewState.ADMIN_LOGIN:
        return <AdminLogin loginUser={loginAdmin} authError={authError} clearAuthError={() => clearAuthErrorFromHook(null)} />;
      case ViewState.ADMIN_DASHBOARD:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminDashboard onNavigate={handleNavigateFromAdminMenu} />;

      case ViewState.TOURNAMENT_SETUP:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
         return <TournamentSetup
            onCreateTournamentShell={(name, eventDateTime, count, type) => {
                const shell = createTournamentShell(name, eventDateTime, count, type);
                return shell;
            }}
            onFinalizeAndStartTournament={finalizeAndStartTournament}
            onDeleteTournamentShell={handleResetActiveTournamentWithoutArchive}
            currentTournament={tournament}
            akoUsers={akoAdmins.filter(admin => admin.role === 'user')}
            hookError={tournamentError}
            clearHookError={clearTournamentSetupHookError}
            currentTheme="softUI"
            initialTournamentType={prospectiveTournamentType}
        />;

      // case ViewState.LEAGUE_TOURNAMENT_SETUP: // Removed

      case ViewState.ADMIN_GAMES_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminGamesPanel
                  games={games}
                  onAddGame={addGame}
                  onUpdateGame={updateGameName}
                  onDeleteGame={deleteGame}
                  gamesError={gamesError}
                  clearGamesError={() => clearGamesErrorFromHook(null)}
                  onClose={handleGoToAdminDashboard}
               />;

      case ViewState.ADMIN_BAN_LIST_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminBanListPanel
                  bannedUsers={bannedUsers}
                  onAddBannedUser={addBannedUser}
                  onRemoveBannedUser={removeBannedUser}
                  banListError={banListError}
                  clearBanListError={() => clearBanListErrorFromHook(null)}
                  onClose={handleGoToAdminDashboard}
                  currentAdminUsername={adminUsername}
                  currentTheme="softUI"
               />;
      case ViewState.BRACKET_VIEW:
         if (!tournament) {
          if (isAdminLoggedIn) {
            setView(ViewState.ADMIN_DASHBOARD);
            return <p className="text-center text-xl text-softUI-textSecondary p-8">تورنومنتی یافت نشد. در حال انتقال به داشبورد...</p>;
          }
          setView(ViewState.USER_PANEL_VIEW);
          const tournamentErrorMessage = "تورنومنت فعالی برای مشاهده وجود ندارد.";
          setTournamentError(tournamentErrorMessage);
          return null;
        }
        // This will now always be a bracket tournament (individual/team)
        return <BracketDisplay
                  tournament={tournament}
                  isAdmin={isAdminLoggedIn}
                  onSelectWinner={selectWinner}
                  onAdvanceToNextRound={advanceToNextRound}
                  onArchiveTournament={handleArchiveActiveTournament}
                  onResetTournamentWithoutArchive={handleResetActiveTournamentWithoutArchive}
                  error={tournamentError}
                  currentTheme={isSoftUIThemeActive ? 'softUI' : 'default'}
                />;
      case ViewState.ADMIN_NEWS_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminNewsPanel newsItems={newsItems} onAddNews={addNewsItem} onDeleteNews={deleteNewsItem} newsError={newsError} clearNewsError={() => clearNewsErrorFromHook(null)} onClose={handleGoToAdminDashboard} currentTheme="softUI" />;
      case ViewState.TOURNAMENT_HISTORY:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <TournamentHistoryPanel archivedTournaments={archivedTournaments} isLoading={isLoadingHistory} error={historyError} onDeleteTournament={deleteTournamentFromHistory} onClose={handleGoToAdminDashboard} currentTheme="softUI" />;
      case ViewState.ADMIN_RULES_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminRulesPanel initialRulesContent={rulesContent} onSaveRules={saveRulesContent} rulesError={rulesError} clearRulesError={() => clearRulesErrorFromHook(null)} onClose={handleGoToAdminDashboard} currentTheme="softUI" />;
      case ViewState.ADMIN_CREDENTIALS_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminCredentialsPanel onChangeCredentials={changeCredentials} authError={authError} clearAuthError={() => clearAuthErrorFromHook(null)} onClose={handleGoToAdminDashboard} currentAdminUsername={adminUsername} currentTheme="softUI" />;
      case ViewState.ADMIN_AKO_ADMINS_MANAGEMENT:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminAkoAdminsPanel akoAdmins={akoAdmins} onAddAdmin={(name, role, details) => !!addAkoAdmin(name, role, details)} onUpdateAdmin={(id, data) => !!updateAkoAdmin(id, data)} onDeleteAdmin={deleteAkoAdmin} akoAdminsError={akoAdminsError} clearAkoAdminsError={() => clearAkoAdminsErrorFromHook(null)} onClose={handleGoToAdminDashboard} currentTheme="softUI" />;
      case ViewState.ADMIN_FEEDBACKS_VIEW:
        if (!isAdminLoggedIn) { setView(ViewState.ADMIN_LOGIN); return null; }
        return <AdminFeedbacksPanel feedbacks={feedbacks} isLoading={isLoadingFeedbacks} error={feedbacksHookError} onToggleRead={toggleReadStatus} onToggleArchive={toggleArchiveStatus} onDelete={deleteFeedbackFromList} onClose={handleGoToAdminDashboard} clearError={() => clearFeedbacksErrorFromHook(null)} currentTheme="softUI" />;

      default:
        return <p className="text-center text-xl p-8">صفحه مورد نظر یافت نشد.</p>;
    }
  };

  const getHeaderTheme = (): 'cosmic' | 'home' | 'versace' | 'softUI' | 'autumnGrays' | 'userPanel' | 'foodieHome' => {
    if (isFoodieHomeThemeActive) return 'foodieHome';
    if (isSoftUIThemeActive) return 'softUI';
    if (isUserPanelThemeActive) return 'userPanel';
    return 'cosmic';
  };


  if (appInitialLoading) {
    return <LoadingScreen isFadingOut={loadingScreenFadingOut} />;
  }

  return (
    <div className={`flex flex-col min-h-screen transition-colors duration-300
        ${isFoodieHomeThemeActive ? 'bg-foodieTheme-bgPage' :
          (isSoftUIThemeActive ? 'bg-softUI-bgPage' :
            (isUserPanelThemeActive ? 'bg-userPanel-bgGradientFrom' : 'bg-brand-cosmicDarkBg'))}
    `}>
      <Header
        isAdmin={isAdminLoggedIn}
        currentTheme={getHeaderTheme()}
        onLogout={isAdminLoggedIn ? logoutAdmin : undefined}
        onGoHome={handleGoHome}
        onGoToAdminDashboard={isAdminLoggedIn ? handleGoToAdminDashboard : undefined}
        onNavigate={handleNavigateFromAdminMenu}
      />
      <main className="flex-grow container mx-auto w-full">
        {renderContent()}
      </main>
      <TournamentTypeSelectionModal
        isOpen={isTournamentTypeModalOpen}
        onClose={() => {
            setIsTournamentTypeModalOpen(false);
            setProspectiveTournamentType(null);
            if(view === ViewState.TOURNAMENT_SETUP && !tournament) {
                setView(ViewState.ADMIN_DASHBOARD);
            }
        }}
        onSelectType={handleTournamentTypeSelected}
      />
      <Footer currentTheme={getHeaderTheme()} />
    </div>
  );
};

export default App;
