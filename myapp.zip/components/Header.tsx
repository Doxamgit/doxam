
import React, { useState, useEffect, useRef } from 'react';
import { APP_TITLE } from '../constants';
import UsersGroupIcon from './UsersGroupIcon'; 
import ChevronDownIcon from './ChevronDownIcon';
import { ViewState } from '../types'; 

interface HeaderProps {
  isAdmin: boolean;
  currentTheme: 'cosmic' | 'home' | 'versace' | 'softUI' | 'autumnGrays' | 'userPanel' | 'foodieHome'; 
  onLogout?: () => void;
  onGoHome?: () => void; 
  onGoToAdminDashboard?: () => void; 
  onNavigate: (view: ViewState) => void; 
}

const Header: React.FC<HeaderProps> = ({ 
  isAdmin, 
  currentTheme,
  onLogout, 
  onGoHome, 
  onGoToAdminDashboard,
  onNavigate
}) => {
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isVersace = currentTheme === 'versace';
  const isSoftUI = currentTheme === 'softUI';
  const isAutumnGrays = currentTheme === 'autumnGrays';
  const isUserPanel = currentTheme === 'userPanel';
  const isFoodieHome = currentTheme === 'foodieHome';

  let headerBgClass = 'bg-surface-cosmicPanel/80 backdrop-blur-lg shadow-lg border-b border-border-cosmicDefault/60';
  let titleClass = 'text-gradient-title'; 
  let navLinkClass = 'text-text-cosmicSecondary hover:text-text-cosmicPrimary';
  let navLinkBgHover = 'hover:bg-surface-cosmicInput/70';
  
  if (isFoodieHome) {
    headerBgClass = 'bg-foodieTheme-cardBg/80 backdrop-blur-md shadow-md border-b border-foodieTheme-inputBorder/70';
    titleClass = 'text-foodieTheme-accent font-extrabold';
    navLinkClass = 'text-foodieTheme-textSecondary hover:text-foodieTheme-accent';
    navLinkBgHover = 'hover:bg-foodieTheme-inputBg';
  } else if (isVersace) {
    headerBgClass = 'bg-versaceTheme-black border-b border-versaceTheme-gray';
    titleClass = 'text-versaceTheme-white';
    navLinkClass = 'text-versaceTheme-gray hover:text-versaceTheme-white';
    navLinkBgHover = 'hover:bg-versaceTheme-gray/20';
  } else if (isSoftUI) {
    headerBgClass = 'bg-softUI-card shadow-md border-b border-softUI-inputBorder';
    titleClass = 'text-softUI-textPrimary';
    navLinkClass = 'text-softUI-textSecondary hover:text-softUI-primary';
    navLinkBgHover = 'hover:bg-softUI-inputBg';
  } else if (isAutumnGrays) {
    headerBgClass = 'bg-autumnGrays-bgPage/90 backdrop-blur-md shadow-md border-b border-autumnGrays-border/70';
    titleClass = 'text-autumnGrays-textPrimary';
    navLinkClass = 'text-autumnGrays-textSecondary hover:text-autumnGrays-textPrimary';
    navLinkBgHover = 'hover:bg-autumnGrays-cardBg/70';
  } else if (isUserPanel) {
    headerBgClass = 'bg-userPanel-bgGradientTo/90 backdrop-blur-md shadow-lg border-b border-userPanel-iconContainerBg/50';
    titleClass = 'text-userPanel-textPrimary';
    navLinkClass = 'text-userPanel-textSecondary hover:text-userPanel-textPrimary';
    navLinkBgHover = 'hover:bg-userPanel-cardBg/70';
  } else if (currentTheme === 'home') { // Original dark home theme
     headerBgClass = 'bg-brand-home-bg/90 backdrop-blur-md shadow-lg border-b border-brand-home-cardBorder/50';
     titleClass = 'text-brand-home-textPrimary';
     navLinkClass = 'text-brand-home-textSecondary hover:text-brand-home-textPrimary';
     navLinkBgHover = 'hover:bg-brand-home-cardBg/70';
  }
  // Default Cosmic styles are applied if none of the above conditions are met.


  const adminMenuButtonClass = isVersace 
    ? 'text-versaceTheme-white border border-versaceTheme-gray hover:bg-versaceTheme-gray/20 px-3 py-1.5 rounded-md text-sm flex items-center interactive-tap'
    : `${navLinkClass} ${navLinkBgHover} px-3 py-1.5 rounded-md text-sm flex items-center`; 


  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setAdminMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const adminMenuItems = [
    { label: 'اخبار', view: ViewState.ADMIN_NEWS_MANAGEMENT, icon: null },
    { label: 'قوانین', view: ViewState.ADMIN_RULES_MANAGEMENT, icon: null },
    { label: 'تیم آکو', view: ViewState.ADMIN_AKO_ADMINS_MANAGEMENT, icon: <UsersGroupIcon className="w-4 h-4 rtl:ml-1.5 ltr:mr-1.5 opacity-80" /> },
    { label: 'مشخصات ورود', view: ViewState.ADMIN_CREDENTIALS_MANAGEMENT, icon: null },
    { label: 'تاریخچه', view: ViewState.TOURNAMENT_HISTORY, icon: null },
  ];

  return (
    <header className={`${headerBgClass} p-4 sticky top-0 z-50`}>
      <div className="container mx-auto flex justify-between items-center">
        <h1 
            className={`text-2xl md:text-3xl font-bold cursor-pointer hover:opacity-90 transition-opacity ${titleClass}`} 
            onClick={onGoHome} 
            role="button"
            tabIndex={0}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onGoHome?.()}
        >
          {APP_TITLE}
        </h1>
        <div className="space-x-1 sm:space-x-2 flex items-center rtl:space-x-reverse">
           {onGoHome && (currentTheme === 'cosmic' || currentTheme === 'home' || currentTheme === 'autumnGrays' || currentTheme === 'userPanel' || currentTheme === 'foodieHome') && !isAdmin && ( 
             <button 
                onClick={onGoHome}
                className={`${navLinkClass} ${navLinkBgHover} transition-colors px-2 sm:px-3 py-1.5 rounded-md text-sm interactive-tap`}
                aria-label="رفتن به خانه"
             >
                خانه
             </button>
           )}

           {isAdmin && isSoftUI && ( 
             <>
              {onGoToAdminDashboard && (
                <button 
                    onClick={onGoToAdminDashboard}
                    className={`${navLinkClass} ${navLinkBgHover} transition-colors px-2 sm:px-3 py-1.5 rounded-md text-sm font-medium interactive-tap`}
                    aria-label="صفحه اصلی پنل ادمین"
                >
                    صفحه اصلی آکو
                </button>
              )}
              {onLogout && (
                <button 
                    onClick={onLogout} 
                    className={`bg-red-500 hover:bg-red-600 text-white font-semibold py-1.5 px-3 sm:px-4 rounded-lg text-sm transition-colors interactive-tap ${isSoftUI ? '!rounded-md' : ''}`}
                    aria-label="خروج ادمین"
                >
                    خروج
                </button>
              )}
             </>
           )}

           {isAdmin && isVersace ? ( 
             <div className="relative" ref={menuRef}>
               <button
                 onClick={() => setAdminMenuOpen(!adminMenuOpen)}
                 className={adminMenuButtonClass}
                 aria-expanded={adminMenuOpen}
                 aria-haspopup="true"
                 aria-controls="admin-options-menu"
               >
                 اختیارات ادمین
                 <ChevronDownIcon className={`w-4 h-4 rtl:mr-2 ltr:ml-2 transition-transform duration-200 ${adminMenuOpen ? 'transform rotate-180' : ''}`} />
               </button>
               {adminMenuOpen && (
                 <div 
                    id="admin-options-menu"
                    className="absolute rtl:left-0 ltr:right-0 top-full mt-2 w-56 bg-versaceTheme-black border border-versaceTheme-gray rounded-md shadow-xl py-1 z-50
                               origin-top-right transition-all duration-150 ease-out
                               transform opacity-0 scale-95 data-[open=true]:opacity-100 data-[open=true]:scale-100 data-[open=true]:translate-y-0 translate-y-[-10px]"
                    data-open={adminMenuOpen}
                    role="menu"
                 >
                   {onGoHome && ( 
                      <button
                        onClick={() => { onGoHome(); setAdminMenuOpen(false); }}
                        className="w-full text-right rtl:text-left px-4 py-2.5 text-sm text-versaceTheme-white hover:bg-versaceTheme-gray/30 flex items-center interactive-tap"
                        role="menuitem"
                      >
                        خانه
                      </button>
                   )}
                   {adminMenuItems.map(item => (
                     <button
                       key={item.label}
                       onClick={() => { onNavigate(item.view); setAdminMenuOpen(false); }}
                       className="w-full text-right rtl:text-left px-4 py-2.5 text-sm text-versaceTheme-white hover:bg-versaceTheme-gray/30 flex items-center interactive-tap"
                       role="menuitem"
                     >
                       {item.icon}
                       {item.label}
                     </button>
                   ))}
                   {onLogout && (
                     <button
                       onClick={() => { onLogout(); setAdminMenuOpen(false); }}
                       className="w-full text-right rtl:text-left px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/30 flex items-center interactive-tap"
                       role="menuitem"
                     >
                       خروج
                     </button>
                   )}
                 </div>
               )}
             </div>
           ) : isAdmin && (currentTheme === 'cosmic' || currentTheme === 'home' || currentTheme === 'autumnGrays' || currentTheme === 'userPanel' || currentTheme === 'foodieHome') ? ( 
             <>
              {adminMenuItems.map(item => (
                item.label !== 'خانه' && 
                <button
                  key={item.label}
                  onClick={() => onNavigate(item.view)}
                  className={`${navLinkClass} ${navLinkBgHover} transition-colors px-2 sm:px-3 py-1.5 rounded-md text-sm flex items-center interactive-tap`}
                  aria-label={item.label}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
              {onLogout && (
                <button 
                    onClick={onLogout} 
                    className={`bg-red-600 hover:bg-red-700 text-white font-semibold py-1.5 px-3 sm:px-4 rounded-lg text-sm transition-colors interactive-tap
                                ${isAutumnGrays ? '!bg-red-700/80 hover:!bg-red-600/80 !border !border-red-500/50' : ''}
                                ${isUserPanel ? 'bg-red-500 hover:bg-red-600' : ''}
                                ${isFoodieHome ? '!bg-foodieTheme-accent hover:!bg-foodieTheme-accentHover' : ''} `}
                    aria-label="خروج ادمین"
                >
                    خروج
                </button>
              )}
             </>
           ) : null}
        </div>
      </div>
    </header>
  );
};

export default Header;
