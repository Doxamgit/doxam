
import React from 'react';
import type { Tournament, Participant, Match as MatchType } from '../types'; // TournamentRegistration removed
import MatchCard from './MatchCard';
import Button from './Button';
import CrownIcon from './CrownIcon';
// import UserCircleIcon from './UserCircleIcon'; // No longer needed for registered list
import UsersGroupIcon from './UsersGroupIcon'; // For team display

interface BracketDisplayProps {
  tournament: Tournament;
  isAdmin: boolean;
  onSelectWinner?: (roundIndex: number, matchIndex: number, winner: Participant) => void;
  onAdvanceToNextRound?: () => void;
  onArchiveTournament?: () => void; 
  onResetTournamentWithoutArchive?: () => void; 
  error?: string | null;
  currentTheme?: 'default' | 'versace' | 'softUI' | 'userPanel';
  // allRegisteredForSetupTournament?: TournamentRegistration[]; // Removed
}

const formatEventDateTime = (isoString: string) => {
  if (!isoString) return "نامشخص";
  try {
    const date = new Date(isoString);
    return date.toLocaleString('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (e) {
    return "تاریخ نامعتبر";
  }
};

const BracketDisplay: React.FC<BracketDisplayProps> = ({
  tournament,
  isAdmin,
  onSelectWinner,
  onAdvanceToNextRound,
  onArchiveTournament,
  onResetTournamentWithoutArchive,
  error,
  currentTheme = 'default',
  // allRegisteredForSetupTournament // Removed
}) => {
  const isVersaceTheme = currentTheme === 'versace';
  const isSoftUITheme = currentTheme === 'softUI';
  const isUserPanelTheme = currentTheme === 'userPanel';

  let mainBgClass = 'bg-brand-cosmicDarkBg';
  let primaryTextClass = 'text-text-cosmicPrimary';
  let secondaryTextClass = 'text-text-cosmicSecondary';
  let accentTextClass = 'text-brand-cosmicAccentOrange';
  let panelBgClass = 'bg-surface-cosmicPanel border border-brand-cosmicAccentOrange';
  let buttonPrimaryVariant: any = 'cosmicAccent';
  let buttonSecondaryVariant: any = 'cosmicDarkSecondary';
  let buttonDangerVariant: any = 'danger';
  let customDangerButtonClass = '';
  let roundTitleBorderClass = 'border-border-cosmicDefault/80';
  let roundTitleBgClass = 'bg-brand-cosmicDarkBg/90';
  let errorTextClass = 'text-red-300';
  let errorBgClass = 'bg-red-700/40';
  let crownIconClass = 'text-yellow-300 filter drop-shadow(0 0 10px #FF7A59)';
  let componentMinHeight = 'min-h-[calc(100vh-150px)]'; 
  let buttonRoundedClass = '!rounded-full';
  let panelRoundedClass = 'rounded-lg';
  let matchCardTheme: 'default' | 'versace' | 'softUI' | 'userPanel' = 'default';
  // let registeredListBgClass = 'bg-surface-cosmicInput'; // Removed
  // let registeredListBorderClass = 'border-border-cosmicDefault/50'; // Removed
  // let registeredListItemBgClass = 'bg-surface-cosmicPanel/80'; // Removed
  // let registeredListItemBorderClass = 'border-border-cosmicDefault/30'; // Removed
  let winnerNameClass = primaryTextClass; // Default for winner display
  let winnerTeamMemberClass = secondaryTextClass + " text-sm";


  if (isSoftUITheme) {
    mainBgClass = 'bg-softUI-bgPage';
    primaryTextClass = 'text-softUI-textPrimary';
    secondaryTextClass = 'text-softUI-textSecondary';
    accentTextClass = 'text-softUI-primary font-semibold';
    panelBgClass = 'bg-softUI-card border border-softUI-inputBorder shadow-soft-ui-card';
    buttonPrimaryVariant = 'softUIPrimary';
    buttonSecondaryVariant = 'custom'; 
    buttonDangerVariant = 'custom'; 
    customDangerButtonClass = '!bg-red-500 hover:!bg-red-600 !border-red-500 !text-white';
    roundTitleBorderClass = 'border-softUI-inputBorder';
    roundTitleBgClass = 'bg-softUI-bgPage/90 backdrop-blur-sm';
    errorTextClass = 'text-red-700';
    errorBgClass = 'bg-red-100 border border-red-300';
    crownIconClass = 'text-softUI-primary';
    componentMinHeight = 'min-h-[calc(100vh-120px)]'; 
    buttonRoundedClass = '!rounded-xl';
    panelRoundedClass = 'rounded-xl';
    matchCardTheme = 'softUI';
    // registeredListBgClass = 'bg-softUI-inputBg'; // Removed
    // registeredListBorderClass = 'border-softUI-inputBorder'; // Removed
    // registeredListItemBgClass = 'bg-softUI-card/80'; // Removed
    // registeredListItemBorderClass = 'border-softUI-inputBorder/70'; // Removed
    winnerNameClass = "text-softUI-primary font-bold";
    winnerTeamMemberClass = "text-softUI-textSecondary text-sm";
  } else if (isVersaceTheme) {
    mainBgClass = 'bg-versaceTheme-black';
    primaryTextClass = 'text-versaceTheme-white';
    secondaryTextClass = 'text-versaceTheme-gray';
    accentTextClass = 'text-versaceTheme-white font-semibold';
    panelBgClass = 'bg-versaceTheme-panelBg border border-versaceTheme-white';
    buttonPrimaryVariant = 'versacePrimary';
    buttonSecondaryVariant = 'versaceOutline';
    buttonDangerVariant = 'custom';
    customDangerButtonClass = '!bg-red-700 !border-red-700 !text-white hover:!bg-red-600';
    roundTitleBorderClass = 'border-versaceTheme-gray';
    roundTitleBgClass = 'bg-versaceTheme-black/90';
    errorTextClass = 'text-red-400';
    errorBgClass = 'bg-red-900/30 border border-red-500/50';
    crownIconClass = 'text-versaceTheme-white';
    buttonRoundedClass = '!rounded-sm';
    panelRoundedClass = 'rounded-md';
    matchCardTheme = 'versace';
    // registeredListBgClass = 'bg-versaceTheme-panelBg'; // Removed
    // registeredListBorderClass = 'border-versaceTheme-gray/50'; // Removed
    // registeredListItemBgClass = 'bg-versaceTheme-black/80'; // Removed
    // registeredListItemBorderClass = 'border-versaceTheme-gray/30'; // Removed
    winnerNameClass = "text-versaceTheme-white font-bold";
    winnerTeamMemberClass = "text-versaceTheme-gray text-sm";
  } else if (isUserPanelTheme) {
    mainBgClass = 'bg-user-panel-gradient'; 
    primaryTextClass = 'text-userPanel-textPrimary';
    secondaryTextClass = 'text-userPanel-textSecondary';
    accentTextClass = 'text-userPanel-iconContainerBg font-semibold'; 
    panelBgClass = 'bg-userPanel-expandedContentBg border border-userPanel-iconContainerBg/50'; 
    buttonPrimaryVariant = 'custom'; 
    customDangerButtonClass = '!bg-red-600 hover:!bg-red-700 text-white border-red-700'; 
    buttonRoundedClass = '!rounded-full'; 
    roundTitleBorderClass = 'border-userPanel-iconContainerBg/70';
    roundTitleBgClass = 'bg-userPanel-bgGradientTo/90 backdrop-blur-sm'; 
    errorTextClass = 'text-red-300'; 
    errorBgClass = 'bg-red-700/30 border border-red-500/50';
    crownIconClass = 'text-userPanel-iconContainerBg';
    componentMinHeight = 'min-h-[calc(100vh-160px)]'; 
    panelRoundedClass = 'rounded-xl';
    matchCardTheme = 'userPanel';
    // registeredListBgClass = 'bg-userPanel-cardBg/50'; // Removed
    // registeredListBorderClass = 'border-userPanel-iconContainerBg/30'; // Removed
    // registeredListItemBgClass = 'bg-userPanel-expandedContentBg/70'; // Removed
    // registeredListItemBorderClass = 'border-userPanel-iconContainerBg/20'; // Removed
    winnerNameClass = "text-userPanel-iconContainerBg font-bold";
    winnerTeamMemberClass = "text-userPanel-textSecondary text-sm";
  } else { // Cosmic (default)
    winnerNameClass = accentTextClass; // Use accent for Cosmic winner name
  }


  if (!tournament) {
    return <p className={`text-center text-xl p-8 ${secondaryTextClass}`}>داده‌ای برای تورنومنت موجود نیست.</p>;
  }

  const { rounds, status, finalWinner, currentRoundIndex, customName, eventDateTime, participantEntryMode, tournamentType } = tournament;
  const currentActualRound = rounds[currentRoundIndex];
  const canAdvance = isAdmin && status === 'active' && currentActualRound && currentActualRound.isCompleted && currentActualRound.matches.length > 1;
  const isFinalRoundCompletedAndActive = status === 'active' && currentActualRound && currentActualRound.isCompleted && currentActualRound.matches.length === 1;
  const isAwaitingArchival = status === 'awaiting_archival' && finalWinner;

  // const showRegisteredListForUser logic removed
  const overallTournamentIsFinished = tournament.status === 'completed' || tournament.status === 'awaiting_archival';


  return (
    <div className={`p-4 md:p-6 ${componentMinHeight} ${mainBgClass} ${isSoftUITheme ? 'soft-ui-theme-active' : ''} ${isUserPanelTheme ? 'user-panel-active' : ''}`}>
      <div className="mb-8 text-center pt-4">
        <h2 className={`text-3xl md:text-4xl font-bold ${primaryTextClass}`}>{customName}</h2>
        <p className={`${secondaryTextClass} text-sm mt-2`}>تاریخ برگزاری: {formatEventDateTime(eventDateTime)}</p>
        <p className={`${secondaryTextClass} text-xs mt-1`}>نوع تورنومنت: {tournamentType === 'team' ? 'تیمی (یاری)' : 'انفرادی'}</p>
      </div>
      
      {isAdmin && onResetTournamentWithoutArchive && (status === 'active' || status === 'awaiting_archival' || status === 'setup') && (
          <div className="text-center mb-6">
            <Button 
              onClick={onResetTournamentWithoutArchive} 
              variant={buttonDangerVariant} 
              size="sm" 
              className={`${buttonRoundedClass} px-5 ${customDangerButtonClass} ${isUserPanelTheme ? '!bg-red-500 hover:!bg-red-600 !border-transparent' : '' }`}
             >
                لغو و بازنشانی تورنومنت فعال
            </Button>
          </div>
      )}

      {error && <p className={`p-3 ${panelRoundedClass} mb-6 text-center shadow-md ${errorTextClass} ${errorBgClass}`}>{error}</p>}

      {isAwaitingArchival && finalWinner && (
        <div className={`${panelBgClass} p-8 md:p-12 ${panelRoundedClass} shadow-2xl text-center my-8 animate-popIn`}>
          <CrownIcon className={`${crownIconClass} w-20 h-20 md:w-28 md:h-28 mx-auto mb-6 animate-pulse`} />
          <h3 className={`text-3xl md:text-4xl font-extrabold ${primaryTextClass} mb-3`}>
            قهرمان تورنومنت: <span className={winnerNameClass}>{finalWinner.name}</span>!
          </h3>
          {finalWinner.members && finalWinner.members.length > 0 && (
             <p className={`${winnerTeamMemberClass} -mt-2 mb-3`}>
                ({finalWinner.members.map(m => m.name).join(' و ')})
             </p>
          )}
          <p className={`text-lg md:text-xl ${secondaryTextClass}`}>تورنومنت به پایان رسید. آیا مایل به ذخیره آن در تاریخچه هستید؟</p>
          {isAdmin && (
             <div className="mt-8 space-y-4 sm:space-y-0 sm:space-x-4 rtl:sm:space-x-reverse flex flex-col sm:flex-row justify-center">
                <Button 
                  onClick={onArchiveTournament} 
                  variant={buttonPrimaryVariant} 
                  size="lg" 
                  className={`${buttonRoundedClass} ${isUserPanelTheme ? '!bg-userPanel-iconContainerBg !text-userPanel-iconColor hover:!opacity-90' : ''}`}
                >
                    بله، ذخیره در تاریخچه و پایان
                </Button>
                <Button 
                  onClick={onResetTournamentWithoutArchive} 
                  variant={buttonSecondaryVariant} 
                  size="lg" 
                  className={`${buttonRoundedClass} ${isSoftUITheme ? `bg-softUI-inputBg text-softUI-textPrimary border border-softUI-inputBorder hover:bg-softUI-inputBorder hover:border-softUI-primary` : ''} ${isUserPanelTheme ? '!bg-userPanel-cardBg hover:!bg-userPanel-cardHoverBg !text-userPanel-textPrimary !border-userPanel-iconContainerBg/50' : ''}`}
                >
                    خیر، پایان بدون ذخیره
                </Button>
             </div>
          )}
        </div>
      )}

      {/* Registered list for user view removed */}

      {!isAwaitingArchival && (status === 'active' || (status === 'setup' && participantEntryMode === 'manual' && rounds.length > 0)) && (
        <div className="flex space-x-4 md:space-x-6 rtl:space-x-reverse overflow-x-auto pb-8 items-start min-h-[350px] p-2 -mx-2">
          {rounds.map((round, rIdx) => (
            <div key={round.id} className="flex-shrink-0 w-72 animate-fadeIn" style={{ animationDelay: `${rIdx * 120}ms`}}>
              <h3 className={`text-xl font-semibold mb-4 pb-2 border-b-2 sticky top-0 py-2 z-10 px-1 ${primaryTextClass} ${roundTitleBorderClass} ${roundTitleBgClass}`}>{round.name}</h3>
              <div className="space-y-4">
                {round.matches.map((match, mIdx) => (
                  <MatchCard
                    key={match.id}
                    match={match}
                    isAdmin={isAdmin}
                    onSelectWinner={(winner) => 
                      onSelectWinner && onSelectWinner(rIdx, mIdx, winner)
                    }
                    isCompletedTournament={overallTournamentIsFinished}
                    currentTheme={matchCardTheme}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
       {!isAwaitingArchival && rounds.length === 0 && status !== 'pending' && (
         <p className={`text-center py-6 ${secondaryTextClass}`}>
            {status === 'setup' ? 'ادمین در حال تنظیم شرکت کنندگان است. منتظر بمانید.' : 
             (tournamentType === 'team' ? 'تورنومنت تیمی هنوز شروع نشده است.' : 'تورنومنت هنوز شروع نشده است.')}
         </p>
       )}


      {isAdmin && status === 'active' && (canAdvance || isFinalRoundCompletedAndActive) && onAdvanceToNextRound && (
        <div className="mt-8 text-center">
          <Button 
            onClick={onAdvanceToNextRound} 
            variant={buttonPrimaryVariant} 
            size="lg" 
            className={`transform hover:scale-105 ${buttonRoundedClass} ${isUserPanelTheme ? '!bg-userPanel-iconContainerBg !text-userPanel-iconColor hover:!opacity-90' : ''}`}
          >
            {isFinalRoundCompletedAndActive ? 'اعلام برنده نهایی و پایان مرحله' : 'رفتن به مرحله بعد'}
          </Button>
        </div>
      )}
       {!isAdmin && status !== 'completed' && !isAwaitingArchival && <p className={`text-center mt-8 ${secondaryTextClass}`}>حالت تماشاگر: مشاهده پیشرفت تورنومنت.</p>}
       {!isAdmin && status === 'pending' && <p className={`text-center mt-8 ${secondaryTextClass}`}>تنظیمات تورنومنت در انتظار است.</p>}
       {!isAdmin && (status === 'setup' && tournamentType === 'team') && <p className={`text-center mt-8 ${secondaryTextClass}`}>تورنومنت تیمی در حال تنظیم است. منتظر شروع آن توسط ادمین باشید.</p>}
       {!isAdmin && (status === 'setup' && tournamentType === 'individual') && <p className={`text-center mt-8 ${secondaryTextClass}`}>تورنومنت انفرادی در حال تنظیم است. منتظر شروع آن توسط ادمین باشید.</p>}


    </div>
  );
};

export default BracketDisplay;