import React, { useState, useEffect } from 'react';
import type { Gender, AkoAdmin } from '../types';
import Button from './Button';
import Input from './Input';
// import Select from './Select'; // No longer used for gender
import UserProfileIcon from './UserOutlineIcon'; 
import LoginUserIcon from './LoginUserIcon'; 
import GenderIconSelector from './GenderIconSelector'; // Import new component

interface UserSelfProfileFormProps {
  onSaveProfile: (
    realName: string, 
    platoUsername: string, 
    age: number, 
    gender: Gender
  ) => Promise<boolean>; 
  existingProfile?: Pick<AkoAdmin, 'name' | 'platoUsername' | 'age' | 'gender'>; 
  isLoading: boolean;
  error?: string | null;
  clearError: () => void;
  successMessage?: string | null;
  setSuccessMessage: (message: string | null) => void;
  currentTheme?: 'default' | 'autumnGrays' | 'userPanelInput';
}

const UserSelfProfileForm: React.FC<UserSelfProfileFormProps> = ({ 
    onSaveProfile, 
    existingProfile,
    isLoading, 
    error, 
    clearError,
    successMessage,
    setSuccessMessage,
    currentTheme = 'default'
}) => {
  const [realName, setRealName] = useState(existingProfile?.name || '');
  const [platoUsername, setPlatoUsername] = useState(existingProfile?.platoUsername || '');
  const [age, setAge] = useState<string>(existingProfile?.age?.toString() || '');
  const [gender, setGender] = useState<Gender>(existingProfile?.gender || '');

  const [formError, setFormError] = useState<string | null>(null);

  const isAutumnTheme = currentTheme === 'autumnGrays';
  const isUserPanelInputTheme = currentTheme === 'userPanelInput';

  useEffect(() => {
    if (error) {
      setFormError(error);
    } else {
      setFormError(null);
    }
  }, [error]);
  
  useEffect(() => {
    if (existingProfile) {
        setRealName(existingProfile.name || '');
        setPlatoUsername(existingProfile.platoUsername || '');
        setAge(existingProfile.age?.toString() || '');
        setGender(existingProfile.gender || '');
    }
  }, [existingProfile]);


  const handleSubmit = async (e: React.FormEvent) => { 
    e.preventDefault();
    clearError();
    setFormError(null);
    setSuccessMessage(null);

    if (!realName.trim()) {
      setFormError('نام واقعی نمی‌تواند خالی باشد.');
      return;
    }
    if (!platoUsername.trim()) {
      setFormError('نام کاربری پلاتو نمی‌تواند خالی باشد.');
      return;
    }
    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum <= 0) {
      setFormError('سن وارد شده معتبر نیست.');
      return;
    }
    if (!gender && isUserPanelInputTheme && gender !== '') { // Ensure gender is selected if required, allow '' (Prefer not to say)
        // This condition might need re-evaluation based on whether "Prefer not to say" counts as selected.
        // For now, if theme requires it, and it's not set to a specific gender (male, female, other), it could be an error.
        // However, if '' is a valid choice, then this validation should check if it's *still* the default placeholder if one existed.
        // The GenderIconSelector design implies `''` is a valid explicit choice.
    }
     if (isUserPanelInputTheme && gender === undefined) { // If required and truly unselected (not even 'Prefer not to say')
        setFormError('لطفاً جنسیت خود را انتخاب کنید.');
        return;
    }


    const success = await onSaveProfile(realName.trim(), platoUsername.trim(), ageNum, gender); 
    if (success) {
      // Parent handles success message
    }
  };

  // const genderOptions: { value: Gender; label: string }[] = [ // No longer used here
  //   { value: '', label: 'انتخاب کنید...' },
  //   { value: 'male', label: 'مرد' },
  //   { value: 'female', label: 'زن' },
  //   { value: 'other', label: 'دیگر' },
  // ];
  
  const titleClasses = isAutumnTheme 
    ? "text-autumnGrays-textPrimary" 
    : (isUserPanelInputTheme ? "text-userPanel-textPrimary" : "text-brand-cosmicAccentOrange");
  const errorTextClasses = isAutumnTheme
    ? "text-red-200 bg-red-700/50"
    : (isUserPanelInputTheme ? "text-red-300 bg-red-800/60" : "text-red-300 bg-red-900/50");
  const successTextClasses = isAutumnTheme
    ? "text-green-200 bg-green-700/50"
    : (isUserPanelInputTheme ? "text-green-400 bg-green-700/60" : "text-green-400 bg-green-800/50");
  const inputActualTheme = isUserPanelInputTheme ? "userPanelInput" : (isAutumnTheme ? "autumnGrays" : "default");
  const buttonVariant = isUserPanelInputTheme ? "custom" : (isAutumnTheme ? "autumnPrimary" : "cosmicAccent");
  const userPanelButtonClass = isUserPanelInputTheme ? '!bg-userPanel-iconContainerBg !text-userPanel-iconColor hover:!opacity-90 !rounded-full' : '';
  const noteTextClasses = isAutumnTheme ? "text-autumnGrays-textSecondary/80" : (isUserPanelInputTheme ? "text-userPanel-textSecondary text-xs" : "text-text-cosmicSecondary");
  const labelColorClass = isUserPanelInputTheme ? 'text-userPanel-textSecondary' : (isAutumnTheme ? 'text-autumnGrays-textSecondary' : 'text-text-cosmicSecondary');


  return (
    <div className={isUserPanelInputTheme ? "" : `w-full max-w-lg mx-auto mt-8 p-6 md:p-8 rounded-2xl shadow-2xl border ${isAutumnTheme ? "bg-autumnGrays-cardBg border-autumnGrays-border" : "bg-surface-cosmicPanel border-border-cosmicDefault"}`}>
      {isUserPanelInputTheme ? null : (
          <h3 className={`text-2xl sm:text-3xl font-bold mb-8 text-center ${titleClasses}`}>
            {existingProfile ? 'ویرایش پروفایل کاربری' : 'ثبت پروفایل کاربری'}
          </h3>
      )}
      
      {formError && <p className={`p-3 rounded-lg mb-6 text-sm text-center ${errorTextClasses}`}>{formError}</p>}
      {successMessage && <p className={`p-3 rounded-lg mb-6 text-sm text-center ${successTextClasses}`}>{successMessage}</p>}

      <form onSubmit={handleSubmit} className="space-y-5">
        <Input
          label="نام واقعی"
          id="realName"
          type="text"
          value={realName}
          onChange={(e) => { setRealName(e.target.value); clearError(); setFormError(null); }}
          placeholder="مثال: علی رضایی"
          required
          theme={inputActualTheme}
          className="font-medium"
          icon={isUserPanelInputTheme ? <LoginUserIcon /> : undefined}
          iconPosition={isUserPanelInputTheme ? 'leading' : undefined}
        />
        <Input
          label="نام کاربری پلاتو"
          id="platoUsername"
          type="text"
          value={platoUsername}
          onChange={(e) => { setPlatoUsername(e.target.value); clearError(); setFormError(null); }}
          placeholder="مثال: AliReza75"
          required
          theme={inputActualTheme}
          className="font-medium"
          disabled={!!existingProfile} 
          aria-describedby={existingProfile ? "plato-username-disabled-note" : undefined}
          icon={isUserPanelInputTheme ? <LoginUserIcon /> : undefined} 
          iconPosition={isUserPanelInputTheme ? 'leading' : undefined}
        />
        {existingProfile && <p id="plato-username-disabled-note" className={`text-xs mt-1 ${noteTextClasses}`}>نام کاربری پلاتو قابل تغییر نیست.</p>}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-5 items-start">
          <Input
            label="سن"
            id="age"
            type="number"
            value={age}
            onChange={(e) => { setAge(e.target.value); clearError(); setFormError(null); }}
            placeholder="مثال: 28"
            required
            min="1"
            theme={inputActualTheme}
            className="font-medium"
          />
          <div>
            <label htmlFor="gender-selector" className={`block text-sm font-medium mb-1.5 ${labelColorClass}`}>
              جنسیت {isUserPanelInputTheme ? <span className="text-red-400">*</span> : ''}
            </label>
            <GenderIconSelector
              value={gender}
              onChange={(newGenderValue) => { setGender(newGenderValue); clearError(); setFormError(null); }}
              theme={inputActualTheme}
              id="gender-selector"
            />
          </div>
        </div>

        <Button
          type="submit"
          variant={buttonVariant as any}
          size="lg"
          fullWidth
          className={`!py-3 !text-base !mt-8 flex items-center justify-center ${userPanelButtonClass} ${isAutumnTheme ? '' : (isUserPanelInputTheme ? '' : '!rounded-xl')}`}
          disabled={isLoading}
          lightningTap={isAutumnTheme}
        >
          {isLoading ? 'در حال ذخیره...' : (existingProfile ? 'ذخیره تغییرات' : 'ثبت اطلاعات')}
        </Button>
      </form>
    </div>
  );
};

export default UserSelfProfileForm;