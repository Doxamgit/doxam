
import React, { useState } from 'react';
import type { AkoAdmin } from '../types';
import Button from './Button';
import ChevronDownIcon from './ChevronDownIcon';
import ChevronUpIcon from './ChevronUpIcon';
import UsersGroupIcon from './UsersGroupIcon';
import StarDisplay from './StarDisplay';
import EyeOpenIcon from './EyeOpenIcon'; 
import EyeClosedIcon from './EyeClosedIcon'; 

interface AkoAdminsDisplaySectionProps {
  akoAdmins: AkoAdmin[];
  isLoading: boolean;
  error: string | null;
  theme?: 'default' | 'home' | 'autumnGrays' | 'userPanelContent'; 
  isStandalonePage?: boolean; // New prop
}

const AkoAdminsDisplaySection: React.FC<AkoAdminsDisplaySectionProps> = ({ 
  akoAdmins, 
  isLoading, 
  error, 
  theme = 'default',
  isStandalonePage = false // Default to false
}) => {
  const [isExpanded, setIsExpanded] = useState(isStandalonePage || (theme === 'userPanelContent' ? false : true));
  const [visibleScores, setVisibleScores] = useState<{ [key: string]: boolean }>({});

  const isHomeTheme = theme === 'home';
  const isAutumnTheme = theme === 'autumnGrays';
  const isUserPanelContentTheme = theme === 'userPanelContent';


  let baseContainerClass = "w-full max-w-2xl mx-auto mt-10 mb-8 p-6 rounded-xl shadow-xl animate-fadeIn transition-all duration-300 hover:shadow-2xl";
  if (isUserPanelContentTheme || isStandalonePage) {
    baseContainerClass = "w-full animate-fadeIn p-1"; 
  }
  let themeContainerClass = "";
  let titleClass = "";
  let iconInTitleClass = "";
  let textClass = ""; 
  let errorTextClass = "";
  let errorBorderClass = ""; 
  let buttonVariant: any = 'artisticOutline';
  let buttonCustomClass = "!rounded-full !px-3 !py-1.5";
  let buttonFocusRingOffset = 'focus:ring-offset-surface-artisticTealPoemPanel';
  let contentBorderClass = "border-brand-artisticGoldAccent/30"; 
  
  let adminCardBg = "bg-brand-artisticTealBg/60";
  let adminCardBorder = "border-brand-artisticGoldAccent/30";
  let adminNameClass = "text-text-onArtisticTealPrimary";
  let adminDetailsClass = "text-text-onArtisticTealSecondary/90"; 
  let adminScoreButtonClass = `text-text-onArtisticTealSecondary/80 hover:text-brand-artisticGoldAccent hover:bg-brand-artisticGoldAccent/10 border-brand-artisticGoldAccent/30 hover:border-brand-artisticGoldAccent/50 focus:ring-offset-brand-artisticTealBg/60`;
  let adminScoreContentBorder = "border-brand-artisticGoldAccent/20";
  let lightningTapButton = false;
  let showHeader = !isUserPanelContentTheme && !isStandalonePage;

  if (isHomeTheme) {
    themeContainerClass = "bg-brand-home-cardBg border border-brand-home-cardBorder hover:border-brand-home-cardBorder/70";
    titleClass = "text-brand-home-cardHeaderText";
    iconInTitleClass = "text-brand-home-textPrimary";
    textClass = "text-brand-home-textSecondary";
    errorTextClass = "text-red-400";
    errorBorderClass = "border-red-500/50";
    buttonVariant = 'custom';
    buttonCustomClass = `text-brand-home-buttonSecondaryText border border-brand-home-buttonSecondaryBorder hover:bg-brand-home-buttonSecondaryBgHover hover:border-brand-home-buttonSecondaryBorderHover focus:ring-brand-home-accentGlow !rounded-full !px-3 !py-1.5`;
    buttonFocusRingOffset = 'focus:ring-offset-brand-home-cardBg';
    contentBorderClass = "border-brand-home-cardBorder/50";
    adminCardBg = "bg-brand-home-bg/50";
    adminCardBorder = "border-brand-home-cardBorder/50";
    adminNameClass = "text-brand-home-textPrimary";
    adminDetailsClass = "text-brand-home-textSecondary/90";
    adminScoreButtonClass = `text-brand-home-textSecondary/80 hover:text-brand-home-accentGlow hover:bg-brand-home-accentGlow/10 border-brand-home-cardBorder/60 hover:border-brand-home-accentGlow/50 focus:ring-offset-brand-home-bg/50`;
    adminScoreContentBorder = "border-brand-home-cardBorder/30";
  } else if (isAutumnTheme) {
    themeContainerClass = "bg-autumnGrays-cardBg border border-autumnGrays-border hover:border-opacity-80";
    titleClass = "text-autumnGrays-textPrimary";
    iconInTitleClass = "text-autumnGrays-textPrimary";
    textClass = "text-autumnGrays-textSecondary";
    errorTextClass = "text-red-200";
    errorBorderClass = "border-red-400/50";
    buttonVariant = 'autumnSecondary';
    buttonCustomClass = `!rounded-full !px-3 !py-1.5`;
    buttonFocusRingOffset = 'focus:ring-offset-autumnGrays-cardBg';
    contentBorderClass = "border-autumnGrays-border/70";
    adminCardBg = "bg-autumnGrays-bgPage"; 
    adminCardBorder = "border-autumnGrays-border/70";
    adminNameClass = "text-autumnGrays-textPrimary";
    adminDetailsClass = "text-autumnGrays-textSecondary";
    adminScoreButtonClass = `text-autumnGrays-textSecondary/80 hover:text-autumnGrays-textPrimary hover:bg-autumnGrays-textPrimary/10 border-autumnGrays-border/60 hover:border-autumnGrays-textPrimary/50 focus:ring-offset-autumnGrays-bgPage`;
    adminScoreContentBorder = "border-autumnGrays-border/50";
    lightningTapButton = true;
  } else if (isUserPanelContentTheme || isStandalonePage) {
    themeContainerClass = ""; 
    titleClass = "text-userPanel-textPrimary"; 
    iconInTitleClass = "text-userPanel-textPrimary"; 
    
    if (isUserPanelContentTheme) { // Correctly use the boolean
        textClass = "text-userPanel-textSecondary"; 
        errorTextClass = "text-red-300";
        contentBorderClass = "border-userPanel-iconContainerBg/30"; 
        adminCardBg = "bg-userPanel-cardBg/70 backdrop-blur-sm"; 
        adminCardBorder = "border-userPanel-iconContainerBg/30";
        adminNameClass = "text-userPanel-textPrimary";
        adminDetailsClass = "text-userPanel-textSecondary";
        adminScoreButtonClass = `text-userPanel-textSecondary/90 hover:text-userPanel-textPrimary hover:bg-userPanel-iconContainerBg/20 border-userPanel-iconContainerBg/40 hover:border-userPanel-iconContainerBg/60 focus:ring-offset-userPanel-cardBg/70`;
        adminScoreContentBorder = "border-userPanel-iconContainerBg/20";
    } else { // Generic standalone styling (isStandalonePage is true, isUserPanelContentTheme is false)
        textClass = "text-gray-700"; // Generic for standalone message text
        errorTextClass = "text-red-500";
        contentBorderClass = "border-gray-300";
        adminCardBg = "bg-gray-100";
        adminCardBorder = "border-gray-300";
        adminNameClass = "text-gray-800";
        adminDetailsClass = "text-gray-600";
        adminScoreButtonClass = `text-gray-500 hover:text-blue-600 hover:bg-blue-100 border-gray-300 hover:border-blue-400 focus:ring-offset-gray-100`;
        adminScoreContentBorder = "border-gray-200";
    }
    buttonVariant = 'custom'; 
    buttonCustomClass = ''; 
  }
  else { // Default (Cosmic-Artistic)
    themeContainerClass = "bg-surface-artisticTealPoemPanel border border-brand-artisticGoldAccent/40 hover:border-brand-artisticGoldAccent/60";
    titleClass = "text-brand-artisticGoldAccent";
    iconInTitleClass = "text-brand-artisticGoldAccent";
    textClass = "text-text-onArtisticTealSecondary";
    errorTextClass = "text-red-300";
    errorBorderClass = "border-red-500/60";
  }


  const roleTranslations: { [key in AkoAdmin['role']]: string } = {
    owner: "صاحب گروه",
    admin: "ادمین گروه",
    moderator: "ناظر گروه",
    user: "کاربر گروه",
  };

  const toggleScoresVisibility = (adminId: string) => {
    setVisibleScores(prev => ({ ...prev, [adminId]: !prev[adminId] }));
  };

  if (isLoading) {
    return (
      <div className={`${baseContainerClass} ${themeContainerClass}`}>
        {showHeader && 
            <h3 className={`text-2xl font-semibold mb-4 text-center flex items-center justify-center ${titleClass}`}>
            <UsersGroupIcon className={`w-7 h-7 ml-2 rtl:mr-2 rtl:ml-0 ${iconInTitleClass}`} />
            تیم آکو
            </h3>
        }
        <p className={`${textClass} text-center`}>در حال بارگذاری اطلاعات تیم...</p>
      </div>
    );
  }

  if (error && !isUserPanelContentTheme && !isStandalonePage) {
    return (
      <div className={`${baseContainerClass} ${isHomeTheme || isAutumnTheme ? themeContainerClass : `bg-surface-artisticTealPoemPanel ${errorBorderClass}` }`}>
        {showHeader && 
            <h3 className={`text-2xl font-semibold mb-4 text-center flex items-center justify-center ${titleClass}`}>
                <UsersGroupIcon className={`w-7 h-7 ml-2 rtl:mr-2 rtl:ml-0 ${iconInTitleClass}`} />
                تیم آکو
            </h3>
        }
        <p className={`${errorTextClass} text-center`}>{error}</p>
      </div>
    );
  }
  
  const renderAdminCard = (admin: AkoAdmin) => (
    <div key={admin.id} className={`p-3 sm:p-4 ${adminCardBg} rounded-lg border ${adminCardBorder} shadow-md`}>
      <div>
        <p className={`font-semibold text-md sm:text-lg ${adminNameClass}`}>{admin.name}</p>
        <p className={`text-xs sm:text-sm ${adminDetailsClass} mb-1.5`}>{roleTranslations[admin.role]}</p>
      </div>

      <div className="mt-1 mb-1.5">
        <Button 
          onClick={() => toggleScoresVisibility(admin.id)} 
          variant="custom" 
          className={`inline-flex items-center px-2 py-1 text-xs rounded-md border focus:outline-none focus:ring-1 focus:ring-current ${adminScoreButtonClass}`}
          aria-expanded={visibleScores[admin.id]}
          aria-controls={`scores-content-${admin.id}`}
          lightningTap={isAutumnTheme || isUserPanelContentTheme || isStandalonePage}
        >
          {visibleScores[admin.id] ? <EyeOpenIcon className="w-3.5 h-3.5 rtl:ml-1 ltr:mr-1" /> : <EyeClosedIcon className="w-3.5 h-3.5 rtl:ml-1 ltr:mr-1" />}
          <span className="text-[0.7rem]">{visibleScores[admin.id] ? 'پنهان کردن جزئیات' : 'نمایش جزئیات'}</span>
        </Button>
      </div>
      
      {visibleScores[admin.id] && (
        <div id={`scores-content-${admin.id}`} className={`mt-2 pt-2 border-t ${adminScoreContentBorder} animate-fadeIn text-xs`}>
          {(admin.role === 'admin' || admin.role === 'moderator') && (
            <div className={`${adminDetailsClass}`}>
              <div className="flex items-center mb-1">
                <span className="font-medium">میانگین امتیاز:</span>
                <StarDisplay rating={admin.averageRating ?? 0} starSize="w-3.5 h-3.5" className="rtl:mr-1 ltr:ml-1" theme={theme === 'userPanelContent' || isStandalonePage ? 'userPanel' : theme} />
                <span>({(admin.averageRating ?? 0).toFixed(1)}/5)</span>
              </div>
              <ul className="list-disc rtl:list-inside ltr:list-inside rtl:mr-3 ltr:ml-3 text-[0.65rem] sm:text-xs opacity-90">
                <li>رفتار حرفه ای: {admin.professionalismScore ?? 0}/5</li>
                <li>فعالیت و در دسترس بودن: {admin.activityAvailabilityScore ?? 0}/5</li>
                <li>توانایی رفع مشکل: {admin.problemSolvingScore ?? 0}/5</li>
              </ul>
            </div>
          )}

          {admin.role === 'user' && (
            <div className={`space-y-0.5 text-xs ${adminDetailsClass}`}>
              <div className="flex items-center">
                رعایت قوانین: 
                <StarDisplay rating={admin.ruleAdherenceScore ?? 0} starSize="w-3 h-3" className="rtl:mr-1 ltr:ml-1" theme={theme === 'userPanelContent' || isStandalonePage ? 'userPanel' : theme} /> 
                ({admin.ruleAdherenceScore ?? 0}/5)
              </div>
              <div className="flex items-center">
                احترام به دیگران: 
                <StarDisplay rating={admin.respectScore ?? 0} starSize="w-3 h-3" className="rtl:mr-1 ltr:ml-1" theme={theme === 'userPanelContent' || isStandalonePage ? 'userPanel' : theme} /> 
                ({admin.respectScore ?? 0}/5)
              </div>
              <div className="flex items-center">
                دقت در ارسال مطالب: 
                <StarDisplay rating={admin.contentAccuracyScore ?? 0} starSize="w-3 h-3" className="rtl:mr-1 ltr:ml-1" theme={theme === 'userPanelContent' || isStandalonePage ? 'userPanel' : theme} /> 
                ({admin.contentAccuracyScore ?? 0}/5)
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const owners = akoAdmins.filter(admin => admin.role === 'owner');
  const adminsAndModerators = akoAdmins.filter(admin => admin.role === 'admin' || admin.role === 'moderator')
                                  .sort((a,b) => (b.averageRating ?? 0) - (a.averageRating ?? 0));
  const users = akoAdmins.filter(admin => admin.role === 'user')
                    .sort((a, b) => { 
                        const sumA = (a.ruleAdherenceScore ?? 0) + (a.respectScore ?? 0) + (a.contentAccuracyScore ?? 0);
                        const sumB = (b.ruleAdherenceScore ?? 0) + (b.respectScore ?? 0) + (b.contentAccuracyScore ?? 0);
                        return sumB - sumA;
                    });

  // For userPanelContent or standalone, always display content without internal toggle.
  if (isUserPanelContentTheme || isStandalonePage) {
    return (
       <div className={`${baseContainerClass} ${themeContainerClass} space-y-5`}>
          {error && <p className={`${errorTextClass} text-center py-2 text-sm`}>خطا: {error}</p>}
          {akoAdmins.length === 0 && !error ? (
            <p className={`${textClass} text-center italic py-2`}>هنوز اطلاعاتی برای تیم ثبت نشده است.</p>
          ) : (
            <>
              {owners.length > 0 && (
                <div>
                  <h4 className={`text-lg font-semibold ${adminNameClass} mb-2 border-b ${contentBorderClass} pb-1`}>
                    {roleTranslations.owner}
                  </h4>
                  <div className="space-y-2.5">
                    {owners.map(renderAdminCard)}
                  </div>
                </div>
              )}
              {adminsAndModerators.length > 0 && (
                <div>
                   <h4 className={`text-lg font-semibold ${adminNameClass} mb-2 border-b ${contentBorderClass} pb-1`}>
                    کادر مدیریتی و نظارت
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {adminsAndModerators.map(renderAdminCard)}
                  </div>
                </div>
              )}
              {users.length > 0 && (
                <div>
                  <h4 className={`text-lg font-semibold ${adminNameClass} mb-2 border-b ${contentBorderClass} pb-1`}>
                    {roleTranslations.user}ها
                  </h4>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {users.map(renderAdminCard)}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
    );
  }


  return (
    <div className={`${baseContainerClass} ${themeContainerClass}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className={`text-2xl font-semibold flex items-center ${titleClass}`}>
            <UsersGroupIcon className={`w-7 h-7 ml-2 rtl:mr-2 rtl:ml-0 ${iconInTitleClass}`} />
            تیم آکو
        </h3>
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          variant={buttonVariant}
          size="sm"
          className={`${buttonCustomClass} ${buttonFocusRingOffset}`}
          aria-expanded={isExpanded}
          aria-controls="ako-admins-content-area"
          lightningTap={lightningTapButton}
        >
          {isExpanded ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
          <span className="mr-2 rtl:ml-2 rtl:mr-0">{isExpanded ? 'پنهان کردن' : 'مشاهده تیم'}</span>
        </Button>
      </div>
      
      {isExpanded && (
        <div id="ako-admins-content-area" className={`mt-4 pt-4 border-t ${contentBorderClass} animate-fadeIn space-y-6`}>
          {akoAdmins.length === 0 ? (
            <p className={`${textClass} text-center italic`}>هنوز اطلاعاتی برای تیم ثبت نشده است.</p>
          ) : (
            <>
              {owners.length > 0 && (
                <div>
                  <h4 className={`text-xl font-semibold ${adminNameClass} mb-3 border-b ${contentBorderClass} pb-1.5`}>
                    {roleTranslations.owner}
                  </h4>
                  <div className="space-y-3">
                    {owners.map(renderAdminCard)}
                  </div>
                </div>
              )}
              {adminsAndModerators.length > 0 && (
                <div>
                   <h4 className={`text-xl font-semibold ${adminNameClass} mb-3 border-b ${contentBorderClass} pb-1.5`}>
                    کادر مدیریتی و نظارت
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {adminsAndModerators.map(renderAdminCard)}
                  </div>
                </div>
              )}
              {users.length > 0 && (
                <div>
                  <h4 className={`text-xl font-semibold ${adminNameClass} mb-3 border-b ${contentBorderClass} pb-1.5`}>
                    {roleTranslations.user}ها
                  </h4>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {users.map(renderAdminCard)}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AkoAdminsDisplaySection;
