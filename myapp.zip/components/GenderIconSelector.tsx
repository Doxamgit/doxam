import React from 'react';
import type { Gender } from '../types';
import MaleIcon from './MaleIcon';
import FemaleIcon from './FemaleIcon';
import GenderNeutralIcon from './GenderNeutralIcon';
import DoNotDisturbIcon from './DoNotDisturbIcon';

interface GenderIconSelectorProps {
  value: Gender;
  onChange: (value: Gender) => void;
  theme: 'default' | 'softUI' | 'userPanelInput' | 'autumnGrays'; // Added autumnGrays, default
  id?: string;
}

const GenderIconSelector: React.FC<GenderIconSelectorProps> = ({ value, onChange, theme, id }) => {
  const options: { value: Gender; label: string; icon: JSX.Element }[] = [
    { value: 'male', label: 'مرد', icon: <MaleIcon /> },
    { value: 'female', label: 'زن', icon: <FemaleIcon /> },
    { value: 'other', label: 'دیگر', icon: <GenderNeutralIcon /> },
    { value: '', label: 'ترجیح می‌دهم نگویم', icon: <DoNotDisturbIcon /> },
  ];

  return (
    <div id={id} className="flex space-x-2 rtl:space-x-reverse" role="radiogroup" aria-label="جنسیت">
      {options.map((option) => {
        const isSelected = value === option.value;
        let buttonClasses = `p-2.5 rounded-lg border-2 transition-all duration-200 ease-in-out focus:outline-none focus:ring-2`;
        let iconClasses = `w-6 h-6 sm:w-7 sm:h-7`; // Slightly larger icons

        if (theme === 'userPanelInput') {
          buttonClasses += isSelected
            ? ' bg-userPanel-iconContainerBg border-transparent shadow-lg ring-userPanel-inputFocusRing ring-offset-2 ring-offset-userPanel-expandedContentBg'
            : ' bg-userPanel-inputBg border-userPanel-inputBorder hover:border-userPanel-iconContainerBg/70 shadow-md hover:shadow-lg';
          iconClasses += isSelected ? ' text-userPanel-iconColor' : ' text-userPanel-inputText/70';
        } else if (theme === 'softUI') {
          buttonClasses += isSelected
            ? ' bg-softUI-primary border-transparent shadow-lg ring-softUI-focusRing ring-offset-2 ring-offset-softUI-card'
            : ' bg-softUI-inputBg border-softUI-inputBorder hover:border-softUI-primary shadow-soft-ui-card hover:shadow-lg';
          iconClasses += isSelected ? ' text-softUI-textOnPrimary' : ' text-softUI-textSecondary';
        } else if (theme === 'autumnGrays') {
           buttonClasses += isSelected
            ? ' bg-autumnGrays-textPrimary border-transparent shadow-lg ring-autumnGrays-focusRing ring-offset-2 ring-offset-autumnGrays-cardBg'
            : ' bg-autumnGrays-inputBg border-autumnGrays-border hover:border-autumnGrays-textPrimary/70 shadow-md hover:shadow-lg';
          iconClasses += isSelected ? ' text-autumnGrays-buttonPrimaryText' : ' text-autumnGrays-textSecondary';
        }
         else { // Default theme (cosmic-like)
          buttonClasses += isSelected
            ? ' bg-brand-cosmicAccentOrange border-transparent shadow-xl ring-border-cosmicFocus ring-offset-2 ring-offset-surface-cosmicPanel'
            : ' bg-surface-cosmicInput border-border-cosmicDefault hover:border-brand-cosmicAccentOrange/70 shadow-lg hover:shadow-xl';
          iconClasses += isSelected ? ' text-text-cosmicOnAccent' : ' text-text-cosmicPrimary/80';
        }

        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={isSelected}
            aria-label={option.label}
            onClick={() => onChange(option.value)}
            className={`${buttonClasses} transform active:scale-95`}
            title={option.label} // Tooltip for clarity
          >
            {React.cloneElement(option.icon, { className: iconClasses })}
          </button>
        );
      })}
    </div>
  );
};

export default GenderIconSelector;