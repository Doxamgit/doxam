
import React from 'react';

const PulseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 68 44" // Adjusted viewBox for the path
    strokeWidth={3.5} // Bolder stroke
    stroke="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M4 22H12L18 12L26 32L34 16L40 26L46 20H52L58 22H64"
      // Animation related properties can be controlled via className if needed:
      // e.g., strokeDasharray="100"
    />
  </svg>
);

export default PulseIcon;
