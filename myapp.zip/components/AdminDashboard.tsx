
import React, { useState } from 'react';
import Button from './Button';
import AdminDashboardModal from './AdminDashboardModal';
import { ViewState } from '../types';
import { APP_TITLE } from '../constants';


interface AdminDashboardProps {
  onNavigate: (view: ViewState) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const titleParts = APP_TITLE.split(' ');
  const akoWord = titleParts.pop() || "آکو";
  const prefixTitle = titleParts.join(' ');


  return (
    <div className="min-h-[calc(100vh-200px)] flex flex-col items-center justify-center p-6 text-center animate-fadeIn bg-softUI-bgPage">
      <div className="mb-10">
        <h1 className="text-5xl sm:text-6xl font-extrabold text-softUI-textPrimary">
           {prefixTitle} <span className="text-softUI-primary">{akoWord}</span>
        </h1>
        <p className="text-xl text-softUI-textSecondary mt-3">پنل مدیریت</p>
      </div>

      <Button
        onClick={() => setIsModalOpen(true)}
        variant="custom"
        size="xl"
        className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold py-6 px-12 rounded-2xl shadow-xl
                   transform transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300 focus:ring-offset-2 focus:ring-offset-softUI-bgPage
                   animate-adminDashboardButtonPulse"
        aria-haspopup="true"
        aria-expanded={isModalOpen}
      >
        <span className="text-2xl sm:text-3xl tracking-wide">اختیارات آکو</span>
      </Button>

      <AdminDashboardModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onNavigate={onNavigate}
      />
      
      <p className="text-softUI-textSecondary mt-12 text-sm">
        از این بخش می‌توانید به تمامی تنظیمات و مدیریت‌های مربوط به تورنومنت‌ها دسترسی داشته باشید.
      </p>
    </div>
  );
};

export default AdminDashboard;
