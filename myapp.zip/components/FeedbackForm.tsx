
import React from 'react';
import Input from './Input';
import Button from './Button';

interface FeedbackFormProps {
  platoId: string;
  onPlatoIdChange: (value: string) => void;
  userCode: string;
  onUserCodeChange: (value: string) => void;
  message: string;
  onMessageChange: (value: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
  theme: 'home' | 'foodieHome'; // Added 'foodieHome'
  clearError: () => void;
}

const FeedbackForm: React.FC<FeedbackFormProps> = ({
  platoId,
  onPlatoIdChange,
  userCode,
  onUserCodeChange,
  message,
  onMessageChange,
  onSubmit,
  isLoading,
  error,
  successMessage,
  theme,
  clearError,
}) => {
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  // Determine specific theme styles based on the theme prop
  const isFoodieHome = theme === 'foodieHome';

  const errorTextClass = isFoodieHome ? 'text-red-100 bg-red-500/70 border-red-400/70' : 'text-red-100 bg-red-700/60 border-red-500/70';
  const successTextClass = isFoodieHome ? 'text-green-900 bg-green-200/80 border-green-400/70' : 'text-green-100 bg-green-600/60 border-green-500/70';
  const labelClass = isFoodieHome ? 'text-foodieTheme-textSecondary' : 'text-brand-home-textSecondary';
  const textareaBaseClass = `block w-full px-4 py-3 rounded-xl shadow-sm sm:text-sm font-medium transition-colors duration-150`;
  const textareaThemeClass = isFoodieHome 
    ? `bg-foodieTheme-inputBg border border-foodieTheme-inputBorder text-foodieTheme-inputText placeholder-foodieTheme-inputPlaceholder focus:outline-none focus:ring-2 focus:ring-foodieTheme-focusRing focus:border-transparent`
    : `bg-brand-home-inputBg border border-brand-home-inputBorder text-brand-home-inputText placeholder-brand-home-inputPlaceholder focus:outline-none focus:ring-2 focus:ring-brand-home-inputFocusRing focus:border-transparent`;
  const buttonVariant = isFoodieHome ? 'foodieHomePrimary' : 'homePrimaryAction';
  const inputTheme = isFoodieHome ? 'foodieHome' : 'home';


  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {error && (
        <p role="alert" className={`p-3 rounded-lg text-sm text-center ${errorTextClass}`}>
          {error}
        </p>
      )}
      {successMessage && (
        <p role="status" className={`p-3 rounded-lg text-sm text-center ${successTextClass}`}>
          {successMessage}
        </p>
      )}
      <Input
        label="شناسه پلاتو شما"
        id="feedback-plato-id"
        type="text"
        value={platoId}
        onChange={(e) => { onPlatoIdChange(e.target.value); clearError(); }}
        placeholder="شناسه پلاتو خود را وارد کنید"
        required
        theme={inputTheme}
        className="font-medium"
        aria-describedby={error ? "feedback-error-desc" : undefined}
        aria-invalid={!!error}
      />
      <Input
        label="کد کاربری (۵ رقمی)"
        id="feedback-user-code"
        type="text" 
        value={userCode}
        onChange={(e) => {
          const val = e.target.value.replace(/\D/g, ''); 
          if (val.length <= 5) {
            onUserCodeChange(val);
          }
          clearError();
        }}
        placeholder="کد ۵ رقمی خود را وارد کنید"
        required
        theme={inputTheme}
        className="font-medium tracking-widest text-center"
        maxLength={5}
        pattern="\d{5}"
        title="کد کاربری باید یک عدد ۵ رقمی باشد."
        inputMode="numeric"
        aria-describedby={error ? "feedback-error-desc" : undefined}
        aria-invalid={!!error}
      />
      <div>
        <label htmlFor="feedback-message" className={`block text-sm font-medium mb-1.5 ${labelClass}`}>
          انتقاد یا پیشنهاد شما
        </label>
        <textarea
          id="feedback-message"
          value={message}
          onChange={(e) => { onMessageChange(e.target.value); clearError(); }}
          placeholder="پیام خود را اینجا بنویسید..."
          rows={5}
          required
          className={`${textareaBaseClass} ${textareaThemeClass}`}
          aria-describedby={error ? "feedback-error-desc" : undefined}
          aria-invalid={!!error}
        />
      </div>
      {error && <p id="feedback-error-desc" className="sr-only">{error}</p>}
      <Button
        type="submit"
        variant={buttonVariant}
        size="lg"
        fullWidth
        className="!py-3 text-base"
        disabled={isLoading}
      >
        {isLoading ? 'در حال ارسال...' : 'ارسال پیام'}
      </Button>
    </form>
  );
};

export default FeedbackForm;
