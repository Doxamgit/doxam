
import React, { useState, ReactNode } from 'react';
import ChevronDownIcon from './ChevronDownIcon';
import ChevronUpIcon from './ChevronUpIcon';

interface UserPanelSectionProps {
  icon: ReactNode;
  label: string;
  onClick?: () => void;
  children?: ReactNode;
  isCollapsible?: boolean;
  initialExpanded?: boolean;
  infoText?: string; // Optional text to display on the right of the main label
}

const UserPanelSection: React.FC<UserPanelSectionProps> = ({
  icon,
  label,
  onClick,
  children,
  isCollapsible = false,
  initialExpanded = false,
  infoText,
}) => {
  const [isExpanded, setIsExpanded] = useState(initialExpanded);

  const handleToggle = () => {
    if (isCollapsible) {
      setIsExpanded(!isExpanded);
    }
    // Always call onClick if provided, regardless of collapsible state
    // This allows it to act as a simple button if not collapsible
    if (onClick) {
      onClick();
    }
  };

  return (
    <div className="animate-fadeIn">
      <button
        type="button"
        onClick={handleToggle}
        className="w-full flex items-center justify-between p-3 bg-userPanel-cardBg hover:bg-userPanel-cardHoverBg rounded-full shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-userPanel-iconContainerBg focus:ring-offset-2 focus:ring-offset-userPanel-bgGradientTo"
        aria-expanded={isCollapsible ? isExpanded : undefined}
        aria-controls={isCollapsible ? `user-panel-content-${label.replace(/\s+/g, '-')}` : undefined}
      >
        <div className="flex items-center">
          <div className="w-10 h-10 bg-userPanel-iconContainerBg rounded-full flex items-center justify-center text-userPanel-iconColor shadow-sm shrink-0">
            {icon}
          </div>
          <span className="rtl:mr-4 ltr:ml-4 text-userPanel-textPrimary font-semibold text-md sm:text-lg truncate">
            {label}
          </span>
        </div>
        <div className="flex items-center">
          {infoText && ( // Display infoText if provided, typically when not collapsible
             <span className="rtl:ml-3 ltr:mr-3 text-userPanel-textSecondary text-xs sm:text-sm truncate max-w-[100px] sm:max-w-[150px]">
                {infoText}
            </span>
          )}
          {isCollapsible && (
            isExpanded ? (
              <ChevronUpIcon className="w-6 h-6 text-userPanel-textSecondary" />
            ) : (
              <ChevronDownIcon className="w-6 h-6 text-userPanel-textSecondary" />
            )
          )}
           {!isCollapsible && infoText === undefined && <div className="w-6 h-6"></div> /* Placeholder for alignment if no chevron and no infoText */}
        </div>
      </button>

      {isCollapsible && isExpanded && (
        <div
          id={`user-panel-content-${label.replace(/\s+/g, '-')}`}
          className="mt-3 p-4 sm:p-6 bg-userPanel-expandedContentBg rounded-2xl shadow-inner animate-fadeIn"
        >
          {children}
        </div>
      )}
    </div>
  );
};

export default UserPanelSection;
