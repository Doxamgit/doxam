import React, { useState } from 'react';
import type { ArchivedTournament } from '../types';
import Button from './Button';
import CrownIcon from './CrownIcon';
import ConfirmationModal from './ConfirmationModal'; // Import the new modal

interface TournamentHistoryPanelProps {
  archivedTournaments: ArchivedTournament[];
  isLoading: boolean;
  error: string | null;
  onDeleteTournament: (id: string) => void;
  onViewTournament?: (tournament: ArchivedTournament) => void; 
  onClose?: () => void;
  currentTheme?: 'default' | 'softUI';
}

const formatCompletedTimestamp = (timestamp: number) => {
  if (!timestamp) return "نامشخص";
  try {
    return new Date(timestamp).toLocaleString('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (e) {
    return "تاریخ نامعتبر";
  }
};


const TournamentHistoryPanel: React.FC<TournamentHistoryPanelProps> = ({
  archivedTournaments,
  isLoading,
  error,
  onDeleteTournament,
  onViewTournament,
  onClose,
  currentTheme = 'default'
}) => {
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [tournamentToDelete, setTournamentToDelete] = useState<ArchivedTournament | null>(null);

  const isSoftUI = currentTheme === 'softUI';

  const handleDeleteRequest = (tournament: ArchivedTournament) => {
    setTournamentToDelete(tournament);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteTournament = () => {
    if (tournamentToDelete) {
      onDeleteTournament(tournamentToDelete.id);
    }
    setIsDeleteModalOpen(false);
    setTournamentToDelete(null);
  };

  // Theme-specific classes
  const panelClasses = isSoftUI 
    ? "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder" 
    : "bg-surface-cosmicPanel rounded-xl shadow-2xl border border-border-cosmicDefault";
  const titleTextClass = isSoftUI ? "text-softUI-textPrimary" : "text-gradient-title";
  const loadingTextClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";
  const errorTextClass = isSoftUI ? "text-red-600" : "text-red-400";
  const errorBgClass = isSoftUI ? "bg-red-100 border-red-300" : "bg-red-900/50";
  const itemBgClass = isSoftUI ? "bg-softUI-bgPage rounded-lg shadow-sm border border-softUI-inputBorder" : "bg-brand-cosmicDarkBg rounded-lg shadow-lg border border-border-cosmicDefault/70";
  const itemTitleClass = isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange";
  const itemDetailsClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";
  const itemMetaClass = isSoftUI ? "text-softUI-textSecondary/70" : "text-text-cosmicSecondary/70";
  const buttonSecondaryVariant = isSoftUI ? "custom" : "cosmicDarkSecondary";
  const softUIButtonSecondaryClass = isSoftUI ? `!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder` : '';
  const crownColorClass = isSoftUI ? "text-softUI-primary" : "text-yellow-400";

  if (isLoading) {
    return <div className={`p-8 text-center ${loadingTextClass}`}>در حال بارگذاری تاریخچه تورنومنت‌ها...</div>;
  }

  return (
    <>
      <div className={`max-w-4xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
        <div className="flex justify-between items-center mb-8">
          <h2 className={`text-3xl font-bold ${titleTextClass}`}>تاریخچه تورنومنت‌ها</h2>
          {onClose && 
              <Button 
                  onClick={onClose} 
                  variant={buttonSecondaryVariant as any} 
                  size="sm" 
                  className={`!rounded-lg ${softUIButtonSecondaryClass}`}
              >
                  بازگشت
              </Button>
          }
        </div>

        {error && <p className={`p-3 rounded-lg mb-4 text-sm ${errorTextClass} ${errorBgClass}`}>{error}</p>}

        {archivedTournaments.length === 0 && !error && (
          <p className={`${loadingTextClass} text-center py-10`}>هیچ تورنومنتی در تاریخچه ذخیره نشده است.</p>
        )}

        {archivedTournaments.length > 0 && (
          <div className={`space-y-6 max-h-[70vh] overflow-y-auto pr-2 ${isSoftUI ? 'soft-ui-theme-active' : 'custom-scrollbar'}`}>
            {archivedTournaments.map(tournament => (
              <div key={tournament.id} className={`p-5 animate-fadeIn ${itemBgClass}`}>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3">
                  <h3 className={`text-xl font-bold mb-2 sm:mb-0 ${itemTitleClass}`}>{tournament.customName}</h3>
                  <Button 
                      onClick={() => handleDeleteRequest(tournament)} 
                      variant={isSoftUI ? "custom" : "danger"} 
                      size="sm"
                      aria-label={`حذف تورنومنت: ${tournament.customName}`}
                      className={`!rounded-md ${isSoftUI ? '!bg-red-100 !text-red-600 !border-red-300 hover:!bg-red-200' : ''}`}
                  >
                    حذف از تاریخچه
                  </Button>
                </div>
                <div className={`text-sm space-y-1 ${itemDetailsClass}`}>
                  <p>
                    <span className="font-semibold">تاریخ برگزاری: </span> 
                    {new Date(tournament.eventDateTime).toLocaleString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                  <p className="flex items-center">
                    <span className="font-semibold mr-1 rtl:ml-1">قهرمان: </span>
                    <CrownIcon className={`${crownColorClass} w-4 h-4 mr-1 rtl:ml-1`} />
                    {tournament.finalWinner?.name || 'نامشخص'}
                  </p>
                  <p>
                    <span className="font-semibold">تعداد شرکت‌کنندگان: </span>
                    {tournament.initialParticipantCount}
                  </p>
                </div>
                <p className={`text-xs mt-3 text-left ${itemMetaClass}`}>
                  تکمیل شده در: {formatCompletedTimestamp(tournament.completedTimestamp)}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
      {tournamentToDelete && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setTournamentToDelete(null);
          }}
          onConfirm={confirmDeleteTournament}
          title="تأیید حذف تورنومنت"
          message={
            <p>
              آیا از حذف تورنومنت <strong className={isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange"}>{tournamentToDelete.customName}</strong> از تاریخچه مطمئن هستید؟ این عمل غیرقابل بازگشت است.
            </p>
          }
          theme={currentTheme === 'softUI' ? 'softUI' : undefined}
        />
      )}
    </>
  );
};

export default TournamentHistoryPanel;
