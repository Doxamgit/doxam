
import React, { useState } from 'react';
import Button from './Button';
import ChevronDownIcon from './ChevronDownIcon'; 
import ChevronUpIcon from './ChevronUpIcon';
import ArrowLeftIcon from './ArrowLeftIcon'; // For standalone page back button example

interface RulesDisplaySectionProps {
  rulesContent: string;
  isLoadingRules: boolean;
  rulesError: string | null;
  theme?: 'default' | 'home' | 'autumnGrays' | 'userPanelContent';
  isStandalonePage?: boolean; // New prop
}

const RulesDisplaySection: React.FC<RulesDisplaySectionProps> = ({ 
  rulesContent, 
  isLoadingRules, 
  rulesError, 
  theme = 'default',
  isStandalonePage = false // Default to false
}) => {
  // If standalone, it's always "expanded" in terms of content visibility.
  // The expand/collapse UI is hidden for standalone pages.
  const [isExpanded, setIsExpanded] = useState(isStandalonePage || (theme === 'userPanelContent' ? false : true));

  const isHomeTheme = theme === 'home';
  const isAutumnTheme = theme === 'autumnGrays';
  const isUserPanelContentTheme = theme === 'userPanelContent';

  let baseContainerClass = "w-full max-w-2xl mx-auto mt-10 mb-8 p-6 rounded-xl shadow-xl animate-fadeIn transition-all duration-300 hover:shadow-2xl";
  if (isUserPanelContentTheme || isStandalonePage) {
    baseContainerClass = "w-full animate-fadeIn p-1"; // Simplified for user panel content or standalone
  }
  let themeContainerClass = "";
  let titleClass = "";
  let textClass = "";
  let errorTextClass = "";
  let errorBorderClass = "";
  let buttonVariant: any = 'artisticOutline';
  let buttonCustomClass = "!rounded-full !px-3 !py-1.5";
  let buttonFocusRingOffset = 'focus:ring-offset-surface-artisticTealPoemPanel';
  let contentBorderClass = "border-brand-artisticGoldAccent/30";
  let lightningTapButton = false;
  let showHeader = !isUserPanelContentTheme && !isStandalonePage; // Hide header if user panel content OR standalone

  if (isHomeTheme) {
    themeContainerClass = "bg-brand-home-cardBg border border-brand-home-cardBorder hover:border-brand-home-cardBorder/70";
    titleClass = "text-brand-home-cardHeaderText";
    textClass = "text-brand-home-textSecondary";
    errorTextClass = "text-red-400";
    errorBorderClass = "border-red-500/50";
    buttonVariant = 'custom';
    buttonCustomClass = `text-brand-home-buttonSecondaryText border border-brand-home-buttonSecondaryBorder hover:bg-brand-home-buttonSecondaryBgHover hover:border-brand-home-buttonSecondaryBorderHover focus:ring-brand-home-accentGlow !rounded-full !px-3 !py-1.5`;
    buttonFocusRingOffset = 'focus:ring-offset-brand-home-cardBg';
    contentBorderClass = "border-brand-home-cardBorder/50";
  } else if (isAutumnTheme) {
    themeContainerClass = "bg-autumnGrays-cardBg border border-autumnGrays-border hover:border-opacity-80";
    titleClass = "text-autumnGrays-textPrimary";
    textClass = "text-autumnGrays-textSecondary";
    errorTextClass = "text-red-200"; 
    errorBorderClass = "border-red-400/50";
    buttonVariant = 'autumnSecondary';
    buttonCustomClass = `!rounded-full !px-3 !py-1.5`;
    buttonFocusRingOffset = 'focus:ring-offset-autumnGrays-cardBg';
    contentBorderClass = "border-autumnGrays-border/70";
    lightningTapButton = true;
  } else if (isUserPanelContentTheme || isStandalonePage) {
    themeContainerClass = ""; 
    titleClass = "text-userPanel-textPrimary"; 
    
    if (isUserPanelContentTheme) { // Correctly use the boolean
        textClass = "text-userPanel-textPrimary";
        errorTextClass = "text-red-300";
        contentBorderClass = "border-userPanel-iconContainerBg/30";
    } else { // Generic standalone styling (isStandalonePage is true, isUserPanelContentTheme is false)
        textClass = "text-gray-800"; 
        errorTextClass = "text-red-500";
        contentBorderClass = "border-gray-300";
    }
    buttonVariant = 'custom'; 
    buttonCustomClass = ''; 
  }
   else { // Default (Cosmic-Artistic)
    themeContainerClass = "bg-surface-artisticTealPoemPanel border border-brand-artisticGoldAccent/40 hover:border-brand-artisticGoldAccent/60";
    titleClass = "text-brand-artisticGoldAccent";
    textClass = "text-text-onArtisticTealSecondary";
    errorTextClass = "text-red-300";
    errorBorderClass = "border-red-500/60";
  }


  if (isLoadingRules) {
    return (
      <div className={`${baseContainerClass} ${themeContainerClass}`}>
        {showHeader && <h3 className={`text-2xl font-semibold mb-4 text-center ${titleClass}`}>قوانین آکو</h3>}
        <p className={`${textClass} text-center`}>در حال بارگذاری قوانین...</p>
      </div>
    );
  }
  
  if (rulesError && !isUserPanelContentTheme && !isStandalonePage) { 
     return (
        <div className="my-12 animate-fadeIn">
            <h2 id="news-heading" className={`text-3xl sm:text-4xl font-bold text-center mb-10 ${titleClass}`}>قوانین آکو</h2>
            <p className={`${errorTextClass} text-center py-4`}>خطا در بارگیری قوانین: {rulesError}</p>
        </div>
     );
  }

  // For userPanelContent or standalone page, always display content without internal toggle.
  if (isUserPanelContentTheme || isStandalonePage) {
    return (
      <div className={`${baseContainerClass} ${themeContainerClass}`}>
         {rulesError && <p className={`${errorTextClass} text-center py-2 text-sm`}>خطا: {rulesError}</p>}
         {rulesContent && !rulesError ? (
            <div 
              className={`prose prose-sm sm:prose-base max-w-none ${textClass} whitespace-pre-wrap leading-relaxed text-xs sm:text-sm`}
              dangerouslySetInnerHTML={{ __html: rulesContent.replace(/\n/g, '<br />') }} 
            />
          ) : (
            !rulesError && <p className={`${textClass} text-center italic`}>هنوز قانونی ثبت نشده است.</p>
          )}
      </div>
    );
  }

  // Original component with expand/collapse for non-standalone, non-userPanelContent views
  return (
    <div className={`${baseContainerClass} ${themeContainerClass}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className={`text-2xl font-semibold ${titleClass}`}>قوانین آکو</h3>
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          variant={buttonVariant}
          size="sm"
          className={`${buttonCustomClass} ${buttonFocusRingOffset}`}
          aria-expanded={isExpanded}
          aria-controls="rules-content-area"
          lightningTap={lightningTapButton}
        >
          {isExpanded ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
          <span className="mr-2 rtl:ml-2 rtl:mr-0">{isExpanded ? 'پنهان کردن' : 'مشاهده قوانین'}</span>
        </Button>
      </div>
      
      {isExpanded && (
        <div id="rules-content-area" className={`mt-4 pt-4 border-t ${contentBorderClass} animate-fadeIn`}>
          {rulesContent ? (
            <div 
              className={`prose prose-sm sm:prose-base max-w-none ${textClass} whitespace-pre-wrap leading-relaxed`}
              dangerouslySetInnerHTML={{ __html: rulesContent.replace(/\n/g, '<br />') }} 
            />
          ) : (
            <p className={`${textClass} text-center italic`}>هنوز قانونی ثبت نشده است.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default RulesDisplaySection;
