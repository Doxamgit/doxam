import React, { useState, useEffect } from 'react';
import type { FeedbackEntry } from '../types';
import Button from './Button';
import EyeOpenIcon from './EyeOpenIcon';
import EyeClosedIcon from './EyeClosedIcon';
import ArchiveBoxIcon from './ArchiveBoxIcon'; 
import TrashIcon from './TrashIcon';
import InboxArrowDownIcon from './InboxArrowDownIcon'; 
import ConfirmationModal from './ConfirmationModal'; // Import the new modal

interface AdminFeedbacksPanelProps {
  feedbacks: FeedbackEntry[];
  isLoading: boolean;
  error: string | null;
  onToggleRead: (id: string) => void;
  onToggleArchive: (id: string) => void;
  onDelete: (id: string) => boolean;
  onClose?: () => void;
  clearError: () => void;
  currentTheme?: 'softUI'; 
}

const AdminFeedbacksPanel: React.FC<AdminFeedbacksPanelProps> = ({
  feedbacks,
  isLoading,
  error,
  onToggleRead,
  onToggleArchive,
  onDelete,
  onClose,
  clearError,
  currentTheme = 'softUI' 
}) => {
  const [showArchived, setShowArchived] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [feedbackToDelete, setFeedbackToDelete] = useState<FeedbackEntry | null>(null);


  useEffect(() => {
    if (error) {
      setLocalError(error);
    }
  }, [error]);
  
  const handleDeleteRequest = (feedbackItem: FeedbackEntry) => {
    setFeedbackToDelete(feedbackItem);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteFeedback = () => {
    if (feedbackToDelete) {
      clearError();
      setLocalError(null);
      onDelete(feedbackToDelete.id);
    }
    setIsDeleteModalOpen(false);
    setFeedbackToDelete(null);
  };


  const filteredFeedbacks = feedbacks.filter(fb => showArchived ? true : !fb.isArchived);

  const panelClasses = "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder";
  const titleTextClass = "text-softUI-textPrimary";
  const titleIconClass = "text-softUI-primary";
  const itemBgClass = "bg-softUI-bgPage rounded-lg shadow-sm border border-softUI-inputBorder";
  const itemDetailsClass = "text-softUI-textSecondary text-xs";
  const itemMessageClass = "text-softUI-textPrimary text-sm whitespace-pre-wrap leading-relaxed";
  const unreadIndicatorClass = "w-3 h-3 bg-blue-500 rounded-full absolute top-2 right-2 rtl:left-2 rtl:right-auto";
  const buttonSecondaryVariant = "custom";
  const softUIButtonSecondaryClass = "!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder";
  const errorTextClass = "text-red-600";
  const errorBgClass = "bg-red-100 border-red-300";
  const loadingTextClass = "text-softUI-textSecondary";
  const filterButtonClass = `px-3 py-1.5 text-xs rounded-md border ${softUIButtonSecondaryClass}`;


  return (
    <>
      <div className={`max-w-4xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
        <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-8 gap-4">
          <h2 className={`text-2xl sm:text-3xl font-bold flex items-center ${titleTextClass}`}>
            <InboxArrowDownIcon className={`w-7 h-7 sm:w-8 sm:h-8 rtl:ml-3 ltr:mr-3 ${titleIconClass}`} />
            صندوق پیشنهادات و انتقادات
          </h2>
          {onClose && (
            <Button onClick={onClose} variant={buttonSecondaryVariant as any} size="sm" className={`!rounded-lg ${softUIButtonSecondaryClass} self-start sm:self-center`}>
              بازگشت
            </Button>
          )}
        </div>

        {localError && <p className={`p-3 rounded-lg mb-4 text-sm ${errorTextClass} ${errorBgClass}`}>{localError}</p>}

        <div className="mb-4 flex justify-end">
          <Button onClick={() => setShowArchived(!showArchived)} className={filterButtonClass}>
            {showArchived ? "پنهان کردن آرشیو شده‌ها" : "نمایش آرشیو شده‌ها"}
          </Button>
        </div>

        {isLoading && <p className={`${loadingTextClass} text-center py-6`}>در حال بارگذاری بازخوردها...</p>}

        {!isLoading && filteredFeedbacks.length === 0 && (
          <p className={`${loadingTextClass} text-center py-10`}>
            {showArchived ? "هیچ بازخورد آرشیو شده‌ای وجود ندارد." : "هیچ بازخورد جدیدی یافت نشد."}
          </p>
        )}

        {!isLoading && filteredFeedbacks.length > 0 && (
          <div className={`space-y-4 max-h-[70vh] overflow-y-auto pr-2 soft-ui-theme-active`}>
            {filteredFeedbacks.map(fb => (
              <div key={fb.id} className={`p-4 relative ${itemBgClass} ${fb.isArchived ? 'opacity-70' : ''}`}>
                {!fb.isRead && !fb.isArchived && <div className={unreadIndicatorClass} title="خوانده نشده"></div>}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-2">
                  <div className="mb-2 sm:mb-0">
                    <p className={`${itemDetailsClass} font-semibold`}>
                      پلاتو: <span className="font-mono text-softUI-primary">{fb.platoId}</span>
                    </p>
                    <p className={`${itemDetailsClass}`}>
                      کد کاربری: <span className="font-mono text-softUI-primary">{fb.userCode}</span>
                    </p>
                  </div>
                  <p className={`${itemDetailsClass} text-xs`}>
                    تاریخ: {new Date(fb.timestamp).toLocaleString('fa-IR')}
                  </p>
                </div>
                <p className={`${itemMessageClass} p-2 bg-white rounded border border-softUI-inputBorder my-2`}>{fb.message}</p>
                <div className="flex flex-wrap gap-2 mt-3 pt-2 border-t border-softUI-inputBorder/70">
                  <Button onClick={() => onToggleRead(fb.id)} size="sm" variant="custom" className={`${filterButtonClass} !text-xs`} title={fb.isRead ? "علامت‌گذاری به عنوان خوانده نشده" : "علامت‌گذاری به عنوان خوانده شده"}>
                    {fb.isRead ? <EyeClosedIcon className="w-4 h-4 rtl:ml-1 ltr:mr-1" /> : <EyeOpenIcon className="w-4 h-4 rtl:ml-1 ltr:mr-1" />}
                    {fb.isRead ? "خوانده نشده" : "خوانده شده"}
                  </Button>
                  <Button onClick={() => onToggleArchive(fb.id)} size="sm" variant="custom" className={`${filterButtonClass} !text-xs`} title={fb.isArchived ? "بازگردانی از آرشیو" : "آرشیو کردن"}>
                    <ArchiveBoxIcon className="w-4 h-4 rtl:ml-1 ltr:mr-1" />
                    {fb.isArchived ? "بازگردانی" : "آرشیو"}
                  </Button>
                  <Button onClick={() => handleDeleteRequest(fb)} size="sm" variant="custom" className={`${filterButtonClass} !bg-red-100 !text-red-600 hover:!bg-red-200 !border-red-300 !text-xs`} title="حذف بازخورد">
                    <TrashIcon className="w-4 h-4 rtl:ml-1 ltr:mr-1" />
                    حذف
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {feedbackToDelete && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setFeedbackToDelete(null);
          }}
          onConfirm={confirmDeleteFeedback}
          title="تأیید حذف بازخورد"
          message={
            <p>
              آیا از حذف بازخورد کاربر <strong className="text-softUI-primary">{feedbackToDelete.platoId}</strong> (کد: {feedbackToDelete.userCode}) مطمئن هستید؟
            </p>
          }
          theme="softUI"
        />
      )}
    </>
  );
};

export default AdminFeedbacksPanel;
