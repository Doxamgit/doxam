
import React from 'react';

const TrophyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-4.5A3.375 3.375 0 0012.75 9.75H11.25A3.375 3.375 0 007.5 13.125V18.75m9 0h1.5M4.5 18.75h1.5m0-13.5H18A2.25 2.25 0 0120.25 7.5v1.5A2.25 2.25 0 0118 11.25H6A2.25 2.25 0 013.75 9V7.5A2.25 2.25 0 016 5.25m0 0V3.75m0 1.5H3.75m0 0V3.75" />
  </svg>
);

export default TrophyIcon;
