
import React, { useState, useEffect } from 'react';
import Button from './Button';
import Input from './Input'; 
import EyeOpenIcon from './EyeOpenIcon';
import EyeClosedIcon from './EyeClosedIcon';
import UserOutlineIcon from './UserOutlineIcon';
import LockOutlineIcon from './LockOutlineIcon';
import LoginUserIcon from './LoginUserIcon'; // For softUI
import LoginPasswordIcon from './LoginPasswordIcon'; // For softUI


interface AdminCredentialsPanelProps {
  onChangeCredentials: (currentUsername: string, currentPassword: string, newUsername: string, newPassword: string) => boolean;
  authError: string | null;
  clearAuthError: () => void;
  onClose?: () => void;
  currentAdminUsername: string; 
  currentTheme?: 'default' | 'softUI';
}

const AdminCredentialsPanel: React.FC<AdminCredentialsPanelProps> = ({
  onChangeCredentials,
  authError,
  clearAuthError,
  onClose,
  currentAdminUsername,
  currentTheme = 'default'
}) => {
  const [stage, setStage] = useState<'verify' | 'change'>('verify');
  
  const [currentUsername, setCurrentUsername] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);

  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmNewPassword, setShowConfirmNewPassword] = useState(false);

  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const isSoftUI = currentTheme === 'softUI';

  useEffect(() => {
    // setCurrentUsername(currentAdminUsername); 
  }, [currentAdminUsername]);

  useEffect(() => {
    if (authError) {
      setLocalError(authError);
    }
  }, [authError]);

  const handleVerificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError();
    setLocalError(null);
    setSuccessMessage(null);

    if (!currentUsername.trim() || !currentPassword.trim()) {
      setLocalError("نام کاربری و رمز عبور فعلی الزامی است.");
      return;
    }
    setStage('change');
    setLocalError(null); 
  };

  const handleSaveChanges = (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError();
    setLocalError(null);
    setSuccessMessage(null);

    if (!newUsername.trim() || !newPassword.trim() || !confirmNewPassword.trim()) {
      setLocalError("تمام فیلدهای مشخصات جدید الزامی هستند.");
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setLocalError("رمز عبور جدید و تکرار آن مطابقت ندارند.");
      return;
    }

    const success = onChangeCredentials(currentUsername, currentPassword, newUsername, confirmNewPassword);
    if (success) {
      setSuccessMessage("مشخصات ورود با موفقیت تغییر کرد!");
      setCurrentUsername('');
      setCurrentPassword('');
      setNewUsername('');
      setNewPassword('');
      setConfirmNewPassword('');
      setStage('verify'); 
      setTimeout(() => setSuccessMessage(null), 4000);
    } 
  };
  
  // Theme-specific classes
  const panelClasses = isSoftUI 
    ? "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder" 
    : "bg-surface-cosmicPanel rounded-xl shadow-2xl border border-border-cosmicDefault";
  const titleTextClass = isSoftUI ? "text-softUI-textPrimary" : "text-gradient-title";
  const sectionTitleClass = isSoftUI ? "text-softUI-textPrimary" : "text-text-cosmicPrimary";
  const helpTextClass = isSoftUI ? "text-softUI-textSecondary text-xs" : "text-text-cosmicSecondary text-xs";
  const inputTheme = isSoftUI ? "softUI" : "default";
  const buttonPrimaryVariant = isSoftUI ? "softUIPrimary" : "cosmicAccent";
  const buttonSecondaryVariant = isSoftUI ? "custom" : "cosmicDarkSecondary";
  const softUIButtonSecondaryClass = isSoftUI ? `!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder` : '';
  const errorTextClass = isSoftUI ? "text-red-600" : "text-red-400";
  const errorBgClass = isSoftUI ? "bg-red-100 border-red-300" : "bg-red-900/50";
  const successTextClass = isSoftUI ? "text-green-600" : "text-green-400";
  const successBgClass = isSoftUI ? "bg-green-100 border-green-300" : "bg-green-800/50";
  
  // Cosmic theme specific input styling
  const cosmicInputWrapperClass = "relative flex items-center";
  const cosmicIconWrapperClass = "absolute rtl:right-0 ltr:left-0 top-1/2 -translate-y-1/2 flex items-center justify-center w-11 h-11 bg-surface-cosmicInput rounded-lg shadow-md rtl:mr-1 ltr:ml-1 border border-border-cosmicDefault";
  const cosmicInputClass = "w-full rtl:pr-14 ltr:pl-14 rtl:pl-10 ltr:pr-10 py-3 bg-surface-cosmicInput border border-border-cosmicDefault rounded-lg text-text-cosmicPrimary placeholder-text-cosmicPlaceholder focus:ring-2 focus:ring-border-cosmicFocus focus:outline-none shadow-sm transition-all";
  const cosmicToggleBtnClass = "absolute rtl:left-0 ltr:right-0 top-1/2 -translate-y-1/2 rtl:ml-2 ltr:mr-2 p-1 text-text-cosmicPlaceholder hover:text-brand-cosmicAccentOrange focus:outline-none rounded-full focus:ring-1 focus:ring-border-cosmicFocus";

  const softUIPasswordToggleBtnClass = "absolute rtl:left-3 ltr:right-3 top-1/2 transform -translate-y-1/2 p-1 text-softUI-inputPlaceholder hover:text-softUI-primary focus:outline-none rounded-full";


  return (
    <div className={`max-w-lg mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
      <div className="flex justify-between items-center mb-8">
        <h2 className={`text-2xl md:text-3xl font-bold ${titleTextClass}`}>تغییر مشخصات ورود ادمین</h2>
        {onClose && 
            <Button 
                onClick={onClose} 
                variant={buttonSecondaryVariant as any} 
                size="sm" 
                className={`!rounded-lg ${softUIButtonSecondaryClass}`}
            >
                بازگشت
            </Button>
        }
      </div>

      {localError && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
      {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

      {stage === 'verify' && (
        <form onSubmit={handleVerificationSubmit} className="space-y-6">
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-3`}>۱. تأیید هویت فعلی</h3>
          
          {isSoftUI ? (
            <>
              <Input
                theme="softUI"
                icon={<LoginUserIcon className="w-5 h-5 text-softUI-inputIcon" />}
                type="text"
                id="current-username"
                value={currentUsername}
                onChange={(e) => {setCurrentUsername(e.target.value); clearAuthError(); setLocalError(null);}}
                placeholder="نام کاربری فعلی"
                required
              />
              <div className="relative">
                <Input
                  theme="softUI"
                  icon={<LoginPasswordIcon className="w-5 h-5 text-softUI-inputIcon" />}
                  type={showCurrentPassword ? "text" : "password"}
                  id="current-password"
                  value={currentPassword}
                  onChange={(e) => {setCurrentPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="رمز عبور فعلی"
                  required
                />
                <button type="button" onClick={() => setShowCurrentPassword(!showCurrentPassword)} className={softUIPasswordToggleBtnClass} aria-label="Toggle current password visibility">
                  {showCurrentPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
            </>
          ) : ( // Cosmic theme inputs
            <>
              <div className={cosmicInputWrapperClass}>
                <div className={cosmicIconWrapperClass}><UserOutlineIcon className="w-5 h-5 text-text-cosmicSecondary" /></div>
                <Input
                    type="text"
                    id="current-username"
                    value={currentUsername}
                    onChange={(e) => {setCurrentUsername(e.target.value); clearAuthError(); setLocalError(null);}}
                    placeholder="نام کاربری فعلی"
                    required
                    className={cosmicInputClass + " rtl:!pr-14 ltr:!pl-14 rtl:!pl-4 ltr:!pr-4"}
                  />
              </div>
              <div className={cosmicInputWrapperClass}>
                <div className={cosmicIconWrapperClass}><LockOutlineIcon className="w-5 h-5 text-text-cosmicSecondary" /></div>
                <Input
                  type={showCurrentPassword ? "text" : "password"}
                  id="current-password"
                  value={currentPassword}
                  onChange={(e) => {setCurrentPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="رمز عبور فعلی"
                  required
                  className={cosmicInputClass}
                />
                <button type="button" onClick={() => setShowCurrentPassword(!showCurrentPassword)} className={cosmicToggleBtnClass} aria-label="Toggle current password visibility">
                  {showCurrentPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
            </>
          )}
          <Button type="submit" variant={buttonPrimaryVariant as any} size="md" fullWidth className="!rounded-lg">
            تأیید و ادامه
          </Button>
        </form>
      )}

      {stage === 'change' && (
        <form onSubmit={handleSaveChanges} className="space-y-6">
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-1`}>۲. تنظیم مشخصات جدید</h3>
          <p className={`${helpTextClass} mb-3`}>نام کاربری فعلی برای تأیید: {currentUsername}</p>
          
          {isSoftUI ? (
            <>
              <Input
                theme="softUI"
                icon={<LoginUserIcon className="w-5 h-5 text-softUI-inputIcon" />}
                type="text"
                id="new-username"
                value={newUsername}
                onChange={(e) => {setNewUsername(e.target.value); clearAuthError(); setLocalError(null);}}
                placeholder="نام کاربری جدید"
                required
              />
              <div className="relative">
                <Input
                  theme="softUI"
                  icon={<LoginPasswordIcon className="w-5 h-5 text-softUI-inputIcon" />}
                  type={showNewPassword ? "text" : "password"}
                  id="new-password"
                  value={newPassword}
                  onChange={(e) => {setNewPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="رمز عبور جدید"
                  required
                />
                <button type="button" onClick={() => setShowNewPassword(!showNewPassword)} className={softUIPasswordToggleBtnClass} aria-label="Toggle new password visibility">
                  {showNewPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
              <div className="relative">
                 <Input
                  theme="softUI"
                  icon={<LoginPasswordIcon className="w-5 h-5 text-softUI-inputIcon" />}
                  type={showConfirmNewPassword ? "text" : "password"}
                  id="confirm-new-password"
                  value={confirmNewPassword}
                  onChange={(e) => {setConfirmNewPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="تکرار رمز عبور جدید"
                  required
                />
                <button type="button" onClick={() => setShowConfirmNewPassword(!showConfirmNewPassword)} className={softUIPasswordToggleBtnClass} aria-label="Toggle confirm new password visibility">
                  {showConfirmNewPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
            </>
          ) : ( // Cosmic Theme Inputs
            <>
              <div className={cosmicInputWrapperClass}>
                <div className={cosmicIconWrapperClass}><UserOutlineIcon className="w-5 h-5 text-text-cosmicSecondary" /></div>
                <Input
                    type="text"
                    id="new-username"
                    value={newUsername}
                    onChange={(e) => {setNewUsername(e.target.value); clearAuthError(); setLocalError(null);}}
                    placeholder="نام کاربری جدید"
                    required
                    className={cosmicInputClass + " rtl:!pr-14 ltr:!pl-14 rtl:!pl-4 ltr:!pr-4"}
                />
              </div>
              <div className={cosmicInputWrapperClass}>
                <div className={cosmicIconWrapperClass}><LockOutlineIcon className="w-5 h-5 text-text-cosmicSecondary" /></div>
                <Input
                  type={showNewPassword ? "text" : "password"}
                  id="new-password"
                  value={newPassword}
                  onChange={(e) => {setNewPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="رمز عبور جدید"
                  required
                  className={cosmicInputClass}
                />
                <button type="button" onClick={() => setShowNewPassword(!showNewPassword)} className={cosmicToggleBtnClass} aria-label="Toggle new password visibility">
                  {showNewPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
              <div className={cosmicInputWrapperClass}>
                <div className={cosmicIconWrapperClass}><LockOutlineIcon className="w-5 h-5 text-text-cosmicSecondary" /></div>
                <Input
                  type={showConfirmNewPassword ? "text" : "password"}
                  id="confirm-new-password"
                  value={confirmNewPassword}
                  onChange={(e) => {setConfirmNewPassword(e.target.value); clearAuthError(); setLocalError(null);}}
                  placeholder="تکرار رمز عبور جدید"
                  required
                  className={cosmicInputClass}
                />
                <button type="button" onClick={() => setShowConfirmNewPassword(!showConfirmNewPassword)} className={cosmicToggleBtnClass} aria-label="Toggle confirm new password visibility">
                  {showConfirmNewPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                </button>
              </div>
            </>
          )}

          <div className="flex space-x-3 rtl:space-x-reverse pt-2">
            <Button type="button" onClick={() => { setStage('verify'); clearAuthError(); setLocalError(null); setSuccessMessage(null); }} variant={buttonSecondaryVariant as any} size="md" className={`!rounded-lg flex-1 ${softUIButtonSecondaryClass}`}>
              بازگشت به تأیید
            </Button>
            <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg flex-1">
              ذخیره تغییرات
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default AdminCredentialsPanel;
