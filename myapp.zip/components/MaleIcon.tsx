import React from 'react';

const MaleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={`w-6 h-6 ${className}`} // Base size, can be overridden
    aria-hidden="true"
  >
    <path 
      d="M15.75 9A4.75 4.75 0 116.25 9a4.75 4.75 0 019.5 0zm0 0V3.75M15.75 3.75L12 3.75m3.75 0L20.25 3m-4.5 5.25H3.75" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
    />
  </svg>
);

export default MaleIcon;