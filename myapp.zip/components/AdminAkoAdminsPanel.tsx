
import React, { useState, useEffect } from 'react';
import type { AkoAdmin, AkoAdminRole, Gender } from '../types';
import Button from './Button';
import Input from './Input';
import Select from './Select'; // Uncommented Select import
import PencilIcon from './PencilIcon';
import TrashIcon from './TrashIcon';
import UsersGroupIcon from './UsersGroupIcon';
import StarRatingInput from './StarRatingInput'; 
import StarDisplay from './StarDisplay'; 
import GenderIconSelector from './GenderIconSelector'; // Import new component

interface AdminAkoAdminsPanelProps {
  akoAdmins: AkoAdmin[];
  onAddAdmin: (name: string, role: AkoAdminRole, details?: { platoUsername?: string; age?: number; gender?: Gender }) => boolean;
  onUpdateAdmin: (id: string, updatedData: Partial<AkoAdmin>) => boolean;
  onDeleteAdmin: (id: string) => boolean;
  akoAdminsError: string | null;
  clearAkoAdminsError: () => void;
  onClose?: () => void;
  currentTheme?: 'default' | 'softUI';
}

const AdminAkoAdminsPanel: React.FC<AdminAkoAdminsPanelProps> = ({
  akoAdmins,
  onAddAdmin,
  onUpdateAdmin,
  onDeleteAdmin,
  akoAdminsError,
  clearAkoAdminsError,
  onClose,
  currentTheme = 'default'
}) => {
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<AkoAdminRole>('user'); 
  const [newPlatoUsername, setNewPlatoUsername] = useState('');
  const [newAge, setNewAge] = useState('');
  const [newGender, setNewGender] = useState<Gender>('');
  
  const [editingAdmin, setEditingAdmin] = useState<AkoAdmin | null>(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<AkoAdminRole>('user');
  const [editPlatoUsername, setEditPlatoUsername] = useState('');
  const [editAge, setEditAge] = useState('');
  const [editGender, setEditGender] = useState<Gender>('');
  
  const [editProfessionalismScore, setEditProfessionalismScore] = useState(0);
  const [editActivityAvailabilityScore, setEditActivityAvailabilityScore] = useState(0);
  const [editProblemSolvingScore, setEditProblemSolvingScore] = useState(0);

  const [editRuleAdherenceScore, setEditRuleAdherenceScore] = useState(0);
  const [editRespectScore, setEditRespectScore] = useState(0);
  const [editContentAccuracyScore, setEditContentAccuracyScore] = useState(0);

  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [adminToDelete, setAdminToDelete] = useState<{ id: string; name: string } | null>(null);

  const isSoftUI = currentTheme === 'softUI';

  useEffect(() => {
    if (akoAdminsError) {
      setLocalError(akoAdminsError);
    }
  }, [akoAdminsError]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearAkoAdminsError();
    setLocalError(null);
    setSuccessMessage(null);

    const details: { platoUsername?: string; age?: number; gender?: Gender } = {};
    if (newRole === 'user') {
      if (!newPlatoUsername.trim()) {
        setLocalError("نام کاربری پلاتو برای نقش کاربر الزامی است.");
        return;
      }
      details.platoUsername = newPlatoUsername.trim();
      if (newAge) details.age = parseInt(newAge, 10);
      if (newGender) details.gender = newGender;
    }

    const success = onAddAdmin(newName, newRole, details);
    if (success) {
      setNewName('');
      setNewRole('user');
      setNewPlatoUsername('');
      setNewAge('');
      setNewGender('');
      setSuccessMessage("مورد با موفقیت اضافه شد!");
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdmin) return;
    clearAkoAdminsError();
    setLocalError(null);
    setSuccessMessage(null);
    
    const updateData: Partial<AkoAdmin> = {
      name: editName,
      role: editRole,
    };

    if (editRole === 'user') {
        if (!editPlatoUsername.trim()) {
            setLocalError("نام کاربری پلاتو برای نقش کاربر الزامی است.");
            return;
        }
      updateData.platoUsername = editPlatoUsername.trim();
      updateData.age = editAge ? parseInt(editAge, 10) : undefined;
      updateData.gender = editGender || undefined; 
      updateData.ruleAdherenceScore = editRuleAdherenceScore;
      updateData.respectScore = editRespectScore;
      updateData.contentAccuracyScore = editContentAccuracyScore;
    } else if (editRole === 'admin' || editRole === 'moderator') {
      updateData.professionalismScore = editProfessionalismScore;
      updateData.activityAvailabilityScore = editActivityAvailabilityScore;
      updateData.problemSolvingScore = editProblemSolvingScore;
    }

    const success = onUpdateAdmin(editingAdmin.id, updateData);
    if (success) {
      setEditingAdmin(null);
      setSuccessMessage("اطلاعات با موفقیت به‌روز شد!");
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };
  
  const startEdit = (admin: AkoAdmin) => {
    setEditingAdmin(admin);
    setEditName(admin.name);
    setEditRole(admin.role);
    setEditPlatoUsername(admin.platoUsername || '');
    setEditAge(admin.age?.toString() || '');
    setEditGender(admin.gender || '');
    
    if (admin.role === 'admin' || admin.role === 'moderator') {
      setEditProfessionalismScore(admin.professionalismScore ?? 0);
      setEditActivityAvailabilityScore(admin.activityAvailabilityScore ?? 0);
      setEditProblemSolvingScore(admin.problemSolvingScore ?? 0);
    } else if (admin.role === 'user') {
      setEditRuleAdherenceScore(admin.ruleAdherenceScore ?? 0);
      setEditRespectScore(admin.respectScore ?? 0);
      setEditContentAccuracyScore(admin.contentAccuracyScore ?? 0);
    } else { 
        setEditProfessionalismScore(0);
        setEditActivityAvailabilityScore(0);
        setEditProblemSolvingScore(0);
        setEditRuleAdherenceScore(0);
        setEditRespectScore(0);
        setEditContentAccuracyScore(0);
    }
    clearAkoAdminsError();
    setLocalError(null);
    setSuccessMessage(null);
  };

  const handleDeleteRequest = (id: string, name: string) => {
    setAdminToDelete({ id, name });
    setShowDeleteConfirmModal(true);
  };

  const confirmDelete = () => {
    if (adminToDelete) {
      clearAkoAdminsError();
      setLocalError(null);
      onDeleteAdmin(adminToDelete.id);
      setShowDeleteConfirmModal(false);
      setAdminToDelete(null);
    }
  };

  const roleOptionsList = [ 
    { value: 'owner', label: 'صاحب گروه' },
    { value: 'admin', label: 'ادمین گروه' },
    { value: 'moderator', label: 'ناظر گروه' },
    { value: 'user', label: 'کاربر گروه' },
  ];
  
  const panelClasses = isSoftUI 
    ? "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder" 
    : "bg-surface-cosmicPanel rounded-xl shadow-2xl border border-border-cosmicDefault";
  const titleTextClass = isSoftUI ? "text-softUI-textPrimary" : "text-gradient-title";
  const titleIconClass = isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange";
  const inputTheme = isSoftUI ? "softUI" : "default";
  const formBgClass = isSoftUI ? "bg-softUI-bgPage rounded-lg border border-softUI-inputBorder" : "bg-brand-cosmicDarkBg rounded-lg border border-border-cosmicDefault/70";
  const sectionTitleClass = isSoftUI ? "text-softUI-textPrimary" : "text-text-cosmicPrimary";
  const itemBgClass = isSoftUI ? "bg-softUI-bgPage rounded-lg shadow-sm border border-softUI-inputBorder" : "bg-brand-cosmicDarkBg rounded-lg shadow-md border border-border-cosmicDefault/50";
  const itemNameClass = isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange";
  const itemDetailsClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";
  const buttonPrimaryVariant = isSoftUI ? "softUIPrimary" : "cosmicAccent";
  const buttonSecondaryVariant = isSoftUI ? "custom" : "cosmicDarkSecondary";
  const softUIButtonSecondaryClass = isSoftUI ? `!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder` : '';
  const errorTextClass = isSoftUI ? "text-red-600" : "text-red-400";
  const errorBgClass = isSoftUI ? "bg-red-100 border-red-300" : "bg-red-900/50";
  const successTextClass = isSoftUI ? "text-green-600" : "text-green-400";
  const successBgClass = isSoftUI ? "bg-green-100 border-green-300" : "bg-green-800/50";
  const scoreLabelClass = isSoftUI ? "text-softUI-textSecondary text-sm" : "text-text-cosmicSecondary text-sm";
  const genderLabelClass = isSoftUI ? "text-softUI-textSecondary mb-1.5 text-sm" : "text-text-cosmicSecondary mb-1.5 text-sm";
  const modalBgClass = isSoftUI ? "bg-softUI-card" : "bg-surface-cosmicPanel";


  return (
    <div className={`max-w-4xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
      <div className="flex justify-between items-center mb-8">
        <h2 className={`text-3xl font-bold flex items-center ${titleTextClass}`}>
          <UsersGroupIcon className={`w-8 h-8 ml-3 rtl:mr-3 rtl:ml-0 ${titleIconClass}`} />
          مدیریت تیم آکو
        </h2>
        {onClose && 
            <Button 
                onClick={onClose} 
                variant={buttonSecondaryVariant as any} 
                size="sm" 
                className={`!rounded-lg ${softUIButtonSecondaryClass}`}
            >
                بازگشت
            </Button>
        }
      </div>

      {localError && <p className={`p-3 rounded-lg mb-4 text-sm ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
      {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

      {editingAdmin ? (
        <form onSubmit={handleEditSubmit} className={`space-y-5 mb-10 p-6 ${formBgClass}`}>
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>ویرایش: {editingAdmin.name}</h3>
          <Input
            label="نام واقعی"
            id="edit-admin-name"
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            required
            theme={inputTheme}
          />
          <Select
            label="نقش"
            id="edit-admin-role"
            value={editRole}
            onChange={(e) => {
              const newR = e.target.value as AkoAdminRole;
              setEditRole(newR);
                setEditProfessionalismScore(0);
                setEditActivityAvailabilityScore(0);
                setEditProblemSolvingScore(0);
                setEditRuleAdherenceScore(0);
                setEditRespectScore(0);
                setEditContentAccuracyScore(0);
                if (newR !== 'user') {
                    setEditPlatoUsername('');
                    setEditAge('');
                    setEditGender('');
                }
            }}
            options={roleOptionsList}
            theme={inputTheme as 'default' | 'softUI' | 'userPanelInput' | 'autumnGrays' | 'versace'}
          />

          {editRole === 'user' && (
            <>
              <Input
                label="نام کاربری پلاتو"
                id="edit-plato-username"
                value={editPlatoUsername}
                onChange={(e) => setEditPlatoUsername(e.target.value)}
                required
                theme={inputTheme}
              />
              <div className="grid grid-cols-2 gap-4 items-start">
                <Input
                    label="سن"
                    id="edit-age"
                    type="number"
                    value={editAge}
                    onChange={(e) => setEditAge(e.target.value)}
                    theme={inputTheme}
                />
                <div>
                    <label htmlFor="edit-gender-selector" className={`block ${genderLabelClass}`}>جنسیت</label>
                    <GenderIconSelector
                        value={editGender}
                        onChange={setEditGender}
                        theme={isSoftUI ? 'softUI' : 'default'} 
                        id="edit-gender-selector"
                    />
                </div>
              </div>
              <h4 className={`text-md font-semibold pt-2 ${scoreLabelClass}`}>امتیازات کاربر:</h4>
              <StarRatingInput
                label="رعایت قوانین گروه (0-5)"
                rating={editRuleAdherenceScore}
                setRating={setEditRuleAdherenceScore}
                theme={currentTheme}
              />
              <StarRatingInput
                label="میزان احترام به ادمین ها و کاربرها (0-5)"
                rating={editRespectScore}
                setRating={setEditRespectScore}
                 theme={currentTheme}
              />
              <StarRatingInput
                label="دقت در ارسال مطالب در گپ (0-5)"
                rating={editContentAccuracyScore}
                setRating={setEditContentAccuracyScore}
                 theme={currentTheme}
              />
            </>
          )}

          {(editRole === 'admin' || editRole === 'moderator') && (
            <>
             <h4 className={`text-md font-semibold pt-2 ${scoreLabelClass}`}>امتیازات ادمین/ناظر:</h4>
              <StarRatingInput
                label="رفتار محترمانه و حرفه ای (0-5)"
                rating={editProfessionalismScore}
                setRating={setEditProfessionalismScore}
                 theme={currentTheme}
              />
              <StarRatingInput
                label="میزان فعالیت و در دسترس بودن (0-5)"
                rating={editActivityAvailabilityScore}
                setRating={setEditActivityAvailabilityScore}
                 theme={currentTheme}
              />
              <StarRatingInput
                label="توانایی رفع مشکل (0-5)"
                rating={editProblemSolvingScore}
                setRating={setEditProblemSolvingScore}
                 theme={currentTheme}
              />
            </>
          )}

          <div className="flex space-x-3 rtl:space-x-reverse pt-3">
            <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">ذخیره تغییرات</Button>
            <Button type="button" onClick={() => setEditingAdmin(null)} variant={buttonSecondaryVariant as any} size="md" className={`!rounded-lg ${softUIButtonSecondaryClass}`}>انصراف</Button>
          </div>
        </form>
      ) : (
        <form onSubmit={handleAddSubmit} className={`space-y-5 mb-10 p-6 ${formBgClass}`}>
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>افزودن عضو جدید</h3>
          <Input
            label="نام واقعی"
            id="new-admin-name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="نام کامل"
            required
            theme={inputTheme}
          />
          <Select
            label="نقش"
            id="new-admin-role"
            value={newRole}
            onChange={(e) => setNewRole(e.target.value as AkoAdminRole)}
            options={roleOptionsList}
            theme={inputTheme as 'default' | 'softUI' | 'userPanelInput' | 'autumnGrays' | 'versace'}
          />
          {newRole === 'user' && (
            <>
              <Input
                label="نام کاربری پلاتو"
                id="new-plato-username"
                value={newPlatoUsername}
                onChange={(e) => setNewPlatoUsername(e.target.value)}
                placeholder="نام کاربری در پلاتو"
                required
                theme={inputTheme}
              />
              <div className="grid grid-cols-2 gap-4 items-start">
                <Input
                    label="سن"
                    id="new-age"
                    type="number"
                    value={newAge}
                    onChange={(e) => setNewAge(e.target.value)}
                    placeholder="مثال: 25"
                    theme={inputTheme}
                />
                 <div>
                    <label htmlFor="new-gender-selector" className={`block ${genderLabelClass}`}>جنسیت</label>
                    <GenderIconSelector
                        value={newGender}
                        onChange={setNewGender}
                        theme={isSoftUI ? 'softUI' : 'default'} 
                        id="new-gender-selector"
                    />
                </div>
              </div>
            </>
          )}
          <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">افزودن عضو</Button>
        </form>
      )}

      <h3 className={`text-2xl font-semibold ${sectionTitleClass} mb-6 mt-8 pt-6 border-t ${isSoftUI ? 'border-softUI-inputBorder' : 'border-border-cosmicDefault/70'}`}>لیست اعضای تیم</h3>
      {akoAdmins.length === 0 ? (
        <p className={`${itemDetailsClass} text-center py-4`}>هنوز عضوی ثبت نشده است.</p>
      ) : (
        <div className={`space-y-4 max-h-[50vh] overflow-y-auto pr-2 ${isSoftUI ? 'soft-ui-theme-active' : 'custom-scrollbar'}`}>
          {akoAdmins.map(admin => (
            <div key={admin.id} className={`p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 ${itemBgClass}`}>
              <div className="flex-grow">
                <p className={`text-lg font-semibold ${itemNameClass}`}>{admin.name}</p>
                <p className={`text-sm ${itemDetailsClass}`}>
                  نقش: {roleOptionsList.find(r => r.value === admin.role)?.label || admin.role}
                </p>
                {admin.role === 'user' && (
                    <div className={`text-xs mt-1 ${itemDetailsClass}/80`}>
                        {admin.platoUsername && <p>پلاتو: {admin.platoUsername}</p>}
                        {admin.age && <p>سن: {admin.age}</p>}
                        {admin.gender && <p>جنسیت: { 
                            admin.gender === 'male' ? 'مرد' : 
                            admin.gender === 'female' ? 'زن' : 
                            admin.gender === 'other' ? 'دیگر' : 
                            'ترجیح می‌دهم نگویم'
                        }</p>}
                    </div>
                )}

                {(admin.role === 'admin' || admin.role === 'moderator') && admin.averageRating !== undefined && (
                  <div className={`text-xs mt-1 ${itemDetailsClass}`}>
                    <div className="flex items-center">
                        میانگین امتیاز: <StarDisplay rating={admin.averageRating ?? 0} starSize="w-3.5 h-3.5" className="rtl:mr-1 ltr:ml-1" theme={currentTheme} />
                        <span className="rtl:mr-1 ltr:ml-1">({(admin.averageRating ?? 0).toFixed(1)}/5)</span>
                    </div>
                  </div>
                )}
                 {admin.role === 'user' && (admin.ruleAdherenceScore !== undefined || admin.respectScore !== undefined || admin.contentAccuracyScore !== undefined) && (
                    <div className={`text-xs mt-1 space-y-0.5 ${itemDetailsClass}`}>
                        {admin.ruleAdherenceScore !== undefined && <div>رعایت قوانین: <StarDisplay rating={admin.ruleAdherenceScore} starSize="w-3.5 h-3.5" className="inline-block rtl:mr-1 ltr:ml-1" theme={currentTheme} /> ({admin.ruleAdherenceScore}/5)</div>}
                        {admin.respectScore !== undefined && <div>احترام: <StarDisplay rating={admin.respectScore} starSize="w-3.5 h-3.5" className="inline-block rtl:mr-1 ltr:ml-1" theme={currentTheme} /> ({admin.respectScore}/5)</div>}
                        {admin.contentAccuracyScore !== undefined && <div>دقت مطالب: <StarDisplay rating={admin.contentAccuracyScore} starSize="w-3.5 h-3.5" className="inline-block rtl:mr-1 ltr:ml-1" theme={currentTheme} /> ({admin.contentAccuracyScore}/5)</div>}
                    </div>
                 )}
              </div>
              <div className="flex space-x-2 rtl:space-x-reverse mt-2 sm:mt-0 shrink-0">
                <Button 
                    onClick={() => startEdit(admin)} 
                    variant={buttonSecondaryVariant as any} 
                    size="sm" 
                    aria-label={`ویرایش ${admin.name}`} 
                    className={`!p-2 !rounded-md ${softUIButtonSecondaryClass}`}
                >
                  <PencilIcon className="w-4 h-4" />
                </Button>
                <Button 
                    onClick={() => handleDeleteRequest(admin.id, admin.name)} 
                    variant={isSoftUI ? "custom" : "danger"} 
                    size="sm" 
                    aria-label={`حذف ${admin.name}`} 
                    className={`!p-2 !rounded-md ${isSoftUI ? '!bg-red-500 hover:!bg-red-600 !text-white' : ''}`}
                >
                  <TrashIcon className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showDeleteConfirmModal && adminToDelete && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[60] p-4 animate-fadeIn">
          <div className={`p-6 rounded-xl shadow-2xl border w-full max-w-md text-center ${modalBgClass} ${isSoftUI ? 'border-softUI-inputBorder' : 'border-border-cosmicDefault'}`}>
            <h3 className={`text-xl font-semibold mb-4 ${sectionTitleClass}`}>تأیید حذف</h3>
            <p className={`${itemDetailsClass} mb-6`}>
              آیا از حذف <span className={`font-bold ${itemNameClass}`}>{adminToDelete.name}</span> مطمئن هستید؟ این عمل غیرقابل بازگشت است.
            </p>
            <div className="flex justify-center space-x-3 rtl:space-x-reverse">
              <Button 
                onClick={confirmDelete} 
                variant={isSoftUI ? "custom" : "danger"} 
                size="md" 
                className={`!rounded-lg ${isSoftUI ? '!bg-red-500 hover:!bg-red-600 !text-white' : ''}`}
              >
                تأیید حذف
              </Button>
              <Button onClick={() => { setShowDeleteConfirmModal(false); setAdminToDelete(null); }} variant={buttonSecondaryVariant as any} size="md" className={`!rounded-lg ${softUIButtonSecondaryClass}`}>
                انصراف
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminAkoAdminsPanel;
