// This component is no longer needed as user-side tournament registration has been removed.
// All tournament participant entry is now handled manually by the admin.

export {}; // To make this an empty module.
