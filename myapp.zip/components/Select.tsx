
import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: { value: string | number; label: string }[];
  theme?: 'default' | 'versace' | 'softUI' | 'autumnGrays' | 'userPanelInput'; 
}

const Select: React.FC<SelectProps> = ({ label, id, options, className = '', theme = 'default', ...props }) => {
  const isVersaceTheme = theme === 'versace';
  const isSoftUITheme = theme === 'softUI';
  const isAutumnGraysTheme = theme === 'autumnGrays';
  const isUserPanelInputTheme = theme === 'userPanelInput';

  let baseSelectClasses = `block w-full shadow-sm focus:outline-none sm:text-sm font-medium transition-all duration-150 appearance-none`;
  let themeLabelClasses = '';
  let selectSpecificClasses = '';
  let optionBgClass = '';
  let chevronIconColor = '';


  if (isSoftUITheme) {
    baseSelectClasses += ` pl-4 pr-10 py-3`; 
    themeLabelClasses = 'text-softUI-textSecondary mb-1.5 text-sm';
    selectSpecificClasses = `bg-softUI-inputBg border border-softUI-inputBorder rounded-xl 
                             text-softUI-textPrimary 
                             focus:ring-2 focus:ring-softUIFocus focus:border-softUIFocus soft-ui-input-focus`;
    optionBgClass = 'bg-softUI-card text-softUI-textPrimary'; 
    chevronIconColor = 'text-softUI-textSecondary';
  } else if (isUserPanelInputTheme) {
    baseSelectClasses += ` pl-4 pr-10 py-3 rounded-full`; // Pill shape
    themeLabelClasses = 'text-userPanel-textSecondary mb-1.5 text-sm';
    selectSpecificClasses = `bg-userPanel-inputBg border border-userPanel-inputBorder 
                             text-userPanel-inputText placeholder-userPanel-inputPlaceholder
                             focus:ring-2 focus:ring-userPanel-inputFocusRing focus:border-userPanel-inputFocusRing user-panel-input-focus`;
    optionBgClass = 'bg-userPanel-inputBg text-userPanel-inputText'; 
    chevronIconColor = 'text-userPanel-inputText';
  } else if (isVersaceTheme) {
    baseSelectClasses += ` pl-4 pr-10 py-2.5`;
    themeLabelClasses = 'text-versaceTheme-white mb-2';
    selectSpecificClasses = `bg-versaceTheme-black border border-versaceTheme-gray rounded-sm 
                             text-versaceTheme-white focus:border-versaceTheme-white focus:ring-2 focus:ring-versaceFocus versace-input-focus`;
    optionBgClass = 'bg-versaceTheme-black text-versaceTheme-white';
    chevronIconColor = 'text-versaceTheme-white';
  } else if (isAutumnGraysTheme) {
    baseSelectClasses += ` pl-4 pr-10 py-2.5`;
    themeLabelClasses = 'text-autumnGrays-textSecondary mb-1.5';
    selectSpecificClasses = `bg-autumnGrays-inputBg border border-autumnGrays-border rounded-lg 
                             text-autumnGrays-textPrimary 
                             focus:ring-2 focus:ring-autumnGrays-focusRing focus:border-autumnGrays-focusRing autumn-grays-input-focus`;
    optionBgClass = 'bg-autumnGrays-inputBg text-autumnGrays-textPrimary'; 
    chevronIconColor = 'text-autumnGrays-textSecondary';
  }
   else { // Default (Cosmic) Theme
    baseSelectClasses += ` pl-4 pr-10 py-2.5`;
    themeLabelClasses = 'text-text-cosmicSecondary mb-1.5';
    selectSpecificClasses = `bg-surface-cosmicInput border border-border-cosmicDefault rounded-lg 
                             focus:ring-2 focus:ring-border-cosmicFocus focus:border-border-cosmicFocus 
                             text-text-cosmicPrimary`;
    optionBgClass = 'bg-surface-cosmicInput text-text-cosmicPrimary';
    chevronIconColor = 'text-text-cosmicSecondary';
  }


  return (
    <div className="w-full">
      {label && (
        <label htmlFor={id} className={`block font-medium ${themeLabelClasses}`}>
          {label}
        </label>
      )}
      <div className="relative">
        <select
          id={id}
          className={`${baseSelectClasses} ${selectSpecificClasses} ${className}`}
          {...props}
        >
          {options.map(option => (
            <option key={option.value} value={option.value} className={`${optionBgClass} font-medium`}>
              {option.label}
            </option>
          ))}
        </select>
        <div className={`pointer-events-none absolute inset-y-0 rtl:left-0 ltr:right-0 flex items-center px-3 ${isUserPanelInputTheme ? 'rtl:left-1 ltr:right-1' : ''} ${chevronIconColor}`}>
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default Select;
