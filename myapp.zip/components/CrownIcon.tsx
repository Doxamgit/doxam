
import React from 'react';

const CrownIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={`w-5 h-5 ${className}`} // Color will be set by parent through className
    aria-hidden="true"
  >
    <path d="M12 2L9.25 8.75H2L7.5 12.5L5.25 19.25L12 15L18.75 19.25L16.5 12.5L22 8.75H14.75L12 2Z" />
  </svg>
);

export default CrownIcon;
