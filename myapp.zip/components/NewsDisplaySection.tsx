
import React from 'react';
import type { NewsItem } from '../types';

interface NewsDisplaySectionProps {
  newsItems: NewsItem[];
  isLoading: boolean;
  theme?: 'default' | 'autumnGrays' | 'userPanelContent'; 
  error?: string | null;
}

const NewsDisplaySection: React.FC<NewsDisplaySectionProps> = ({ newsItems, isLoading, theme = 'default', error }) => {
  const isAutumnTheme = theme === 'autumnGrays';
  const isUserPanelContentTheme = theme === 'userPanelContent';

  let titleClass = "text-gradient-title";
  let loadingTextClass = "text-text-cosmicSecondary";
  let noNewsTextClass = "text-text-cosmicSecondary";
  let articleBgClass = "bg-surface-cosmicPanel border-border-cosmicDefault";
  let articleTitleClass = "text-brand-cosmicAccentOrange";
  let articleContentClass = "text-text-cosmicSecondary";
  let articleMetaClass = "text-text-cosmicSecondary/70";
  let errorTextClass = "text-red-400";


  if (isAutumnTheme) {
    titleClass = "text-autumnGrays-textPrimary";
    loadingTextClass = "text-autumnGrays-textSecondary";
    noNewsTextClass = "text-autumnGrays-textSecondary";
    articleBgClass = "bg-autumnGrays-cardBg border-autumnGrays-border";
    articleTitleClass = "text-autumnGrays-textPrimary";
    articleContentClass = "text-autumnGrays-textSecondary";
    articleMetaClass = "text-autumnGrays-textSecondary/80";
    errorTextClass = "text-red-300";
  } else if (isUserPanelContentTheme) {
    titleClass = "text-userPanel-textPrimary";
    loadingTextClass = "text-userPanel-textSecondary";
    noNewsTextClass = "text-userPanel-textSecondary";
    // For content inside UserPanelSection, background is already dark by UserPanelSection.
    // These cards will be distinct within that dark area.
    articleBgClass = "bg-userPanel-cardBg/70 border-userPanel-iconContainerBg/30 backdrop-blur-sm";
    articleTitleClass = "text-userPanel-iconContainerBg"; // Use the bright blue for titles
    articleContentClass = "text-userPanel-textPrimary"; // Main text white
    articleMetaClass = "text-userPanel-textSecondary/80";
    errorTextClass = "text-red-300";
  }


  if (isLoading) {
    return (
      <div className={`my-8 animate-fadeIn ${isUserPanelContentTheme ? 'p-2' : ''}`}>
        {!isUserPanelContentTheme && <h2 className={`text-3xl font-bold text-center mb-8 ${titleClass}`}>اخبار گروه</h2>}
        <p className={`${loadingTextClass} text-center`}>در حال بارگذاری اخبار...</p>
      </div>
    );
  }
  
  if (error && !isUserPanelContentTheme) { // Only show top-level error if not in user panel collapsible
     return (
        <div className="my-12 animate-fadeIn">
            <h2 id="news-heading" className={`text-3xl sm:text-4xl font-bold text-center mb-10 ${titleClass}`}>اخبار گروه</h2>
            <p className={`${errorTextClass} text-center py-4`}>خطا در بارگیری اخبار: {error}</p>
        </div>
     );
  }


  return (
    <section className={`my-8 animate-fadeIn ${isUserPanelContentTheme ? 'py-2' : 'py-12'}`} aria-labelledby={!isUserPanelContentTheme ? "news-heading" : undefined}>
      {!isUserPanelContentTheme && 
        <h2 id="news-heading" className={`text-3xl sm:text-4xl font-bold text-center mb-10 ${titleClass}`}>
          اخبار گروه
        </h2>
      }
      {error && isUserPanelContentTheme && <p className={`${errorTextClass} text-center py-2 text-sm`}>خطا: {error}</p>}
      {newsItems.length === 0 && !error ? (
        <p className={`${noNewsTextClass} text-center py-4`}>در حال حاضر خبری موجود نیست.</p>
      ) : (
        <div className={`space-y-6 ${isUserPanelContentTheme ? 'max-w-full' : 'max-w-3xl mx-auto'}`}>
          {newsItems.map((item, index) => (
            <article 
              key={item.id} 
              className={`p-4 sm:p-5 border rounded-xl shadow-lg animate-fadeIn ${articleBgClass}`}
              style={{ animationDelay: `${index * 100}ms` }}
              aria-labelledby={`news-title-${item.id}`}
            >
              <h3 id={`news-title-${item.id}`} className={`text-xl sm:text-2xl font-semibold mb-2 ${articleTitleClass}`}>{item.title}</h3>
              <p className={`${articleContentClass} whitespace-pre-wrap leading-relaxed mb-3 text-sm sm:text-base`}>{item.content}</p>
              <p className={`text-xs text-left ${articleMetaClass}`}>
                تاریخ انتشار: {new Date(item.timestamp).toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
};

export default NewsDisplaySection;
