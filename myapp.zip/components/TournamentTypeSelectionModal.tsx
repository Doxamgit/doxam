
import React, { useEffect } from 'react';
import type { TournamentType } from '../types';
import Button from './Button';
import UserCircleIcon from './UserCircleIcon';
import UsersGroupIcon from './UsersGroupIcon';
// import ListBulletIcon from './ListBulletIcon'; // Removed as League type is gone
import XMarkIcon from './XMarkIcon';

interface TournamentTypeSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectType: (type: TournamentType) => void;
  theme?: 'softUI';
}

const TournamentTypeSelectionModal: React.FC<TournamentTypeSelectionModalProps> = ({
  isOpen,
  onClose,
  onSelectType,
  theme = 'softUI',
}) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      document.addEventListener('keydown', handleEsc);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const typeOptions: { label: string; type: TournamentType; icon: React.ReactNode }[] = [
    { label: 'تورنومنت (انفرادی)', type: 'individual', icon: <UserCircleIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'تورنومنت (یاری)', type: 'team', icon: <UsersGroupIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    // { label: 'تورنومنت (لیگ)', type: 'league', icon: <ListBulletIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> }, // Removed
  ];
  
  const modalOverlayClass = "bg-softUI-modalOverlay backdrop-blur-sm";
  const modalContentClass = "bg-softUI-card rounded-2xl shadow-xl border border-softUI-inputBorder";
  const titleTextClass = "text-softUI-textPrimary";
  const closeButtonHoverBg = "hover:bg-softUI-inputBg";

  return (
    <div
      className={`fixed inset-0 z-[70] flex items-center justify-center p-4 
                  transition-opacity duration-300 ease-out ${modalOverlayClass} 
                  ${isOpen ? 'opacity-100 visible modal-overlay-shown' : 'opacity-0 invisible'}`}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="tournament-type-modal-title"
    >
      <div
        className={`w-full max-w-md transform transition-all duration-300 ease-out ${modalContentClass}
                    max-h-[80vh] flex flex-col
                    ${isOpen ? 'animate-modal-enter modal-content-shown' : 'animate-modal-leave'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-5 border-b border-softUI-inputBorder">
          <h2 id="tournament-type-modal-title" className={`text-xl font-bold ${titleTextClass}`}>
            انتخاب نوع تورنومنت
          </h2>
          <Button
            onClick={onClose}
            variant="custom"
            className={`p-2 rounded-full ${closeButtonHoverBg} focus:outline-none focus:ring-2 focus:ring-softUI-primary focus:ring-offset-2 focus:ring-offset-softUI-card`}
            aria-label="بستن مودال"
          >
            <XMarkIcon className="w-6 h-6 text-softUI-textSecondary" />
          </Button>
        </div>

        <div className="p-4 sm:p-6 grid grid-cols-1 gap-4 overflow-y-auto">
          {typeOptions.map((opt) => (
            <Button
              key={opt.type}
              onClick={() => {
                onSelectType(opt.type);
                // onClose(); // onSelectType in App.tsx will handle closing the modal state
              }}
              variant="softUIDashboardOption"
              className="group admin-options-button-glow text-lg font-semibold !py-5 !px-5"
              neonEffect
            >
              {opt.icon}
              <span>{opt.label}</span>
            </Button>
          ))}
        </div>
         <div className="p-4 border-t border-softUI-inputBorder text-center">
            <Button onClick={onClose} variant="softUILink" size="md">انصراف</Button>
        </div>
      </div>
    </div>
  );
};

export default TournamentTypeSelectionModal;