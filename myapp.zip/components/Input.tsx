
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  id: string; 
  theme?: 'default' | 'versace' | 'softUI' | 'autumnGrays' | 'userPanelInput' | 'home' | 'foodieHome'; 
  icon?: React.ReactNode; 
  iconPosition?: 'leading' | 'trailing'; 
}

const Input: React.FC<InputProps> = ({ label, id, className = '', theme = 'default', icon, iconPosition = 'leading', ...props }) => { 
  const isVersaceTheme = theme === 'versace';
  const isSoftUITheme = theme === 'softUI';
  const isAutumnGraysTheme = theme === 'autumnGrays';
  const isUserPanelInputTheme = theme === 'userPanelInput';
  const isHomeTheme = theme === 'home'; // Original dark home
  const isFoodieHomeTheme = theme === 'foodieHome'; // New light home

  let baseInputClasses = `block w-full shadow-sm focus:outline-none sm:text-sm font-medium transition-all duration-150`;
  let themeLabelClasses = '';
  let inputSpecificClasses = '';
  let wrapperDivClasses = "w-full";
  let iconContainerClasses = `absolute inset-y-0 flex items-center pointer-events-none ${iconPosition === 'leading' ? 'rtl:pr-4 ltr:pl-4' : 'rtl:pl-4 ltr:pr-4'}`;


  if (isFoodieHomeTheme) {
    baseInputClasses += ` px-4 py-3`;
    themeLabelClasses = 'text-foodieTheme-textSecondary mb-1.5 text-sm';
    inputSpecificClasses = `bg-foodieTheme-inputBg border border-foodieTheme-inputBorder rounded-lg 
                            placeholder-foodieTheme-inputPlaceholder text-foodieTheme-inputText 
                            focus:ring-2 focus:ring-foodieTheme-focusRing focus:border-transparent`;
    // No icon support explicitly added for foodieHome theme inputs yet
  } else if (isSoftUITheme) {
    baseInputClasses += ` px-4 py-3`; 
    themeLabelClasses = 'text-softUI-textSecondary mb-1.5 text-sm';
    inputSpecificClasses = `bg-softUI-inputBg border border-softUI-inputBorder rounded-xl 
                            placeholder-softUI-inputPlaceholder text-softUI-textPrimary 
                            focus:ring-2 focus:ring-softUIFocus focus:border-softUIFocus soft-ui-input-focus
                            ${icon ? (iconPosition === 'leading' ? 'rtl:pr-12 ltr:pl-12' : 'rtl:pl-4 ltr:pr-12') : 'rtl:pr-4 ltr:pl-4'}`;
    if (props.type === 'password' && !icon) { 
        inputSpecificClasses += ` rtl:pl-10 ltr:pr-10`; 
    }
    wrapperDivClasses += ` relative`;
  } else if (isUserPanelInputTheme) {
    baseInputClasses += ` px-4 py-3 rounded-full`; 
    themeLabelClasses = 'text-userPanel-textSecondary mb-1.5 text-sm';
    inputSpecificClasses = `bg-userPanel-inputBg border border-userPanel-inputBorder 
                            placeholder-userPanel-inputPlaceholder text-userPanel-inputText 
                            focus:ring-2 focus:ring-userPanel-inputFocusRing focus:border-userPanel-inputFocusRing user-panel-input-focus
                            ${icon ? (iconPosition === 'leading' ? 'rtl:pr-12 ltr:pl-12' : 'rtl:pl-4 ltr:pr-12') : 'rtl:pr-4 ltr:pl-4'}`;
     if (props.type === 'password' && !icon) { 
        inputSpecificClasses += ` rtl:pl-10 ltr:pr-10`;
    }
    wrapperDivClasses += ` relative`;
    iconContainerClasses = `absolute inset-y-0 flex items-center pointer-events-none ${iconPosition === 'leading' ? 'rtl:right-3 ltr:left-3' : 'rtl:left-3 ltr:right-3'}`; 
     if (icon) { 
      iconContainerClasses += ` !w-10 !h-10 bg-userPanel-iconContainerBg rounded-full justify-center top-1/2 -translate-y-1/2 ${iconPosition === 'leading' ? 'rtl:right-1.5 ltr:left-1.5' : 'rtl:left-1.5 ltr:right-1.5'}`;
      if (iconPosition === 'leading') {
        inputSpecificClasses = inputSpecificClasses.replace(/rtl:pr-12 ltr:pl-12|rtl:pr-4 ltr:pl-4/g, 'rtl:pr-[3.25rem] ltr:pl-[3.25rem]');
      } else {
         inputSpecificClasses = inputSpecificClasses.replace(/rtl:pl-4 ltr:pr-12|rtl:pr-4 ltr:pl-4/g, 'rtl:pl-[3.25rem] ltr:pr-[3.25rem]');
      }
    }
  } else if (isHomeTheme) {
    baseInputClasses += ` px-4 py-3`;
    themeLabelClasses = 'text-brand-home-textSecondary mb-1.5 text-sm'; 
    inputSpecificClasses = `bg-brand-home-inputBg border border-brand-home-inputBorder rounded-xl
                            placeholder-brand-home-inputPlaceholder text-brand-home-inputText
                            focus:ring-2 focus:ring-brand-home-inputFocusRing focus:border-transparent`; 
  } else if (isVersaceTheme) {
    baseInputClasses += ` px-4 py-2.5`;
    themeLabelClasses = 'text-versaceTheme-white mb-2';
    inputSpecificClasses = `bg-versaceTheme-black border border-versaceTheme-gray rounded-sm placeholder-versaceTheme-gray 
                             text-versaceTheme-white focus:border-versaceTheme-white focus:ring-2 focus:ring-versaceFocus versace-input-focus`;
  } else if (isAutumnGraysTheme) {
    baseInputClasses += ` px-4 py-2.5`;
    themeLabelClasses = 'text-autumnGrays-textSecondary mb-1.5';
    inputSpecificClasses = `bg-autumnGrays-inputBg border border-autumnGrays-border rounded-lg placeholder-autumnGrays-textSecondary/70 
                             focus:ring-2 focus:ring-autumnGrays-focusRing focus:border-autumnGrays-focusRing autumn-grays-input-focus text-autumnGrays-textPrimary`;
  }
  else { // Default (Cosmic) Theme
    baseInputClasses += ` px-4 py-2.5`;
    themeLabelClasses = 'text-text-cosmicSecondary mb-1.5';
    inputSpecificClasses = `bg-surface-cosmicInput border border-border-cosmicDefault rounded-lg placeholder-text-cosmicPlaceholder 
                             focus:ring-2 focus:ring-border-cosmicFocus focus:border-border-cosmicFocus text-text-cosmicPrimary`;
  }


  return (
    <div className={wrapperDivClasses}>
      {label && (
        <label htmlFor={id} className={`block font-medium ${themeLabelClasses}`}>
          {label}
        </label>
      )}
      <div className="relative">
        {(isSoftUITheme || isUserPanelInputTheme) && icon && ( 
          <div className={iconContainerClasses}>
            {React.cloneElement(icon as React.ReactElement<{ className?: string }>, { 
              className: `${(icon as React.ReactElement<{ className?: string }>).props.className || ''} ${isUserPanelInputTheme ? 'text-userPanel-iconColor' : 'text-softUI-inputIcon'}`
            })}
          </div>
        )}
        <input
          id={id}
          className={`${baseInputClasses} ${inputSpecificClasses} ${className}`}
          {...props}
        />
      </div>
    </div>
  );
};

export default Input;
