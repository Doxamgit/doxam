
import React from 'react';
import FilledStarIcon from './FilledStarIcon';
import EmptyStarIcon from './EmptyStarIcon';

interface StarDisplayProps {
  rating: number;
  maxStars?: number;
  starSize?: string;
  className?: string;
  theme?: 'default' | 'softUI' | 'home' | 'autumnGrays' | 'userPanel'; 
}

const StarDisplay: React.FC<StarDisplayProps> = ({
  rating,
  maxStars = 5,
  starSize = "w-4 h-4", 
  className = "",
  theme = 'default'
}) => {
  const validRating = Math.max(0, Math.min(rating, maxStars));
  
  let filledStarColor = 'text-yellow-400';
  let emptyStarColor = 'text-gray-400';

  if (theme === 'softUI') {
    filledStarColor = 'text-yellow-500'; 
    emptyStarColor = 'text-gray-300';
  } else if (theme === 'home') {
    filledStarColor = 'text-yellow-400'; 
    emptyStarColor = 'text-gray-500'; 
  } else if (theme === 'autumnGrays') {
    filledStarColor = 'text-autumnGrays-textPrimary'; 
    emptyStarColor = 'text-autumnGrays-border';
  } else if (theme === 'userPanel') {
    filledStarColor = 'text-userPanel-iconContainerBg'; // Use the bright blue for filled stars
    emptyStarColor = 'text-userPanel-textSecondary/60'; // A dimmer version of text for empty
  }


  return (
    <div className={`flex items-center space-x-0.5 rtl:space-x-reverse ${className}`}>
      {[...Array(maxStars)].map((_, index) => {
        const starValue = index + 1;
        return starValue <= validRating ? (
          <FilledStarIcon key={index} className={`${starSize} ${filledStarColor}`} />
        ) : (
          <EmptyStarIcon key={index} className={`${starSize} ${emptyStarColor}`} />
        );
      })}
    </div>
  );
};

export default StarDisplay;
