
import React, { useState, useEffect } from 'react';
import Button from './Button';

interface AdminRulesPanelProps {
  initialRulesContent: string;
  onSaveRules: (content: string) => boolean; 
  rulesError: string | null;
  clearRulesError: () => void;
  onClose?: () => void;
  currentTheme?: 'default' | 'softUI';
}

const AdminRulesPanel: React.FC<AdminRulesPanelProps> = ({
  initialRulesContent,
  onSaveRules,
  rulesError,
  clearRulesError,
  onClose,
  currentTheme = 'default'
}) => {
  const [content, setContent] = useState(initialRulesContent);
  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const isSoftUI = currentTheme === 'softUI';

  useEffect(() => {
    setContent(initialRulesContent); 
  }, [initialRulesContent]);

  useEffect(() => {
    if (rulesError) {
      setLocalError(rulesError);
    }
  }, [rulesError]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    clearRulesError();
    setLocalError(null);
    setSuccessMessage(null);
    
    const success = onSaveRules(content);
    if (success) {
      setSuccessMessage("قوانین با موفقیت ذخیره شد!");
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  // Theme-specific classes
  const panelClasses = isSoftUI 
    ? "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder" 
    : "bg-surface-cosmicPanel rounded-xl shadow-2xl border border-border-cosmicDefault";
  const titleTextClass = isSoftUI ? "text-softUI-textPrimary" : "text-gradient-title";
  const buttonPrimaryVariant = isSoftUI ? "softUIPrimary" : "cosmicAccent";
  const buttonSecondaryVariant = isSoftUI ? "custom" : "cosmicDarkSecondary";
  const softUIButtonSecondaryClass = isSoftUI ? `!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder` : '';
  const errorTextClass = isSoftUI ? "text-red-600" : "text-red-400";
  const errorBgClass = isSoftUI ? "bg-red-100 border-red-300" : "bg-red-900/50";
  const successTextClass = isSoftUI ? "text-green-600" : "text-green-400";
  const successBgClass = isSoftUI ? "bg-green-100 border-green-300" : "bg-green-800/50";
  const textareaClass = isSoftUI 
    ? "block w-full px-4 py-2.5 bg-softUI-inputBg border border-softUI-inputBorder rounded-xl shadow-sm placeholder-softUI-inputPlaceholder focus:outline-none focus:ring-2 focus:ring-softUIFocus focus:border-softUIFocus sm:text-sm text-softUI-textPrimary font-medium transition-colors duration-150"
    : "block w-full px-4 py-2.5 bg-surface-cosmicInput border border-border-cosmicDefault rounded-lg shadow-sm placeholder-text-cosmicPlaceholder focus:outline-none focus:ring-2 focus:ring-border-cosmicFocus focus:border-border-cosmicFocus sm:text-sm text-text-cosmicPrimary font-medium transition-colors duration-150";
  const labelClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";
  const helpTextClass = isSoftUI ? "text-softUI-textSecondary text-xs" : "text-text-cosmicSecondary text-xs";


  return (
    <div className={`max-w-4xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
      <div className="flex justify-between items-center mb-8">
        <h2 className={`text-3xl font-bold ${titleTextClass}`}>مدیریت قوانین آکو</h2>
        {onClose && 
            <Button 
                onClick={onClose} 
                variant={buttonSecondaryVariant as any} 
                size="sm" 
                className={`!rounded-lg ${softUIButtonSecondaryClass}`}
            >
                بازگشت
            </Button>
        }
      </div>

      {localError && <p className={`p-3 rounded-lg mb-4 text-sm ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
      {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

      <form onSubmit={handleSave} className="space-y-6">
        <div>
          <label htmlFor="rules-content" className={`block text-sm font-medium mb-1.5 ${labelClass}`}>
            محتوای قوانین
          </label>
          <textarea
            id="rules-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="قوانین و مقررات آکو را اینجا وارد کنید..."
            rows={15}
            className={textareaClass}
          />
          <p className={`mt-2 ${helpTextClass}`}>می‌توانید از خطوط جدید برای جداسازی پاراگراف‌ها استفاده کنید.</p>
        </div>
        <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">
          ذخیره قوانین
        </Button>
      </form>
    </div>
  );
};

export default AdminRulesPanel;
