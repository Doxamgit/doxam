import React from 'react';

interface LoadingScreenProps {
  isFadingOut: boolean;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ isFadingOut }) => {
  const imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBrS2ocWMuAqYfRmuiEWjClKAvYzRr-5j-eUCfychzLrqz-mD-Yd1P1DTlnBxWSZ6UaI-i4tOFPiqKL3GKAJsZxLzl6a3vfiR7w07_z7rn23toSkwnRiO1amQQKeXMLeXUrHeXTmvcoO6RIqQ4JYz2ikWhXSvJoRJIawOSboRvPjSGb-sWwpuXbjZaOrI_rFt90UG2lNPG3bZxeaLWpsRVflbqIojmji3I5YvV5TuEFKDCKxBoHHA3flWeTP-jEtsvJpfH0n_VOMg";

  return (
    <div
      className={`fixed inset-0 z-[100] flex size-full min-h-screen flex-col items-center justify-center bg-[#F8F7FA] p-4 group/design-root overflow-x-hidden transition-opacity duration-700 ease-in-out ${
        isFadingOut ? 'opacity-0' : 'opacity-100'
      }`}
      style={{ fontFamily: '"Be Vietnam Pro", "Noto Sans", sans-serif' }}
      aria-live="polite"
      aria-busy="true"
      role="status"
    >
      <div className="flex flex-col items-center justify-center w-full max-w-md flex-grow">
        <h2 className="text-[#0d141c] tracking-tight text-[36px] font-bold leading-tight text-center mb-8 font-sans">
          خانواده ی بزرگ <span className="text-[#0c7ff2]">آکو</span>
        </h2>
        <div className="relative w-full aspect-square max-w-[350px] sm:max-w-[400px] rounded-full border-4 border-[#0c7ff2]/50 shadow-xl p-2">
          <div
            className="w-full h-full bg-center bg-no-repeat bg-contain rounded-full"
            style={{ backgroundImage: `url("${imageUrl}")` }}
            aria-label="Ako Family decorative image"
          ></div>
          <div className="absolute inset-0 rounded-full border-t-4 border-b-4 border-[#0c7ff2] animate-spin opacity-50"></div>
        </div>
      </div>
      <div className="flex flex-col items-center justify-center w-full pb-12">
        <div className="flex space-x-2 rtl:space-x-reverse">
          <div className="w-3 h-3 bg-[#0c7ff2] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
          <div className="w-3 h-3 bg-[#0c7ff2] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
          <div className="w-3 h-3 bg-[#0c7ff2] rounded-full animate-bounce"></div>
        </div>
        <p className="mt-4 text-sm text-[#0d141c] font-sans">لطفا صبور باشید</p>
      </div>
    </div>
  );
};

export default LoadingScreen;