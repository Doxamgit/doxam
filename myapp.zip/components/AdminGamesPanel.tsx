
import React, { useState, useEffect } from 'react';
import type { Game } from '../types';
import Button from './Button';
import Input from './Input';
import TrashIcon from './TrashIcon';
import PencilIcon from './PencilIcon';
import PuzzlePieceIcon from './PuzzlePieceIcon'; 
import ConfirmationModal from './ConfirmationModal';

interface AdminGamesPanelProps {
  games: Game[];
  onAddGame: (name: string) => Game | null;
  onUpdateGame: (id: string, newName: string) => Game | null;
  onDeleteGame: (id: string) => boolean;
  gamesError: string | null;
  clearGamesError: () => void;
  onClose?: () => void;
}

const AdminGamesPanel: React.FC<AdminGamesPanelProps> = ({
  games,
  onAddGame,
  onUpdateGame,
  onDeleteGame,
  gamesError,
  clearGamesError,
  onClose,
}) => {
  const [newGameName, setNewGameName] = useState('');
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [editGameName, setEditGameName] = useState('');
  
  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [gameToDelete, setGameToDelete] = useState<Game | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  useEffect(() => {
    if (gamesError) {
      setLocalError(gamesError);
    }
  }, [gamesError]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearGamesError();
    setLocalError(null);
    setSuccessMessage(null);
    const addedGame = onAddGame(newGameName);
    if (addedGame) {
      setNewGameName('');
      setSuccessMessage(`بازی "${addedGame.name}" با موفقیت اضافه شد.`);
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGame) return;
    clearGamesError();
    setLocalError(null);
    setSuccessMessage(null);
    const updatedGame = onUpdateGame(editingGame.id, editGameName);
    if (updatedGame) {
      setEditingGame(null);
      setEditGameName('');
      setSuccessMessage(`بازی "${updatedGame.name}" با موفقیت ویرایش شد.`);
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  const startEdit = (game: Game) => {
    setEditingGame(game);
    setEditGameName(game.name);
    clearGamesError();
    setLocalError(null);
    setSuccessMessage(null);
  };

  const handleDeleteRequest = (game: Game) => {
    setGameToDelete(game);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteGame = () => {
    if (gameToDelete) {
      onDeleteGame(gameToDelete.id);
    }
    setIsDeleteModalOpen(false);
    setGameToDelete(null);
  };
  
  const panelClasses = "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder";
  const titleTextClass = "text-softUI-textPrimary";
  const titleIconClass = "text-softUI-primary";
  const inputTheme = "softUI";
  const formBgClass = "bg-softUI-bgPage rounded-lg border border-softUI-inputBorder";
  const sectionTitleClass = "text-softUI-textPrimary";
  const itemBgClass = "bg-softUI-bgPage rounded-lg shadow-sm border border-softUI-inputBorder";
  const itemNameClass = "text-softUI-textPrimary";
  const itemDetailsClass = "text-softUI-textSecondary"; 
  const buttonPrimaryVariant = "softUIPrimary";
  const buttonSecondaryVariant = "custom";
  const softUIButtonSecondaryClass = "!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder";
  const errorTextClass = "text-red-600";
  const errorBgClass = "bg-red-100 border-red-300";
  const successTextClass = "text-green-600";
  const successBgClass = "bg-green-100 border-green-300";

  return (
    <>
      <div className={`max-w-2xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
        <div className="flex justify-between items-center mb-8">
          <h2 className={`text-2xl sm:text-3xl font-bold flex items-center ${titleTextClass}`}>
            <PuzzlePieceIcon className={`w-7 h-7 sm:w-8 sm:h-8 rtl:ml-3 ltr:mr-3 ${titleIconClass}`} />
            مدیریت لیست بازی‌ها
          </h2>
          {onClose && 
              <Button onClick={onClose} variant={buttonSecondaryVariant as any} size="sm" className={`!rounded-lg ${softUIButtonSecondaryClass}`}>
                  بازگشت
              </Button>
          }
        </div>

        {localError && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
        {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

        {editingGame ? (
          <form onSubmit={handleEditSubmit} className={`space-y-5 mb-10 p-6 ${formBgClass}`}>
            <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>ویرایش بازی: {editingGame.name}</h3>
            <Input
              label="نام جدید بازی"
              id="edit-game-name"
              value={editGameName}
              onChange={(e) => setEditGameName(e.target.value)}
              required
              theme={inputTheme}
              className="!rounded-lg"
            />
            <div className="flex space-x-3 rtl:space-x-reverse pt-2">
              <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">ذخیره تغییرات</Button>
              <Button type="button" onClick={() => setEditingGame(null)} variant={buttonSecondaryVariant as any} size="md" className={`!rounded-lg ${softUIButtonSecondaryClass}`}>انصراف</Button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleAddSubmit} className={`space-y-5 mb-10 p-6 ${formBgClass}`}>
            <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>افزودن بازی جدید</h3>
            <Input
              label="نام بازی"
              id="new-game-name"
              value={newGameName}
              onChange={(e) => setNewGameName(e.target.value)}
              placeholder="مثال: شطرنج، مافیا، بیلیارد"
              required
              theme={inputTheme}
              className="!rounded-lg"
            />
            <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">افزودن بازی</Button>
          </form>
        )}

        <h3 className={`text-xl sm:text-2xl font-semibold ${sectionTitleClass} mb-6 mt-8 pt-6 border-t border-softUI-inputBorder`}>
          لیست بازی‌های موجود ({games.length})
        </h3>
        {games.length === 0 ? (
          <p className={`${itemDetailsClass} text-center py-4`}>هنوز هیچ بازی‌ای اضافه نشده است. می‌توانید از لیست پیش‌فرض استفاده کنید یا بازی جدید اضافه کنید.</p>
        ) : (
          <div className={`space-y-3 max-h-[40vh] overflow-y-auto pr-2 soft-ui-theme-active`}>
            {games.map(game => (
              <div key={game.id} className={`p-3 flex justify-between items-center ${itemBgClass}`}>
                <p className={`${itemNameClass} text-md`}>{game.name}</p>
                <div className="flex space-x-2 rtl:space-x-reverse shrink-0">
                  <Button onClick={() => startEdit(game)} variant={buttonSecondaryVariant as any} size="sm" aria-label={`ویرایش ${game.name}`} className={`!p-2 !rounded-md ${softUIButtonSecondaryClass}`}>
                    <PencilIcon className="w-4 h-4" />
                  </Button>
                  <Button onClick={() => handleDeleteRequest(game)} variant="custom" size="sm" aria-label={`حذف ${game.name}`} className={`!p-2 !rounded-md !bg-red-100 !text-red-600 hover:!bg-red-200 !border-red-300`}>
                    <TrashIcon className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {gameToDelete && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setGameToDelete(null);
          }}
          onConfirm={confirmDeleteGame}
          title="تأیید حذف بازی"
          message={
            <p className="text-softUI-textSecondary">
              آیا از حذف بازی <strong className="text-softUI-primary">"{gameToDelete.name}"</strong> مطمئن هستید؟
              این عمل غیرقابل بازگشت است.
            </p>
          }
          theme="softUI"
        />
      )}
    </>
  );
};

export default AdminGamesPanel;
