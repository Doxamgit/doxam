// This component has been removed as per user request.
// The functionality is replaced by FeaturedTournamentCard.
export {};
