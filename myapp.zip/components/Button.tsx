
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'light' | 'outline' | 'formSecondary' | 'orange' | 'custom' | 'cosmicAccent' | 'cosmicDarkSecondary' | 'artisticGold' | 'artisticOutline' | 'homePrimaryAction' | 'homeSecondaryAction' | 'versacePrimary' | 'versaceSecondary' | 'versaceOutline' | 'softUIPrimary' | 'softUILink' | 'softUIDashboardOption' | 'autumnPrimary' | 'autumnSecondary' | 'foodieHomePrimary' | 'foodieHomeSecondary';
  size?: 'sm' | 'md' | 'lg' | 'xl'; 
  fullWidth?: boolean;
  focusRingOffsetColor?: string; 
  interactive?: boolean; 
  neonEffect?: boolean; 
  lightningTap?: boolean;
}

const Button: React.FC<ButtonProps> = ({
  children,
  className = '',
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  focusRingOffsetColor, 
  interactive = true,
  neonEffect = false, 
  lightningTap = false,
  ...props
}) => {
  let actualFocusRingOffsetColor = focusRingOffsetColor;
  if (!actualFocusRingOffsetColor) {
    if (variant === 'artisticGold' || variant === 'artisticOutline') {
      actualFocusRingOffsetColor = 'focus:ring-offset-surface-artisticTealPoemPanel';
    } else if (variant === 'homePrimaryAction' || variant === 'homeSecondaryAction') {
      actualFocusRingOffsetColor = 'focus:ring-offset-brand-home-bg';
    } else if (variant === 'foodieHomePrimary' || variant === 'foodieHomeSecondary') {
      actualFocusRingOffsetColor = 'focus:ring-offset-foodieTheme-bgPage';
    } else if (variant === 'versacePrimary' || variant === 'versaceSecondary' || variant === 'versaceOutline') {
      actualFocusRingOffsetColor = 'focus:ring-offset-versace-black';
    } else if (variant === 'softUIPrimary' || variant === 'softUILink' || variant === 'softUIDashboardOption') {
      actualFocusRingOffsetColor = 'focus:ring-offset-softUI-card'; 
      if (props.disabled) actualFocusRingOffsetColor = 'focus:ring-offset-softUI-bgPage'; 
    } else if (variant === 'autumnPrimary' || variant === 'autumnSecondary') {
      actualFocusRingOffsetColor = 'focus:ring-offset-autumnGrays-cardBg';
       if (props.disabled || variant === 'autumnSecondary') actualFocusRingOffsetColor = 'focus:ring-offset-autumnGrays-bgPage';
    }
     else {
      actualFocusRingOffsetColor = 'focus:ring-offset-brand-cosmicDarkBg'; 
    }
  }

  const baseStyles = `font-semibold focus:outline-none focus:ring-2 ${actualFocusRingOffsetColor} transition-all duration-200 ease-in-out disabled:opacity-60 disabled:cursor-not-allowed`;
  
  let interactiveClasses = '';
  if (interactive && !props.disabled) {
    if (lightningTap) {
      interactiveClasses = 'interactive-lightning-tap';
    } else {
      interactiveClasses = 'active:scale-[0.97] active:opacity-90';
    }
  }
  
  const neonGlowClass = neonEffect && !props.disabled ? 'interactive-neon-glow' : '';

  let roundedClass = 'rounded-lg'; 
  if (variant === 'cosmicAccent' || variant === 'cosmicDarkSecondary' || variant === 'artisticGold' || variant === 'artisticOutline' || variant === 'homePrimaryAction' || variant === 'homeSecondaryAction') {
    roundedClass = 'rounded-full';
  } else if (variant === 'versacePrimary' || variant === 'versaceSecondary' || variant === 'versaceOutline') {
    roundedClass = 'rounded-md'; 
  } else if (variant === 'softUIPrimary' || variant === 'softUILink' || variant === 'softUIDashboardOption') {
    roundedClass = 'rounded-xl'; 
  } else if (variant === 'foodieHomePrimary' || variant === 'foodieHomeSecondary') {
    roundedClass = 'rounded-xl';
  } else if (variant === 'autumnPrimary' || variant === 'autumnSecondary') {
    roundedClass = 'rounded-lg';
  }


  const variantStyles = {
    primary: 'bg-brand-primary hover:bg-brand-primaryHover text-text-onPrimary focus:ring-brand-primary',
    secondary: 'bg-surface-cosmicPanel hover:bg-border-cosmicDefault text-text-cosmicPrimary focus:ring-border-cosmicFocus', 
    danger: 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-500',
    light: 'bg-gray-200 hover:bg-gray-300 text-gray-800 focus:ring-gray-400',
    outline: 'bg-transparent hover:bg-brand-cosmicAccentOrange/10 border-2 border-brand-cosmicAccentOrange text-brand-cosmicAccentOrange focus:ring-brand-cosmicAccentOrange',
    formSecondary: 'bg-brand-buttonSecondaryBg hover:bg-brand-buttonSecondaryBgHover text-text-buttonSecondary focus:ring-gray-400 border border-gray-300',
    orange: 'bg-brand-orange hover:bg-brand-orangeHover text-white focus:ring-brand-orange',
    
    cosmicAccent: `bg-brand-cosmicAccentOrange hover:bg-brand-cosmicAccentOrangeHover text-text-cosmicOnAccent focus:ring-brand-cosmicAccentOrange ${roundedClass}`,
    cosmicDarkSecondary: `bg-surface-cosmicInput hover:bg-border-cosmicDefault text-text-cosmicPrimary focus:ring-border-cosmicFocus ${roundedClass}`,
    
    artisticGold: `bg-brand-artisticGoldButtonBg hover:bg-brand-artisticGoldButtonHoverBg text-brand-artisticGoldButtonText focus:ring-brand-artisticGoldAccent ${roundedClass}`,
    artisticOutline: `bg-transparent hover:bg-brand-artisticGoldAccent/10 border-2 border-border-artisticGoldAccent text-brand-artisticGoldAccent focus:ring-brand-artisticGoldAccent ${roundedClass}`,

    homePrimaryAction: `bg-brand-home-buttonPrimaryBg text-brand-home-buttonPrimaryText border border-brand-home-buttonPrimaryBorder hover:bg-brand-home-buttonPrimaryBgHover focus:ring-brand-home-accentGlow ${roundedClass}`,
    homeSecondaryAction: `bg-transparent text-brand-home-buttonSecondaryText border-2 border-brand-home-buttonSecondaryBorder hover:border-brand-home-buttonSecondaryBorderHover hover:bg-brand-home-buttonSecondaryBgHover focus:ring-brand-home-accentGlow ${roundedClass}`,
    
    foodieHomePrimary: `bg-foodieTheme-accent text-foodieTheme-onAccent hover:bg-foodieTheme-accentHover focus:ring-foodieTheme-focusRing shadow-md hover:shadow-lg ${roundedClass}`,
    foodieHomeSecondary: `bg-foodieTheme-cardBg text-foodieTheme-accent border-2 border-foodieTheme-accent hover:bg-foodieTheme-inputBg focus:ring-foodieTheme-focusRing shadow-md hover:shadow-lg ${roundedClass}`,

    versacePrimary: `bg-versaceTheme-black text-versaceTheme-white border-2 border-versaceTheme-white hover:bg-versaceTheme-white hover:text-versaceTheme-black focus:ring-versaceFocus ${roundedClass}`,
    versaceSecondary: `bg-versaceTheme-white text-versaceTheme-black border-2 border-versaceTheme-black hover:bg-versaceTheme-black hover:text-versaceTheme-white focus:ring-versaceFocus ${roundedClass}`,
    versaceOutline: `bg-transparent text-versaceTheme-white border-2 border-versaceTheme-white hover:bg-versaceTheme-white hover:text-versaceTheme-black focus:ring-versaceFocus ${roundedClass}`,
    
    softUIPrimary: `bg-softUI-primary hover:bg-softUI-primaryHover text-softUI-textOnPrimary focus:ring-softUIFocus ${roundedClass} shadow-md hover:shadow-lg`,
    softUILink: `bg-transparent text-softUI-textSecondary hover:text-softUI-primary focus:ring-softUIFocus focus:ring-offset-softUI-bgPage ${roundedClass}`,
    softUIDashboardOption: `bg-softUI-card hover:bg-softUI-adminOptionHoverBg text-softUI-textPrimary hover:text-softUI-primary 
                            border border-softUI-inputBorder hover:border-softUI-primary 
                            focus:ring-softUIFocus focus:ring-offset-softUI-card 
                            shadow-soft-ui-card hover:shadow-lg ${roundedClass} flex items-center justify-start text-right p-4`,

    autumnPrimary: `bg-autumnGrays-buttonPrimaryBg text-autumnGrays-buttonPrimaryText border border-autumnGrays-border hover:bg-opacity-80 focus:ring-autumnGraysFocus ${roundedClass}`,
    autumnSecondary: `bg-autumnGrays-buttonSecondaryBg text-autumnGrays-buttonSecondaryText border border-autumnGrays-border hover:bg-opacity-80 focus:ring-autumnGraysFocus ${roundedClass}`,

    custom: '', 
  };

  const sizeStyles = {
    sm: 'px-3.5 py-2 text-sm',
    md: 'px-5 py-2.5 text-base',
    lg: 'px-7 py-3.5 text-lg',
    xl: 'px-8 py-4 text-xl', 
  };
  
  const widthClass = fullWidth ? 'w-full' : '';

  const finalClassName = `${baseStyles} ${variant === 'custom' ? '' : variantStyles[variant]} ${sizeStyles[size]} ${widthClass} ${className.includes('rounded-') ? '' : roundedClass} ${interactiveClasses} ${neonGlowClass} ${className}`;


  return (
    <button
      className={finalClassName}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
