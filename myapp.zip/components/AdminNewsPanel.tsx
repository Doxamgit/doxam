import React, { useState, useEffect } from 'react';
import type { NewsItem } from '../types';
import Button from './Button';
import Input from './Input';
import ConfirmationModal from './ConfirmationModal'; // Import the new modal

interface AdminNewsPanelProps {
  newsItems: NewsItem[];
  onAddNews: (title: string, content: string) => boolean; 
  onDeleteNews: (id: string) => void;
  newsError: string | null;
  clearNewsError: () => void;
  onClose?: () => void; 
  currentTheme?: 'default' | 'softUI';
}

const AdminNewsPanel: React.FC<AdminNewsPanelProps> = ({
  newsItems,
  onAddNews,
  onDeleteNews,
  newsError,
  clearNewsError,
  onClose,
  currentTheme = 'default'
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [newsItemToDelete, setNewsItemToDelete] = useState<NewsItem | null>(null);

  const isSoftUI = currentTheme === 'softUI';

  useEffect(() => {
    if (newsError) {
      setLocalError(newsError);
    }
  }, [newsError]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearNewsError(); 
    setLocalError(null);
    setSuccessMessage(null);
    if (!title.trim() || !content.trim()) {
      setLocalError("عنوان و متن خبر نمی‌توانند خالی باشند.");
      return;
    }
    const success = onAddNews(title, content);
    if (success) {
      setTitle('');
      setContent('');
      setSuccessMessage("خبر با موفقیت اضافه شد!");
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };
  
  const handleDeleteRequest = (item: NewsItem) => {
    setNewsItemToDelete(item);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteNewsItem = () => {
    if (newsItemToDelete) {
      clearNewsError();
      setLocalError(null);
      onDeleteNews(newsItemToDelete.id);
    }
    setIsDeleteModalOpen(false);
    setNewsItemToDelete(null);
  };

  // Theme-specific classes
  const panelClasses = isSoftUI 
    ? "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder" 
    : "bg-surface-cosmicPanel rounded-xl shadow-2xl border border-border-cosmicDefault";
  const titleTextClass = isSoftUI ? "text-softUI-textPrimary" : "text-gradient-title";
  const inputTheme = isSoftUI ? "softUI" : "default";
  const formBgClass = isSoftUI ? "bg-softUI-bgPage rounded-lg border border-softUI-inputBorder" : "bg-brand-cosmicDarkBg rounded-lg border border-border-cosmicDefault/70";
  const sectionTitleClass = isSoftUI ? "text-softUI-textPrimary" : "text-text-cosmicPrimary";
  const itemBgClass = isSoftUI ? "bg-softUI-bgPage rounded-lg shadow-md border border-softUI-inputBorder" : "bg-brand-cosmicDarkBg rounded-lg shadow-lg border border-border-cosmicDefault/50";
  const itemTitleClass = isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange";
  const itemContentClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";
  const itemMetaClass = isSoftUI ? "text-softUI-textSecondary/70" : "text-gray-500";
  const buttonPrimaryVariant = isSoftUI ? "softUIPrimary" : "cosmicAccent";
  const buttonSecondaryVariant = isSoftUI ? "custom" : "cosmicDarkSecondary"; // Use custom for softUI secondary
  const softUIButtonSecondaryClass = isSoftUI ? `!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder` : '';
  const errorTextClass = isSoftUI ? "text-red-600" : "text-red-400";
  const errorBgClass = isSoftUI ? "bg-red-100 border-red-300" : "bg-red-900/50";
  const successTextClass = isSoftUI ? "text-green-600" : "text-green-400";
  const successBgClass = isSoftUI ? "bg-green-100 border-green-300" : "bg-green-800/50";
  const textareaClass = isSoftUI 
    ? "block w-full px-4 py-2.5 bg-softUI-inputBg border border-softUI-inputBorder rounded-xl shadow-sm placeholder-softUI-inputPlaceholder focus:outline-none focus:ring-2 focus:ring-softUIFocus focus:border-softUIFocus sm:text-sm text-softUI-textPrimary font-medium transition-colors duration-150"
    : "block w-full px-4 py-2.5 bg-surface-cosmicInput border border-border-cosmicDefault rounded-lg shadow-sm placeholder-text-cosmicPlaceholder focus:outline-none focus:ring-2 focus:ring-border-cosmicFocus focus:border-border-cosmicFocus sm:text-sm text-text-cosmicPrimary font-medium transition-colors duration-150";
  const labelClass = isSoftUI ? "text-softUI-textSecondary" : "text-text-cosmicSecondary";

  return (
    <>
      <div className={`max-w-4xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
        <div className="flex justify-between items-center mb-8">
          <h2 className={`text-3xl font-bold ${titleTextClass}`}>مدیریت اخبار</h2>
          {onClose && 
              <Button 
                  onClick={onClose} 
                  variant={buttonSecondaryVariant as any} 
                  size="sm" 
                  className={`!rounded-lg ${softUIButtonSecondaryClass}`}
              >
                  بازگشت
              </Button>
          }
        </div>

        {localError && <p className={`p-3 rounded-lg mb-4 text-sm ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
        {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

        <form onSubmit={handleSubmit} className={`space-y-6 mb-10 p-6 ${formBgClass}`}>
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>افزودن خبر جدید</h3>
          <Input
            label="عنوان خبر"
            id="news-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="عنوان خبر را وارد کنید"
            required
            theme={inputTheme}
            className="font-semibold"
          />
          <div>
            <label htmlFor="news-content" className={`block text-sm font-medium mb-1.5 ${labelClass}`}>
              متن خبر
            </label>
            <textarea
              id="news-content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="متن کامل خبر را اینجا بنویسید..."
              rows={5}
              required
              className={textareaClass}
            />
          </div>
          <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">
            افزودن خبر
          </Button>
        </form>

        <h3 className={`text-2xl font-semibold ${sectionTitleClass} mb-6 mt-8 pt-6 border-t ${isSoftUI ? 'border-softUI-inputBorder' : 'border-border-cosmicDefault/70'}`}>لیست اخبار منتشر شده</h3>
        {newsItems.length === 0 ? (
          <p className={`${itemContentClass} text-center py-4`}>در حال حاضر هیچ خبری منتشر نشده است.</p>
        ) : (
          <div className={`space-y-6 max-h-[60vh] overflow-y-auto pr-2 ${isSoftUI ? 'soft-ui-theme-active' : 'custom-scrollbar'}`}>
            {newsItems.map(item => (
              <div key={item.id} className={`p-5 animate-fadeIn ${itemBgClass}`}>
                <div className="flex justify-between items-start mb-2">
                  <h4 className={`text-xl font-bold ${itemTitleClass}`}>{item.title}</h4>
                  <Button 
                      onClick={() => handleDeleteRequest(item)} 
                      variant={isSoftUI ? "custom" : "danger"} 
                      size="sm" 
                      aria-label={`حذف خبر: ${item.title}`} 
                      className={`!rounded-md ${isSoftUI ? '!bg-red-500 hover:!bg-red-600 !text-white' : ''}`}
                  >
                    حذف
                  </Button>
                </div>
                <p className={`${itemContentClass} whitespace-pre-wrap leading-relaxed mb-3`}>{item.content}</p>
                <p className={`text-xs ${itemMetaClass}`}>
                  منتشر شده در: {new Date(item.timestamp).toLocaleString('fa-IR')}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
      {newsItemToDelete && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setNewsItemToDelete(null);
          }}
          onConfirm={confirmDeleteNewsItem}
          title="تأیید حذف خبر"
          message={
            <p>
              آیا از حذف خبر <strong className={isSoftUI ? "text-softUI-primary" : "text-brand-cosmicAccentOrange"}>"{newsItemToDelete.title}"</strong> مطمئن هستید؟
            </p>
          }
          theme={currentTheme === 'softUI' ? 'softUI' : undefined}
        />
      )}
    </>
  );
};

export default AdminNewsPanel;
