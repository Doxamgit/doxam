
import React, { useEffect } from 'react';
import { ViewState } from '../types';
import Button from './Button';
import CogIcon from './CogIcon'; 
import NewspaperIcon from './NewspaperIcon'; 
import ScaleIcon from './ScaleIcon'; 
import KeyIcon from './KeyIcon'; 
import UsersGroupIcon from './UsersGroupIcon';
import ListBulletIcon from './ListBulletIcon'; 
import XMarkIcon from './XMarkIcon'; 
import InboxIcon from './InboxIcon'; 
import BanIcon from './BanIcon';
import PuzzlePieceIcon from './PuzzlePieceIcon'; // Import new icon for games

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: ViewState) => void;
}

const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({ isOpen, onClose, onNavigate }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('keydown', handleEsc);
    }
    return () => {
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const adminOptions = [
    { label: 'پیکربندی تورنومنت', view: ViewState.TOURNAMENT_SETUP, icon: <CogIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'مدیریت اخبار', view: ViewState.ADMIN_NEWS_MANAGEMENT, icon: <NewspaperIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'مدیریت قوانین', view: ViewState.ADMIN_RULES_MANAGEMENT, icon: <ScaleIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'مدیریت تیم آکو', view: ViewState.ADMIN_AKO_ADMINS_MANAGEMENT, icon: <UsersGroupIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'مدیریت بازی‌ها', view: ViewState.ADMIN_GAMES_MANAGEMENT, icon: <PuzzlePieceIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'مدیریت لیست مسدودی', view: ViewState.ADMIN_BAN_LIST_MANAGEMENT, icon: <BanIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'صندوق پیشنهادات و انتقادات', view: ViewState.ADMIN_FEEDBACKS_VIEW, icon: <InboxIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'تاریخچه تورنومنت‌ها', view: ViewState.TOURNAMENT_HISTORY, icon: <ListBulletIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
    { label: 'تغییر مشخصات ورود', view: ViewState.ADMIN_CREDENTIALS_MANAGEMENT, icon: <KeyIcon className="w-7 h-7 rtl:ml-3 ltr:mr-3 text-softUI-adminOptionIcon group-hover:text-softUI-primary transition-colors" /> },
  ];

  return (
    <div
      className={`fixed inset-0 z-[70] flex items-center justify-center p-4 bg-softUI-modalOverlay backdrop-blur-sm
                  transition-opacity duration-300 ease-out ${isOpen ? 'opacity-100 visible modal-overlay-shown' : 'opacity-0 invisible'}`}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-dashboard-modal-title"
    >
      <div
        className={`bg-softUI-card rounded-2xl shadow-xl w-full max-w-2xl transform transition-all duration-300 ease-out
                    max-h-[80vh] flex flex-col
                    ${isOpen ? 'animate-modal-enter modal-content-shown' : 'animate-modal-leave'}`}
        onClick={(e) => e.stopPropagation()} // Prevent click inside from closing modal
      >
        <div className="flex justify-between items-center p-5 border-b border-softUI-inputBorder">
          <h2 id="admin-dashboard-modal-title" className="text-2xl font-bold text-softUI-textPrimary">
            اختیارات ادمین آکو
          </h2>
          <Button
            onClick={onClose}
            variant="custom"
            className="p-2 rounded-full hover:bg-softUI-inputBg focus:outline-none focus:ring-2 focus:ring-softUI-primary focus:ring-offset-2 focus:ring-offset-softUI-card"
            aria-label="بستن مودال"
          >
            <XMarkIcon className="w-6 h-6 text-softUI-textSecondary" />
          </Button>
        </div>

        <div className="p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 overflow-y-auto">
          {adminOptions.map((opt) => (
            <Button
              key={opt.view}
              onClick={() => {
                onNavigate(opt.view);
                onClose();
              }}
              variant="softUIDashboardOption"
              className="group admin-options-button-glow text-lg font-semibold !py-5 !px-5" // Increased padding
              neonEffect // Enable neon glow on hover/focus
            >
              {opt.icon}
              <span>{opt.label}</span>
            </Button>
          ))}
        </div>
        <div className="p-4 border-t border-softUI-inputBorder text-center">
            <Button onClick={onClose} variant="softUILink" size="md">بستن</Button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardModal;
