import React from 'react';

const FemaleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={`w-6 h-6 ${className}`} // Base size, can be overridden
    aria-hidden="true"
  >
    <path 
      d="M12 12.75a4.75 4.75 0 100-9.5 4.75 4.75 0 000 9.5zm0 0V21m-3-3h6" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
    />
  </svg>
);

export default FemaleIcon;