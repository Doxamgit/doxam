
export interface Player {
  id: string;
  name: string;
}

export interface Participant {
  id: string; // For individual: AkoAdmin.id or generated. For team: generated team ID.
  name: string; // For individual: player name. For team: team name.
  members?: Player[]; // For team: array of players (typically 2). Undefined or empty for individual.
}

export interface Match {
  id: string;
  participant1: Participant | null;
  participant2: Participant | null;
  winner: Participant | null;
  roundIndex: number;
  matchIndex: number; // Index of match within its round
  isPlaceholder?: boolean; // True if this match slot is waiting for winners from previous round
}

export interface Round {
  id: string;
  name: string; // e.g., "Round 1", "Quarterfinals"
  matches: Match[];
  isCompleted: boolean;
}

export type TournamentType = 'individual' | 'team'; // Removed 'league'

// --- Game Management Type ---
export interface Game {
  id: string;
  name: string;
}
// --- End of Game Management Type ---

export interface Tournament {
  id: string;
  customName: string; // User-defined tournament name
  eventDateTime: string; // ISO string for date and time
  
  // For bracket-based tournaments (individual/team)
  participants: Participant[]; 
  initialParticipantCount: number; 
  rounds: Round[];
  currentRoundIndex: number; 
  finalWinner?: Participant | null;
  
  status: 'pending' | 'setup' | 'active' | 'completed' | 'awaiting_archival';
  participantEntryMode: 'manual'; 
  tournamentType: TournamentType; 
}

export interface ArchivedTournament extends Omit<Tournament, 'status' | 'currentRoundIndex' | 'participantEntryMode' | 'tournamentType'> {
  status: 'completed';
  completedTimestamp: number;
  participantEntryMode: 'manual'; 
  tournamentType: TournamentType; 
  participants: Participant[]; 
}


export interface NewsItem {
  id: string;
  title: string;
  content: string;
  timestamp: number;
}

export type AkoAdminRole = 'owner' | 'admin' | 'moderator' | 'user';
export type Gender = 'male' | 'female' | 'other' | ''; // '' for unselected or not specified

export interface AkoAdmin {
  id: string;
  name: string; 
  role: AkoAdminRole;
  userCode?: string; 
  
  platoUsername?: string;
  age?: number;
  gender?: Gender;

  professionalismScore?: number;
  activityAvailabilityScore?: number;
  problemSolvingScore?: number;
  averageRating?: number; 

  ruleAdherenceScore?: number;
  respectScore?: number;
  contentAccuracyScore?: number;
}

export interface FeedbackEntry {
  id: string;
  platoId: string;
  userCode: string;
  message: string;
  timestamp: number;
  isRead: boolean;
  isArchived: boolean;
}

export interface BannedUser {
  platoUsername: string;
  timestamp: number;
  bannedBy?: string; 
  reason?: string; 
}


export enum ViewState {
  HOME = 'HOME',
  USER_PANEL_VIEW = 'USER_PANEL_VIEW', 
  ADMIN_LOGIN = 'ADMIN_LOGIN',
  ADMIN_DASHBOARD = 'ADMIN_DASHBOARD', 
  TOURNAMENT_SETUP = 'TOURNAMENT_SETUP', // For Individual/Team bracket setup
  // LEAGUE_TOURNAMENT_SETUP = 'LEAGUE_TOURNAMENT_SETUP', // Removed
  BRACKET_VIEW = 'BRACKET_VIEW', 
  ADMIN_NEWS_MANAGEMENT = 'ADMIN_NEWS_MANAGEMENT',
  TOURNAMENT_HISTORY = 'TOURNAMENT_HISTORY',
  ADMIN_RULES_MANAGEMENT = 'ADMIN_RULES_MANAGEMENT',
  ADMIN_CREDENTIALS_MANAGEMENT = 'ADMIN_CREDENTIALS_MANAGEMENT',
  ADMIN_AKO_ADMINS_MANAGEMENT = 'ADMIN_AKO_ADMINS_MANAGEMENT',
  ADMIN_FEEDBACKS_VIEW = 'ADMIN_FEEDBACKS_VIEW',
  ADMIN_GAMES_MANAGEMENT = 'ADMIN_GAMES_MANAGEMENT', 
  
  USER_PANEL_TOURNAMENT_DETAILS_VIEW = 'USER_PANEL_TOURNAMENT_DETAILS_VIEW',
  USER_PANEL_NEWS_DETAILS_VIEW = 'USER_PANEL_NEWS_DETAILS_VIEW',
  USER_PANEL_RULES_DETAILS_VIEW = 'USER_PANEL_RULES_DETAILS_VIEW',
  USER_PANEL_TEAM_DETAILS_VIEW = 'USER_PANEL_TEAM_DETAILS_VIEW',

  ADMIN_BAN_LIST_MANAGEMENT = 'ADMIN_BAN_LIST_MANAGEMENT',
}