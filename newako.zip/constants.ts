
export const APP_TITLE = "تورنومنت گپ آکو";

// Admin Credentials
export const DEFAULT_ADMIN_USERNAME = "Akoid"; // Default username if none in localStorage
export const ADMIN_PASSWORD = "Manvaredmisham"; // Default password if none in localStorage / initial password
export const LOCAL_STORAGE_ADMIN_USERNAME_KEY = "tournamentGapAcoAdminUsername";
export const LOCAL_STORAGE_ADMIN_PASSWORD_KEY = "tournamentGapAcoAdminPassword";

export const PARTICIPANT_COUNT_OPTIONS = [2, 4, 8, 16, 32, 64];
export const LOCAL_STORAGE_KEY = "tournamentGapAcoData"; // For active tournament
export const LOCAL_STORAGE_NEWS_KEY = "tournamentGapAcoNews";
export const LOCAL_STORAGE_HISTORY_KEY = "tournamentGapAcoHistory"; // For archived tournaments
export const LOCAL_STORAGE_RULES_KEY = "tournamentGapAcoRules"; // For Ako Rules
export const LOCAL_STORAGE_AKO_ADMINS_KEY = "tournamentGapAcoAdmins"; // For Ako Admins
export const LOCAL_STORAGE_FEEDBACKS_KEY = "tournamentGapAcoFeedbacks"; // For Feedbacks
export const LOCAL_STORAGE_BAN_LIST_KEY = "tournamentGapAcoBanList"; 
export const LOCAL_STORAGE_GAMES_KEY = "tournamentGapAcoGames"; // New key for games list


export const ROUND_NAMES_DEFAULT: { [key: number]: string } = {
  1: "فینال",
  2: "نیمه نهایی",
  4: "یک چهارم نهایی",
  8: "یک هشتم نهایی", // More common than "مرحله ۱۶ تیمی" for general use
  16: "مرحله ۳۲ تیمی", // Or "یک شانزدهم نهایی" but "مرحله X تیمی" is clearer
  32: "مرحله ۶۴ تیمی", // Or "یک سی و دوم نهایی"
};

export function getRoundName(numMatchesInRound: number, totalRounds: number, currentRoundNumber: number): string {
  if (numMatchesInRound === 1) return "فینال";
  if (numMatchesInRound === 2) return "نیمه نهایی";
  if (numMatchesInRound === 4) return "یک چهارم نهایی";
  // For rounds like Round of 16, Round of 32 etc., it's often referred to by number of teams
  const teamsRemaining = numMatchesInRound * 2;
  if (teamsRemaining === 8 && totalRounds >=4) return ROUND_NAMES_DEFAULT[4]; // Quarterfinals
  if (teamsRemaining === 16 && totalRounds >=5) return ROUND_NAMES_DEFAULT[8]; // Round of 16
  if (teamsRemaining === 32 && totalRounds >=6) return ROUND_NAMES_DEFAULT[16]; // Round of 32
  if (teamsRemaining === 64 && totalRounds >=7) return ROUND_NAMES_DEFAULT[32]; // Round of 64
  
  return `مرحله ${currentRoundNumber}`;
}

export const RANDOM_TEAM_NAMES: string[] = [
  "تیم اژدهای سرخ", "عقاب‌های طلایی", "گرگ‌های شمالی", "شیرهای غران", "ببرهای وحشی", 
  "کبراهای سمی", "رعدهای آسمانی", "طوفان‌های ویرانگر", "ققنوس‌های آتشین", "سایه‌های مرموز",
  "مبارزان کهکشان", "جنگجویان دلیر", "ستارگان درخشان", "غول‌های شکست‌ناپذیر", "افسانه‌های فراموش‌نشدنی"
];

// This list will now also be used for random individual participant names in TournamentSetup
export const RANDOM_PLAYER_NICKNAMES_FOR_TEAMS: string[] = [
  "تیرانداز دقیق", "دیوار پولادین", "مهاجم برق‌آسا", "استاد تاکتیک", "بازیکن کلیدی", 
  "شکارچی فرصت‌ها", "فرمانده میدان", "صخره استوار", "روح تیم", "ماشین گلزنی",
  "جادوگر توپ", "سد محکم", "موتور خستگی‌ناپذیر", "ذهن خلاق", "ناجی تیم",
  "سلطان دریبل", "قاتل خاموش", "ژنرال خط میانی", "عقرب زرد", "کوه یخ",
  "تندباد ویرانگر", "مار خوش خط و خال", "کابوس حریفان", "مدافع خستگی ناپذیر", "آقای گل",
  "بازیکن افسانه ای", "ماشین جنگی", "گلادیاتور میدان", "قهرمان بی بدیل", "ستاره بی چون و چرا"
];

export const DEFAULT_GAMES_LIST: string[] = [
  "Ocho", "Pool", "Carrom", "Match Monster", "Brawlbots", "Mini Golf", "Table Soccer", "Bounce", 
  "Bowling", "Word Box", "Plox", "Disc-O", "Ludo", "Bingo", "Blitz League", "Archery", "Skeeball", 
  "Four in a row", "Dominoes", "Backgammon", "Plato Land", "Cribbage", "Bankroll", "Dice Party", 
  "Gin Rummy", "Darts", "Go Fish", "Chess", "Sea Battles", "Spades", "Hold'em", "Bloko", "Mancala", 
  "Werewolf", "Dots & Boxes", "Basketball", "Cup Pong", "Bullshit", "Checkers", "Truco", 
  "Minesweeper", "Literati", "Old Zombie", "Big Two", "Reversi"
];
