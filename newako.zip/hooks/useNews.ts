
import { useState, useCallback, useEffect } from 'react';
import type { NewsItem } from '../types';
import { LOCAL_STORAGE_NEWS_KEY } from '../constants';

export const useNews = () => {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [isLoadingNews, setIsLoadingNews] = useState<boolean>(true);
  const [newsError, setNewsError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoadingNews(true);
    try {
      const savedNewsData = localStorage.getItem(LOCAL_STORAGE_NEWS_KEY);
      if (savedNewsData) {
        const parsedNews: NewsItem[] = JSON.parse(savedNewsData);
        if (Array.isArray(parsedNews) && parsedNews.every(item => item.id && item.title && typeof item.content === 'string' && item.timestamp)) {
          setNewsItems(parsedNews.sort((a, b) => b.timestamp - a.timestamp));
        } else {
          localStorage.removeItem(LOCAL_STORAGE_NEWS_KEY);
        }
      }
    } catch (e) {
      console.error("Failed to load news from local storage:", e);
      setNewsError("خطا در بارگذاری اخبار.");
      localStorage.removeItem(LOCAL_STORAGE_NEWS_KEY);
    }
    setIsLoadingNews(false);
  }, []);

  const saveNews = useCallback((updatedNewsItems: NewsItem[]) => {
    const sortedNews = updatedNewsItems.sort((a, b) => b.timestamp - a.timestamp);
    setNewsItems(sortedNews);
    localStorage.setItem(LOCAL_STORAGE_NEWS_KEY, JSON.stringify(sortedNews));
  }, []);

  const addNewsItem = useCallback((title: string, content: string) => {
    setNewsError(null);
    if (!title.trim() || !content.trim()) {
      setNewsError("عنوان و محتوای خبر نمی‌توانند خالی باشند.");
      return false;
    }
    const newItem: NewsItem = {
      id: `news-${Date.now()}`,
      title: title.trim(),
      content: content.trim(),
      timestamp: Date.now(),
    };
    saveNews([newItem, ...newsItems]);
    return true;
  }, [newsItems, saveNews]);

  const deleteNewsItem = useCallback((newsId: string) => {
    setNewsError(null);
    const updatedNews = newsItems.filter(item => item.id !== newsId);
    if (updatedNews.length === newsItems.length) {
      setNewsError("مورد خبری برای حذف یافت نشد.");
      return;
    }
    saveNews(updatedNews);
  }, [newsItems, saveNews]);
  
  const updateSetNewsError = useCallback((message: string | null) => {
    setNewsError(message);
  }, []);

  return {
    newsItems,
    isLoadingNews,
    newsError,
    addNewsItem,
    deleteNewsItem,
    setNewsError: updateSetNewsError, 
  };
};
