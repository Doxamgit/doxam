
import { useState, useCallback, useEffect } from 'react';
import type { Tournament, Participant, Round, Match, TournamentType } from '../types';
import { LOCAL_STORAGE_KEY, getRoundName }
from '../constants';

// Utility to shuffle an array
function shuffleArray<T,>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export const useTournament = () => {
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    setIsLoading(true);
    try {
      const savedTournamentData = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (savedTournamentData) {
        const parsedTournament: any = JSON.parse(savedTournamentData); // Parse as any initially for migration
        if (parsedTournament && parsedTournament.id) {
          // @ts-ignore 
          if (parsedTournament.participantEntryMode && parsedTournament.participantEntryMode !== 'manual') {
             // @ts-ignore
            parsedTournament.participantEntryMode = 'manual';
          } else if (!parsedTournament.participantEntryMode) {
             // @ts-ignore
            parsedTournament.participantEntryMode = 'manual';
          }
           // @ts-ignore 
          delete parsedTournament.registrationOpen; 
          
          // Ensure tournamentType is valid and remove old league types
          if (parsedTournament.tournamentType === 'league' || (parsedTournament.tournamentType !== 'individual' && parsedTournament.tournamentType !== 'team')) {
            // If a league tournament is found or type is invalid, clear it as it's no longer supported or needs reset
            localStorage.removeItem(LOCAL_STORAGE_KEY);
            setTournament(null);
            setIsLoading(false);
            return;
          }
          
          // Remove league specific fields if they exist from older versions
          delete parsedTournament.numberOfLeagues;
          delete parsedTournament.leagues;
          delete parsedTournament.availableGameNames;


          if (parsedTournament.status === 'awaiting_archival' && !parsedTournament.finalWinner) {
             parsedTournament.status = 'active'; 
          }
          setTournament(parsedTournament as Tournament);
        } else {
          localStorage.removeItem(LOCAL_STORAGE_KEY); 
        }
      }
    } catch (e) {
      console.error("Failed to load tournament from local storage:", e);
      localStorage.removeItem(LOCAL_STORAGE_KEY); 
    }
    setIsLoading(false);
  }, []);

  const saveTournament = useCallback((updatedTournament: Tournament | null) => {
    setTournament(updatedTournament);
    if (updatedTournament) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedTournament));
    } else {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  }, []);

  const createTournamentShell = useCallback((
    customName: string, 
    eventDateTime: string,
    bracketTargetParticipantCount: number, 
    tournamentType: TournamentType
  ) => {
    setError(null);
    if (!customName.trim()) {
      setError("نام تورنومنت نمی‌تواند خالی باشد.");
      return null;
    }
    if (!eventDateTime) {
      setError("تاریخ و ساعت تورنومنت مشخص نشده است.");
      return null;
    }
    // 'league' type is already excluded by TournamentType
    if (!tournamentType || (tournamentType !== 'individual' && tournamentType !== 'team')) {
        setError("نوع تورنومنت نامعتبر است. باید 'انفرادی' یا 'تیمی' باشد.");
        return null;
    }

    const baseTournamentData: Omit<Tournament, 'id' | 'initialParticipantCount'> = {
      customName: customName.trim(),
      eventDateTime,
      participants: [], 
      rounds: [], 
      currentRoundIndex: 0,
      status: 'setup', 
      finalWinner: null,
      participantEntryMode: 'manual',
      tournamentType: tournamentType,
    };
    
    let newTournament: Tournament;

    // Individual or Team (bracket-based)
    if (bracketTargetParticipantCount < 2 || (bracketTargetParticipantCount & (bracketTargetParticipantCount - 1)) !== 0) {
        setError("تعداد شرکت‌کنندگان/تیم‌ها باید توانی از ۲ باشد (مثلاً ۲، ۴، ۸، ...).");
        return null;
    }
    newTournament = {
        ...baseTournamentData,
        id: `tournament-${Date.now()}`,
        initialParticipantCount: bracketTargetParticipantCount,
    };
    

    saveTournament(newTournament);
    return newTournament;
  }, [saveTournament, setError]);


  const finalizeAndStartTournament = useCallback((tournamentId: string, finalParticipants: Participant[]) => {
    let currentTournament = tournament; 
    const storedTournamentData = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (storedTournamentData) {
      const parsed: Tournament = JSON.parse(storedTournamentData);
      if (parsed && parsed.id === tournamentId) {
        currentTournament = parsed;
      }
    }

    if (!currentTournament || currentTournament.id !== tournamentId || currentTournament.status !== 'setup') {
      setError("تورنومنت برای شروع آماده نیست یا تورنومنت فعال دیگری در جریان است.");
      return;
    }
    // 'league' type is excluded by TournamentType, no specific check needed here

    if (finalParticipants.length !== currentTournament.initialParticipantCount) {
      setError(`تعداد شرکت‌کنندگان/تیم‌های انتخاب شده (${finalParticipants.length}) با تعداد هدف تورنومنت (${currentTournament.initialParticipantCount}) مطابقت ندارد.`);
      return;
    }
     if ((finalParticipants.length & (finalParticipants.length - 1)) !== 0 && finalParticipants.length > 0) {
      setError("تعداد نهایی شرکت‌کنندگان/تیم‌ها باید توانی از ۲ باشد.");
      return;
    }
    if (finalParticipants.length < 2) {
       setError("حداقل ۲ شرکت‌کننده/تیم برای شروع تورنومنت لازم است.");
      return;
    }
    
    const namesOrIds = finalParticipants.map(p => p.name.toLowerCase().trim()); // For both individual (name) and team (name)
    if (new Set(namesOrIds).size !== namesOrIds.length) {
        setError(currentTournament.tournamentType === 'individual' ? "نام شرکت‌کنندگان نباید تکراری باشد." : "نام تیم‌ها نباید تکراری باشد.");
        return;
    }

    setError(null);
    const shuffledParticipants = shuffleArray(finalParticipants);
    const initialRoundMatches: Match[] = [];
    for (let i = 0; i < shuffledParticipants.length; i += 2) {
      initialRoundMatches.push({
        id: `match-${Date.now()}-${i}`,
        participant1: shuffledParticipants[i],
        participant2: shuffledParticipants[i + 1],
        winner: null,
        roundIndex: 0,
        matchIndex: i / 2,
      });
    }
    
    const totalRounds = Math.log2(shuffledParticipants.length);
    const firstRoundName = getRoundName(initialRoundMatches.length, totalRounds, 1);

    const initialRound: Round = {
      id: `round-0-${Date.now()}`,
      name: firstRoundName,
      matches: initialRoundMatches,
      isCompleted: false,
    };

    const updatedTournament: Tournament = {
      ...currentTournament,
      participants: [...finalParticipants], 
      rounds: [initialRound],
      currentRoundIndex: 0,
      status: 'active',
    };
    saveTournament(updatedTournament);

  }, [tournament, saveTournament, setError]);


  const selectWinner = useCallback((roundIndex: number, matchIndex: number, winnerParticipant: Participant) => {
    if (!tournament || (tournament.status !== 'active' && tournament.status !== 'awaiting_archival')) return;
    // 'league' type is excluded by TournamentType, no specific check needed here
    
    let errorOccurred = false;
    if (tournament.status === 'awaiting_archival' && tournament.rounds[roundIndex]?.matches[matchIndex]?.id !== tournament.rounds[tournament.rounds.length -1]?.matches[0]?.id) {
      setError("تورنومنت منتظر آرشیو است. فقط نتیجه فینال قابل تغییر است.");
      return;
    }
    setError(null);

    const updatedRounds = tournament.rounds.map((round, rIdx) => {
      if (rIdx === roundIndex) {
        const updatedMatches = round.matches.map((match, mIdx) => {
          if (mIdx === matchIndex) {
            const nextRoundIndex = roundIndex + 1;
            if (tournament.rounds[nextRoundIndex] && tournament.rounds[nextRoundIndex].matches.length > 0) {
                const participationsInNextRoundAsP1 = tournament.rounds[nextRoundIndex].matches.map(m => m.participant1?.id).filter(Boolean);
                const participationsInNextRoundAsP2 = tournament.rounds[nextRoundIndex].matches.map(m => m.participant2?.id).filter(Boolean);
                
                const currentMatchParticipant1Id = match.participant1?.id;
                const currentMatchParticipant2Id = match.participant2?.id;

                if (match.winner && match.winner.id !== winnerParticipant.id) { 
                    let isP1Locked = false;
                    if (currentMatchParticipant1Id) {
                        isP1Locked = participationsInNextRoundAsP1.includes(currentMatchParticipant1Id) || 
                                     participationsInNextRoundAsP2.includes(currentMatchParticipant1Id);
                    }

                    let isP2Locked = false;
                    if (currentMatchParticipant2Id) {
                        isP2Locked = participationsInNextRoundAsP1.includes(currentMatchParticipant2Id) || 
                                     participationsInNextRoundAsP2.includes(currentMatchParticipant2Id);
                    }

                    if (match.winner.id === currentMatchParticipant1Id && isP1Locked) {
                         setError("نمی‌توان برنده را تغییر داد. بازیکن ۱ از این مسابقه در مرحله بعد قفل شده است.");
                         errorOccurred = true;
                         return match;
                    }
                    if (match.winner.id === currentMatchParticipant2Id && isP2Locked) {
                        setError("نمی‌توان برنده را تغییر داد. بازیکن ۲ از این مسابقه در مرحله بعد قفل شده است.");
                        errorOccurred = true;
                        return match;
                    }
                }
            }
            if (errorOccurred) return match;
            return { ...match, winner: winnerParticipant };
          }
          return match;
        });
        
        if (errorOccurred) return round;

        const allMatchesInRoundHaveWinner = updatedMatches.every(m => m.winner !== null);
        return { ...round, matches: updatedMatches, isCompleted: allMatchesInRoundHaveWinner };
      }
      return round;
    });
    
    if (!errorOccurred) {
        saveTournament({ ...tournament, rounds: updatedRounds });
    }
  }, [tournament, saveTournament, setError]);

  const advanceToNextRound = useCallback(() => {
    if (!tournament || tournament.status !== 'active') return;
    // 'league' type is excluded by TournamentType, no specific check needed here
    setError(null);

    const currentRound = tournament.rounds[tournament.currentRoundIndex];
    if (!currentRound || !currentRound.isCompleted) {
      setError("مرحله فعلی هنوز تکمیل نشده است. تمام مسابقات باید برنده داشته باشند.");
      return;
    }

    if (currentRound.matches.length === 1 && currentRound.matches[0].winner) { 
      saveTournament({
        ...tournament,
        status: 'awaiting_archival', 
        finalWinner: currentRound.matches[0].winner,
      });
      return;
    }

    const winners = currentRound.matches.map(match => match.winner).filter(Boolean) as Participant[];
    if (winners.length === 0 || (winners.length % 2 !== 0 && winners.length !==1) ) {
       setError("خطا در جمع‌آوری برندگان برای مرحله بعد.");
       return;
    }

    const nextRoundMatches: Match[] = [];
    for (let i = 0; i < winners.length; i += 2) {
      nextRoundMatches.push({
        id: `match-${Date.now()}-${i}`,
        participant1: winners[i],
        participant2: winners[i + 1],
        winner: null,
        roundIndex: tournament.currentRoundIndex + 1,
        matchIndex: i / 2,
      });
    }

    const totalRounds = Math.log2(tournament.initialParticipantCount);
    const nextRoundName = getRoundName(nextRoundMatches.length, totalRounds, tournament.currentRoundIndex + 2);

    const nextRound: Round = {
      id: `round-${tournament.currentRoundIndex + 1}-${Date.now()}`,
      name: nextRoundName,
      matches: nextRoundMatches,
      isCompleted: false,
    };

    saveTournament({
      ...tournament,
      rounds: [...tournament.rounds, nextRound],
      currentRoundIndex: tournament.currentRoundIndex + 1,
    });
  }, [tournament, saveTournament, setError]);

  const resetActiveTournament = useCallback(() => {
    setError(null);
    saveTournament(null); 
  }, [saveTournament, setError]);


  return {
    tournament,
    isLoading,
    error,
    createTournamentShell,
    finalizeAndStartTournament,
    selectWinner,
    advanceToNextRound,
    resetActiveTournament, 
    setError, 
  };
};
