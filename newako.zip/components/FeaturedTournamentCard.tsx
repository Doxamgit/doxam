
import React from 'react';
import type { Tournament } from '../types';
import Button from './Button';
import CalendarDaysIcon from './CalendarDaysIcon'; // Placeholder, you'll need to create this
import InformationCircleIcon from './InformationCircleIcon'; // Placeholder

interface FeaturedTournamentCardProps {
  tournament: Tournament | null;
  onViewTournamentClick: () => void;
}

const formatEventDateTimeForCard = (isoString: string) => {
  if (!isoString) return "نامشخص";
  try {
    const date = new Date(isoString);
    return date.toLocaleString('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (e) {
    return "تاریخ نامعتبر";
  }
};

const getSimplifiedStatus = (status: Tournament['status'] | undefined): string => {
  if (!status) return "";
  switch (status) {
    case 'active':
      return "در حال برگزاری";
    case 'setup':
      return "به زودی آغاز می‌شود";
    case 'awaiting_archival':
      return "مراحل پایانی";
    default:
      return "";
  }
};

const FeaturedTournamentCard: React.FC<FeaturedTournamentCardProps> = ({ tournament, onViewTournamentClick }) => {
  const isRelevantTournament = tournament && (tournament.status === 'active' || tournament.status === 'setup' || tournament.status === 'awaiting_archival');

  return (
    <div className="w-full max-w-xl mx-auto mt-12 p-6 sm:p-8 bg-surface-artisticTealPoemPanel rounded-xl shadow-xl border border-brand-artisticGoldAccent/40 animate-fadeIn transition-all duration-300 hover:shadow-2xl hover:border-brand-artisticGoldAccent/60">
      {isRelevantTournament && tournament ? (
        <>
          <h3 className="text-2xl sm:text-3xl font-bold text-brand-artisticGoldAccent mb-6 text-center">
            تورنومنت ویژه
          </h3>
          <div className="space-y-4 text-text-onArtisticTealPrimary">
            <h4 className="text-xl sm:text-2xl font-semibold text-center mb-3">{tournament.customName}</h4>
            
            <div className="flex items-center justify-center text-sm sm:text-base text-text-onArtisticTealSecondary">
              <CalendarDaysIcon className="w-5 h-5 ml-2 rtl:mr-2 rtl:ml-0 text-brand-artisticGoldAccent/80" />
              <span>تاریخ برگزاری: {formatEventDateTimeForCard(tournament.eventDateTime)}</span>
            </div>

            {tournament.status && getSimplifiedStatus(tournament.status) && (
              <div className="flex items-center justify-center text-sm sm:text-base text-text-onArtisticTealSecondary">
                <InformationCircleIcon className="w-5 h-5 ml-2 rtl:mr-2 rtl:ml-0 text-brand-artisticGoldAccent/80" />
                <span>وضعیت: {getSimplifiedStatus(tournament.status)}</span>
              </div>
            )}
          </div>
          <div className="mt-8 text-center">
            <Button
              onClick={onViewTournamentClick}
              variant="artisticGold"
              size="lg"
              className="!rounded-full px-8"
              focusRingOffsetColor="focus:ring-offset-surface-artisticTealPoemPanel"
            >
              مشاهده جزئیات تورنومنت
            </Button>
          </div>
        </>
      ) : (
        <>
          <h3 className="text-2xl sm:text-3xl font-bold text-brand-artisticGoldAccent mb-6 text-center">
            رویدادهای آکو
          </h3>
          <p className="text-lg text-text-onArtisticTealSecondary text-center leading-relaxed">
            در حال حاضر تورنومنت فعالی برنامه‌ریزی نشده است. <br /> منتظر رویدادهای بعدی ما باشید!
          </p>
          <div className="mt-8 text-center">
            <Button
              onClick={onViewTournamentClick} // This will lead to USER_PANEL_VIEW via App.tsx logic
              variant="artisticOutline"
              size="lg"
              className="!rounded-full px-8"
              focusRingOffsetColor="focus:ring-offset-surface-artisticTealPoemPanel"
            >
              ورود به پنل کاربران
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default FeaturedTournamentCard;
