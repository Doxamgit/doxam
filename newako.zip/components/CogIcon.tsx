
import React from 'react';

const CogIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m18 0h-1.5m-15.036-7.026A7.5 7.5 0 0112 4.5v1.5m0 13.5v-1.5a7.5 7.5 0 01-7.5-7.5H3m18 0h-1.5a7.5 7.5 0 01-7.5 7.5v1.5m0-13.5V3M12 12a3 3 0 110-6 3 3 0 010 6z" />
  </svg>
);

export default CogIcon;
