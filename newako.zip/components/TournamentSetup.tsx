
import React, { useState, useEffect, useCallback } from 'react';
import type { Participant, Player, Tournament, TournamentType, AkoAdmin } from '../types';
import { PARTICIPANT_COUNT_OPTIONS, RANDOM_TEAM_NAMES, RANDOM_PLAYER_NICKNAMES_FOR_TEAMS } from '../constants';
import Button from './Button';
import Input from './Input';
import Select from './Select';
import ConfirmationModal from './ConfirmationModal';
import ArrowRightIcon from './ArrowRightIcon';
import UserCircleIcon from './UserCircleIcon'; 
import TrashIcon from './TrashIcon';
import UsersGroupIcon from './UsersGroupIcon'; // For team icon
import RefreshIcon from './RefreshIcon'; // For Random Fill button

// Utility to shuffle an array
function shuffleArray<T,>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}


interface TeamDetailsInput {
  id: string; // Temporary client-side ID for the input row
  teamName: string;
  player1Name: string;
  player2Name: string;
}

interface TournamentSetupProps {
  onCreateTournamentShell: (tournamentName: string, eventDateTime: string, targetParticipantCount: number, tournamentType: TournamentType) => Tournament | null;
  onFinalizeAndStartTournament: (tournamentId: string, finalParticipants: Participant[]) => void;
  onDeleteTournamentShell?: () => void;
  currentTournament: Tournament | null; 
  akoUsers: AkoAdmin[]; 
  hookError?: string | null;
  clearHookError?: () => void;
  currentTheme?: 'default' | 'versace' | 'softUI';
  initialTournamentType?: TournamentType | null; // This will be 'individual' or 'team'
}


const TournamentSetup: React.FC<TournamentSetupProps> = ({
  onCreateTournamentShell,
  onFinalizeAndStartTournament,
  onDeleteTournamentShell,
  currentTournament,
  akoUsers = [], 
  hookError,
  clearHookError,
  currentTheme = 'default',
  initialTournamentType // Should be 'individual' or 'team' from App.tsx
}) => {
  const [tournamentName, setTournamentName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventTime, setEventTime] = useState('');
  const [targetParticipantCount, setTargetParticipantCount] = useState<number>(PARTICIPANT_COUNT_OPTIONS[2]);
  
  const [manualParticipantNames, setManualParticipantNames] = useState<string[]>([]); 
  const [manualTeamsData, setManualTeamsData] = useState<TeamDetailsInput[]>([]); 

  const [formError, setFormError] = useState<string | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  
  const effectiveTournamentType = 
    (currentTournament?.tournamentType === 'individual' || currentTournament?.tournamentType === 'team') 
    ? currentTournament.tournamentType 
    : initialTournamentType;

  const isEditingExistingShellOfThisType = 
    currentTournament && 
    currentTournament.status === 'setup' &&
    currentTournament.tournamentType === effectiveTournamentType &&
    (effectiveTournamentType === 'individual' || effectiveTournamentType === 'team');

  const canEditShellFields = !isEditingExistingShellOfThisType;

  const showCreateShellButton = 
    !isEditingExistingShellOfThisType &&
    effectiveTournamentType && 
    (effectiveTournamentType === 'individual' || effectiveTournamentType === 'team');

  const showParticipantEntrySection = isEditingExistingShellOfThisType;


  useEffect(() => {
    if (currentTournament && (currentTournament.tournamentType === 'individual' || currentTournament.tournamentType === 'team')) {
      setTournamentName(currentTournament.customName);
      if (currentTournament.eventDateTime) {
        const date = new Date(currentTournament.eventDateTime);
        setEventDate(date.toISOString().split('T')[0]);
        setEventTime(date.toTimeString().split(' ')[0].substring(0,5));
      } else {
        setEventDate('');
        setEventTime('');
      }
      setTargetParticipantCount(currentTournament.initialParticipantCount);

      if (currentTournament.status === 'setup') { // If it's a setup shell
        if (currentTournament.participants && currentTournament.participants.length > 0) { // And participants were already being entered
            if (currentTournament.tournamentType === 'individual') {
               setManualParticipantNames(currentTournament.participants.map(p => p.name));
               setManualTeamsData([]); 
            } else if (currentTournament.tournamentType === 'team') {
              const teams: TeamDetailsInput[] = currentTournament.participants.map((p) => ({
                  id: p.id, 
                  teamName: p.name,
                  player1Name: p.members?.[0]?.name || '',
                  player2Name: p.members?.[1]?.name || '',
              }));
              setManualTeamsData(teams);
              setManualParticipantNames([]); 
            }
        } else { // Shell exists, but no participants entered yet, initialize fields based on count and type
          if (currentTournament.tournamentType === 'individual') {
              setManualParticipantNames(Array(currentTournament.initialParticipantCount).fill(''));
              setManualTeamsData([]);
          } else if (currentTournament.tournamentType === 'team') {
              setManualTeamsData(Array.from({ length: currentTournament.initialParticipantCount }, (_, i) => ({
                  id: `new-team-input-${i}-${Date.now()}`, teamName: '', player1Name: '', player2Name: '',
                })));
              setManualParticipantNames([]);
          }
        }
      } else { // Not a setup shell (e.g. active, completed, or pending) - treat as new shell creation
        const initialCount = PARTICIPANT_COUNT_OPTIONS[2];
        setTargetParticipantCount(initialCount);
        if (effectiveTournamentType === 'individual') {
            setManualParticipantNames(Array(initialCount).fill(''));
            setManualTeamsData([]);
        } else if (effectiveTournamentType === 'team') {
            setManualTeamsData(Array.from({ length: initialCount }, (_, i) => ({
                id: `new-team-input-${i}-${Date.now()}`, teamName: '', player1Name: '', player2Name: '',
              })));
            setManualParticipantNames([]);
        }
      }
    } else { // No current tournament, or it's a league type (which is handled by initialTournamentType)
      setTournamentName('');
      setEventDate('');
      setEventTime('');
      const initialCount = PARTICIPANT_COUNT_OPTIONS[2]; 
      setTargetParticipantCount(initialCount); 

       if (effectiveTournamentType === 'individual') {
            setManualParticipantNames(Array(initialCount).fill(''));
            setManualTeamsData([]);
        } else if (effectiveTournamentType === 'team') {
            setManualTeamsData(Array.from({ length: initialCount }, (_, i) => ({
                id: `new-team-input-${i}-${Date.now()}`, teamName: '', player1Name: '', player2Name: '',
              })));
            setManualParticipantNames([]);
        } else { 
            setManualParticipantNames([]);
            setManualTeamsData([]);
        }
    }
  }, [currentTournament, initialTournamentType, effectiveTournamentType]);


  useEffect(() => {
    // This effect adjusts the input fields when targetParticipantCount changes,
    // only if we are in the shell creation phase OR if we are editing a shell (status === 'setup')
     if (canEditShellFields || (currentTournament && currentTournament.status === 'setup' && (currentTournament.tournamentType === 'individual' || currentTournament.tournamentType === 'team'))) {
        if (effectiveTournamentType === 'individual') {
            setManualParticipantNames(prevNames => {
                const newNames = Array(targetParticipantCount).fill('');
                for (let i = 0; i < Math.min(targetParticipantCount, prevNames.length); i++) {
                    newNames[i] = prevNames[i];
                }
                return newNames;
            });
        } else if (effectiveTournamentType === 'team') {
            setManualTeamsData(prevTeams => {
                const newTeams = Array.from({ length: targetParticipantCount }, (_, i) => {
                    if (i < prevTeams.length) {
                        return prevTeams[i];
                    }
                    return {
                        id: `new-team-input-${i}-${Date.now()}`,
                        teamName: '', player1Name: '', player2Name: '',
                    };
                });
                return newTeams;
            });
        }
    }
  }, [targetParticipantCount, effectiveTournamentType, canEditShellFields, currentTournament?.status, currentTournament?.tournamentType]);


  const handleGenericInputChange = () => {
    setFormError(null);
    clearHookError?.();
  };

  const handleManualParticipantNameChange = (index: number, name: string) => {
    const newNames = [...manualParticipantNames];
    newNames[index] = name;
    setManualParticipantNames(newNames);
    handleGenericInputChange();
  };
  
  const handleManualTeamDetailChange = (index: number, field: keyof Omit<TeamDetailsInput, 'id'>, value: string) => {
    const newTeamsData = [...manualTeamsData];
    newTeamsData[index] = { ...newTeamsData[index], [field]: value };
    setManualTeamsData(newTeamsData);
    handleGenericInputChange();
  };

  const handleCreateShell = (e: React.FormEvent) => {
    e.preventDefault();
    handleGenericInputChange();

    if (!effectiveTournamentType) { // Handles null or undefined
        setFormError("نوع تورنومنت نامعتبر است. این بخش فقط برای تورنومنت‌های انفرادی و یاری است.");
        return;
    }
    if (!tournamentName.trim()) {
      setFormError('نام تورنومنت الزامی است.');
      return;
    }
    if (!eventDate || !eventTime) {
      setFormError('تاریخ و ساعت تورنومنت الزامی است.');
      return;
    }
    const eventDateTimeISO = new Date(`${eventDate}T${eventTime}`).toISOString();
    onCreateTournamentShell(tournamentName, eventDateTimeISO, targetParticipantCount, effectiveTournamentType);
    // After shell creation, currentTournament prop will update, and useEffect will adjust UI to participant entry.
  };

  const handleFinalizeAndStart = () => {
    handleGenericInputChange();
    if (!currentTournament || currentTournament.status !== 'setup' || (currentTournament.tournamentType !== 'individual' && currentTournament.tournamentType !== 'team')) {
        setFormError("ابتدا پوسته تورنومنت (انفرادی/یاری) را ایجاد و ذخیره کنید.");
        return;
    }

    let finalParticipants: Participant[] = [];
    if (currentTournament.tournamentType === 'individual') {
        const filledNames = manualParticipantNames.slice(0, targetParticipantCount).filter(name => name.trim() !== '');
        if (filledNames.length !== targetParticipantCount) {
            setFormError(`لطفاً نام تمام ${targetParticipantCount} شرکت‌کننده را وارد کنید.`);
            return;
        }
        const uniqueNames = new Set(filledNames.map(name => name.trim().toLowerCase()));
        if (uniqueNames.size !== filledNames.length) {
            setFormError("نام شرکت‌کنندگان نباید تکراری باشد.");
            return;
        }
        finalParticipants = filledNames.map((name, index) => ({
             id: `manual-player-${index}-${Date.now()}`, 
             name: name.trim() 
        }));

    } else if (currentTournament.tournamentType === 'team') {
        const filledTeamDetails = manualTeamsData.slice(0, targetParticipantCount).filter(
          team => team.teamName.trim() !== '' && team.player1Name.trim() !== '' && team.player2Name.trim() !== ''
        );
        if (filledTeamDetails.length !== targetParticipantCount) {
          setFormError(`لطفاً نام تیم و نام هر دو بازیکن را برای تمام ${targetParticipantCount} تیم وارد کنید.`);
          return;
        }
        const uniqueTeamNames = new Set(filledTeamDetails.map(team => team.teamName.trim().toLowerCase()));
        if (uniqueTeamNames.size !== filledTeamDetails.length) {
          setFormError("نام تیم‌ها نباید تکراری باشد.");
          return;
        }
        for (const team of filledTeamDetails) {
            if (team.player1Name.trim().toLowerCase() === team.player2Name.trim().toLowerCase()) {
                setFormError(`در تیم "${team.teamName}", نام بازیکنان باید متفاوت باشد.`);
                return;
            }
        }
        finalParticipants = filledTeamDetails.map((teamDetail, index) => ({
          id: teamDetail.id.startsWith('new-team-input-') || teamDetail.id.startsWith('random-team-') ? `team-${Date.now()}-${index}` : teamDetail.id,
          name: teamDetail.teamName.trim(),
          members: [
            { id: `player-${teamDetail.id}-1-${Date.now()}`, name: teamDetail.player1Name.trim() },
            { id: `player-${teamDetail.id}-2-${Date.now()}`, name: teamDetail.player2Name.trim() },
          ],
        }));
    }
    onFinalizeAndStartTournament(currentTournament.id, finalParticipants);
  };

  const handleRandomFill = () => {
    handleGenericInputChange();
    // This button is only shown when showParticipantEntrySection is true (i.e. isEditingExistingShellOfThisType is true)
    // So currentTournament is guaranteed to be a setup shell of individual/team type.
    if (!currentTournament || currentTournament.status !== 'setup') {
        setFormError("خطای داخلی: پوسته تورنومنت برای پر کردن تصادفی آماده نیست.");
        return;
    }

    if (currentTournament.tournamentType === 'individual') {
        if (RANDOM_PLAYER_NICKNAMES_FOR_TEAMS.length < targetParticipantCount) {
            console.warn("تعداد نام‌های تصادفی بازیکنان کمتر از ظرفیت تورنومنت است.");
        }
        const shuffledNicknames = shuffleArray([...RANDOM_PLAYER_NICKNAMES_FOR_TEAMS]);
        const randomNames = Array(targetParticipantCount).fill('').map((_, index) => 
            shuffledNicknames[index % shuffledNicknames.length] || `بازیکن شانسی ${index + 1}`
        );
        setManualParticipantNames(randomNames);

    } else if (currentTournament.tournamentType === 'team') {
        if (RANDOM_TEAM_NAMES.length === 0 || RANDOM_PLAYER_NICKNAMES_FOR_TEAMS.length === 0) {
            setFormError("لیست نام‌های تصادفی از پیش تعریف شده خالی است.");
            return;
        }
        
        const shuffledTeamNames = shuffleArray([...RANDOM_TEAM_NAMES]);
        let availablePlayerNicknames = shuffleArray([...RANDOM_PLAYER_NICKNAMES_FOR_TEAMS]);
        
        const newTeamsData = Array.from({ length: targetParticipantCount }, (_, index) => {
            const teamName = shuffledTeamNames[index % shuffledTeamNames.length];
            
            if(availablePlayerNicknames.length < 2) { 
                 availablePlayerNicknames = shuffleArray([...RANDOM_PLAYER_NICKNAMES_FOR_TEAMS]);
            }
            const player1Name = availablePlayerNicknames.pop() || `بازیکن ${index * 2 + 1}`;
            const player2Name = availablePlayerNicknames.pop() || `بازیکن ${index * 2 + 2}`;

            return {
                id: `random-team-${Date.now()}-${index}`,
                teamName: teamName,
                player1Name: player1Name,
                player2Name: player2Name,
            };
        });
        setManualTeamsData(newTeamsData);
    }
  };

  const getTournamentTypeDisplay = (type: TournamentType | undefined | null): string => {
    if (!type) return "نامشخص";
    switch(type) {
        case 'individual': return "انفرادی";
        case 'team': return "یاری (تیمی)";
        default: return "نامشخص";
    }
  };

  const handleDeleteShellClick = () => {
    clearHookError?.();
    setFormError(null);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteShell = () => {
    if (onDeleteTournamentShell) {
      onDeleteTournamentShell();
      // Reset local form state after deletion confirmation
      setTournamentName('');
      setEventDate('');
      setEventTime('');
      const initialCount = PARTICIPANT_COUNT_OPTIONS[2];
      setTargetParticipantCount(initialCount);
      if (effectiveTournamentType === 'individual') {
        setManualParticipantNames(Array(initialCount).fill(''));
      } else if (effectiveTournamentType === 'team') {
        setManualTeamsData(Array.from({ length: initialCount }, (_, i) => ({
            id: `new-team-input-${i}-${Date.now()}`, teamName: '', player1Name: '', player2Name: '',
        })));
      }
    }
    setIsDeleteModalOpen(false);
  };

  const isSoftUITheme = currentTheme === 'softUI';
  const panelClasses = isSoftUITheme ? "bg-softUI-card rounded-2xl shadow-soft-ui-card p-6 md:p-10 border border-softUI-inputBorder" : "bg-surface-cosmicPanel rounded-2xl sm:rounded-3xl shadow-2xl p-6 md:p-8";
  const titleClasses = isSoftUITheme ? "text-3xl sm:text-4xl font-bold text-softUI-textPrimary mb-1 sm:mb-2 text-center" : "text-3xl sm:text-4xl font-extrabold mb-1 sm:mb-2 text-center text-text-cosmicPrimary";
  const subtitleClasses = isSoftUITheme ? "text-sm text-softUI-textSecondary mb-8 text-center" : "text-sm text-text-cosmicSecondary mb-8 text-center";
  const inputThemeProp = isSoftUITheme ? 'softUI' : 'default';
  const buttonPrimaryVariant = isSoftUITheme ? 'softUIPrimary' : 'cosmicAccent';
  const errorTextClass = isSoftUITheme ? 'text-red-600' : 'text-red-400';
  const errorBgClass = isSoftUITheme ? 'bg-red-100 border border-red-300' : 'bg-red-900/40';
  const deleteButtonClass = isSoftUITheme ? '!bg-red-500 hover:!bg-red-600 !text-white !border-transparent' : 'bg-red-600 hover:bg-red-700 text-white';
  const teamInputGroupBg = isSoftUITheme ? 'bg-softUI-inputBg/50 p-4 rounded-lg border border-softUI-inputBorder/70' : 'bg-surface-cosmicInput/30 p-4 rounded-lg border border-border-cosmicDefault/40';
  const randomFillButtonClass = isSoftUITheme ? `!bg-blue-100 !text-blue-700 hover:!bg-blue-200 !border-blue-300` : 'bg-blue-600 hover:bg-blue-700 text-white';


  return (
    <>
    <div className={`min-h-[calc(100vh-120px)] py-8 px-4 relative overflow-hidden animate-fadeIn ${isSoftUITheme ? "bg-softUI-bgPage" : "bg-brand-cosmicDarkBg"}`}>
      <div className={panelClasses}>
        <h2 className={titleClasses}>
            {showParticipantEntrySection ? 'تکمیل و شروع تورنومنت' : 'ایجاد تورنومنت (انفرادی/یاری)'}
        </h2>
        {effectiveTournamentType && (
             <p className={subtitleClasses}>
                نوع تورنومنت: <span className={isSoftUITheme ? 'font-semibold text-softUI-primary' : 'font-semibold text-brand-cosmicAccentOrange'}>{getTournamentTypeDisplay(effectiveTournamentType)}</span>
            </p>
        )}
        
        {(formError || hookError) && 
            <p className={`p-3 rounded-lg text-sm text-center py-2 mb-6 ${errorTextClass} ${errorBgClass}`}>
                {formError || hookError}
            </p>
        }

        <form onSubmit={handleCreateShell} className="space-y-6 mb-8">
          <Input
            label="نام تورنومنت"
            id="tournamentName"
            type="text"
            value={tournamentName}
            onChange={(e) => {setTournamentName(e.target.value); handleGenericInputChange();}}
            placeholder="مثال: جام قهرمانان آکو"
            required
            theme={inputThemeProp}
            className={`font-semibold ${isSoftUITheme ? '!rounded-xl' : 'rounded-xl'}`} 
            disabled={!canEditShellFields}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <Input
              label="تاریخ تورنومنت"
              id="eventDate"
              type="date"
              value={eventDate}
              onChange={(e) => {setEventDate(e.target.value); handleGenericInputChange();}}
              required
              theme={inputThemeProp}
              className={`font-bold ${isSoftUITheme ? '!rounded-xl' : 'rounded-xl'}`}
              disabled={!canEditShellFields}
            />
            <Input
              label="ساعت تورنومنت"
              id="eventTime"
              type="time"
              value={eventTime}
              onChange={(e) => {setEventTime(e.target.value); handleGenericInputChange();}}
              required
              theme={inputThemeProp}
              className={`font-bold ${isSoftUITheme ? '!rounded-xl' : 'rounded-xl'}`}
              disabled={!canEditShellFields}
            />
          </div>
          <Select
            label={effectiveTournamentType === 'individual' ? "ظرفیت تورنومنت (تعداد شرکت‌کنندگان)" : (effectiveTournamentType === 'team' ? "ظرفیت تورنومنت (تعداد تیم‌ها)" : "ظرفیت تورنومنت (تعداد اسلات‌ها)")}
            id="targetParticipantCount"
            value={targetParticipantCount}
            onChange={(e) => {
                const newCount = parseInt(e.target.value, 10);
                setTargetParticipantCount(newCount);
                handleGenericInputChange();
            }}
            options={PARTICIPANT_COUNT_OPTIONS.map(count => ({ value: count, label: `${count} ${effectiveTournamentType === 'individual' ? 'نفر' : (effectiveTournamentType === 'team' ? 'تیم' : 'اسلات')}` }))}
            theme={inputThemeProp as any}
            className={`font-semibold ${isSoftUITheme ? '!rounded-xl' : 'rounded-xl'}`}
            disabled={!canEditShellFields}
          />
          
          {showCreateShellButton && ( 
            <Button
                type="submit"
                variant={buttonPrimaryVariant as any}
                size="lg"
                fullWidth
                className={`!py-3.5 !text-lg !mt-8 flex items-center justify-center group ${isSoftUITheme ? '!rounded-xl' : '!rounded-full'}`}
            >
                ایجاد پوسته تورنومنت
                <ArrowRightIcon className="w-5 h-5 rtl:mr-2 ltr:ml-2 rtl:transform rtl:rotate-180 transition-transform duration-200 group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
            </Button>
          )}
        </form>

        {showParticipantEntrySection && currentTournament && (
            <div className="mt-10 pt-8 border-t border-border-cosmicDefault/30">
                <div className="flex justify-between items-center mb-4">
                    <h3 className={`text-xl font-semibold ${isSoftUITheme ? 'text-softUI-textPrimary' : 'text-text-cosmicPrimary'}`}>
                        {currentTournament?.tournamentType === 'individual' ? 'ورود دستی نام شرکت‌کنندگان' : 'ورود دستی تیم‌ها و بازیکنان'}
                    </h3>
                    <Button onClick={handleRandomFill} variant="custom" size="sm" className={`!rounded-lg px-4 py-2 flex items-center group ${randomFillButtonClass}`}>
                        <RefreshIcon className="w-4 h-4 rtl:ml-2 ltr:mr-2"/>
                        پر کردن تصادفی لیست
                    </Button>
                </div>

                {currentTournament?.tournamentType === 'individual' && (
                    <div className="space-y-3">
                        {Array.from({ length: targetParticipantCount }).map((_, index) => (
                            <Input
                                key={`manual-participant-${index}`}
                                label={`نام شرکت‌کننده ${index + 1}`}
                                id={`manual-participant-name-${index}`}
                                type="text"
                                value={manualParticipantNames[index] || ''}
                                onChange={(e) => handleManualParticipantNameChange(index, e.target.value)}
                                placeholder={`نام شرکت‌کننده ${index + 1}`}
                                theme={inputThemeProp}
                                className={isSoftUITheme ? '!rounded-lg' : 'rounded-lg'}
                            />
                        ))}
                    </div>
                )}

                {currentTournament?.tournamentType === 'team' && (
                    <div className="space-y-5">
                    {manualTeamsData.map((team, index) => (
                        <div key={team.id} className={`space-y-3 ${teamInputGroupBg}`}>
                        <p className={`font-medium ${isSoftUITheme ? 'text-softUI-textSecondary' : 'text-text-cosmicSecondary'}`}>تیم {index + 1}</p>
                        <Input
                            label={`نام تیم ${index + 1}`}
                            id={`team-name-${index}`}
                            type="text"
                            value={team.teamName}
                            onChange={(e) => handleManualTeamDetailChange(index, 'teamName', e.target.value)}
                            placeholder={`نام تیم`}
                            theme={inputThemeProp}
                            className={isSoftUITheme ? '!rounded-lg' : 'rounded-lg'}
                        />
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <Input
                            label={`بازیکن ۱ تیم ${index + 1}`}
                            id={`team-${index}-player1`}
                            type="text"
                            value={team.player1Name}
                            onChange={(e) => handleManualTeamDetailChange(index, 'player1Name', e.target.value)}
                            placeholder={`نام بازیکن ۱`}
                            theme={inputThemeProp}
                            className={isSoftUITheme ? '!rounded-lg' : 'rounded-lg'}
                            />
                            <Input
                            label={`بازیکن ۲ تیم ${index + 1}`}
                            id={`team-${index}-player2`}
                            type="text"
                            value={team.player2Name}
                            onChange={(e) => handleManualTeamDetailChange(index, 'player2Name', e.target.value)}
                            placeholder={`نام بازیکن ۲`}
                            theme={inputThemeProp}
                            className={isSoftUITheme ? '!rounded-lg' : 'rounded-lg'}
                            />
                        </div>
                        </div>
                    ))}
                    </div>
                )}
                
                <Button
                    onClick={handleFinalizeAndStart}
                    variant={buttonPrimaryVariant as any}
                    size="lg"
                    fullWidth
                    className={`!py-3.5 !text-lg !mt-8 flex items-center justify-center group ${isSoftUITheme ? '!rounded-xl' : '!rounded-full'}`}
                >
                    نهایی کردن لیست و شروع تورنومنت
                    <ArrowRightIcon className="w-5 h-5 rtl:mr-2 ltr:ml-2 rtl:transform rtl:rotate-180 transition-transform duration-200 group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
                </Button>
            </div>
        )}


        {currentTournament && onDeleteTournamentShell && ( // Show if a tournament exists (even if just a shell)
          <div className="mt-10 pt-6 border-t border-dashed border-border-cosmicDefault/30 text-center">
            <Button
              onClick={handleDeleteShellClick}
              variant="custom"
              size="md"
              className={`!rounded-lg px-6 py-2.5 flex items-center justify-center group ${deleteButtonClass}`}
            >
              <TrashIcon className="w-5 h-5 rtl:ml-2 ltr:mr-2"/>
              {currentTournament.status === 'setup' ? 'حذف پوسته تورنومنت' : 'لغو و بازنشانی تورنومنت'}
            </Button>
          </div>
        )}
      </div>
    </div>
    {isDeleteModalOpen && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => setIsDeleteModalOpen(false)}
          onConfirm={confirmDeleteShell}
          title="تأیید حذف"
          message={
            <p className={isSoftUITheme ? "text-softUI-textSecondary" : "text-text-cosmicSecondary"}>
              آیا از حذف این پوسته تورنومنت و تمامی تنظیمات وارد شده مطمئن هستید؟ 
              <br />
              این عمل غیرقابل بازگشت است.
            </p>
          }
          confirmButtonText="بله، حذف کن"
          cancelButtonText="انصراف"
          theme={isSoftUITheme ? 'softUI' : undefined}
        />
      )}
    </>
  );
};

export default TournamentSetup;
