
import React from 'react';

interface LoadingScreenProps {
  isFadingOut: boolean;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ isFadingOut }) => {
  const imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCCTCiUwC8OiBidjSYQEv7n18u7Xqp72HHMUByFaBVS_u8Ig2JZq45_xUHLBL_v5YROom49hgbIx_GvJTfJ3wkZPA6t4jw4wCPVd8TaUdi-4j40pmelLTadzCXpHDHV9LUbFh5nfIcaux44kpYAIe_EzQO_w5U4ywN7AreJKoiwP_8JjJB7w4V41XzZ15QgYqYNt-h8dV1CJvGVUdwI3NRH4LMmQYgTPGuGq4_bTh-BQNCc8n74gbDUpsTou-V60TN1zQHU6FQB_J8";

  return (
    <div
      className={`fixed inset-0 z-[100] flex size-full min-h-screen flex-col bg-[#101a23] dark justify-between group/design-root overflow-x-hidden animate-overallFadeIn transition-opacity duration-700 ease-in-out ${
        isFadingOut ? 'opacity-0' : 'opacity-100'
      }`}
      style={{ fontFamily: '"Space Grotesk", "Noto Sans", sans-serif' }}
      aria-live="polite"
      aria-busy="true"
      role="status"
    >
      <div></div> {/* Empty div for spacing as in provided HTML */}
      <div>
        <h1 className="text-white tracking-light text-[32px] font-bold leading-tight px-4 text-center pb-3 pt-6">
          AKO
        </h1>
        <h3 className="text-white tracking-light text-2xl font-bold leading-tight px-4 text-center pb-2 pt-5">
          به خونواده آکو خوش اومدین
        </h3>
        <div className="flex w-full grow bg-[#101a23] @container p-4">
          <div className="w-full gap-1 overflow-hidden bg-[#101a23] @[480px]:gap-2 aspect-[3/2] rounded-lg flex">
            <div
              className="w-full bg-center bg-no-repeat bg-cover aspect-auto rounded-none flex-1 animate-loadingImagePulse"
              style={{ backgroundImage: `url("${imageUrl}")` }}
              aria-label="Promotional image for Ako family"
            ></div>
          </div>
        </div>
        <div className="h-5 bg-[#101a23]"></div>
      </div>
      <div></div> 
    </div>
  );
};

export default LoadingScreen;
