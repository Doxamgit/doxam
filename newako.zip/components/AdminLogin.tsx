
import React, { useState } from 'react';
import Button from './Button';
import Input from './Input'; // Assuming Input supports icon prop for softUI
import EyeOpenIcon from './EyeOpenIcon';
import EyeClosedIcon from './EyeClosedIcon';
import LoginUserIcon from './LoginUserIcon'; // New icon for softUI
import LoginPasswordIcon from './LoginPasswordIcon'; // New icon for softUI

interface AdminLoginProps {
  loginUser: (username: string, password: string) => boolean;
  authError: string | null;
  clearAuthError: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ loginUser, authError, clearAuthError }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError(); 
    loginUser(username, password);
    // Navigation will be handled by App.tsx
  };

  return (
    <div className="min-h-[calc(100vh-100px)] flex flex-col items-center justify-center bg-softUI-bgPage p-4 sm:p-6 animate-fadeIn">
      <div 
        className="bg-softUI-card rounded-3xl shadow-soft-ui-card p-8 sm:p-10 md:p-12 w-full max-w-sm text-center"
      >
        <div className="mb-8">
          {/* Logo Placeholder - styled like the image */}
          <div className="mx-auto w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center shadow-md border-4 border-white">
            <span className="text-2xl font-bold text-white transform -skew-x-12">آکو</span>
          </div>
        </div>

        <h2 className="text-3xl font-bold text-softUI-textPrimary mb-2">ورود ادمین آکو</h2>
        <p className="text-softUI-textSecondary mb-8 text-sm">برای مدیریت وارد شوید</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            theme="softUI"
            icon={<LoginUserIcon className="w-5 h-5 text-softUI-inputIcon" />}
            type="text"
            id="admin-username-softui"
            value={username}
            onChange={(e) => { setUsername(e.target.value); clearAuthError(); }}
            placeholder="نام کاربری"
            className="text-sm"
            aria-describedby={authError ? "login-error-softui" : undefined}
          />

          <div className="relative">
            <Input
              theme="softUI"
              icon={<LoginPasswordIcon className="w-5 h-5 text-softUI-inputIcon" />}
              type={showPassword ? "text" : "password"}
              id="admin-password-softui"
              value={password}
              onChange={(e) => { setPassword(e.target.value); clearAuthError(); }}
              placeholder="رمز عبور"
              required
              className="text-sm"
              aria-required="true"
              aria-describedby={authError ? "login-error-softui" : undefined}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute rtl:left-3 ltr:right-3 top-1/2 transform -translate-y-1/2 p-1 text-softUI-inputPlaceholder hover:text-softUI-primary focus:outline-none rounded-full"
              aria-label={showPassword ? "پنهان کردن رمز عبور" : "نمایش رمز عبور"}
            >
              {showPassword ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
            </button>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-between items-center text-xs pt-1 space-y-2 sm:space-y-0">
            <label className="flex items-center text-softUI-textSecondary cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="form-checkbox-softui rtl:ml-2 ltr:mr-2"
              />
              مرا به خاطر بسپار
            </label>
            <Button variant="softUILink" size="sm" className="text-xs p-0">
              فراموشی رمز عبور؟
            </Button>
          </div>
            
          {authError && <p id="login-error-softui" className="text-red-500 bg-red-100 p-2.5 rounded-lg text-xs">{authError}</p>}

          <Button
            type="submit"
            variant="softUIPrimary"
            size="lg"
            fullWidth
            className="!py-3 text-base"
          >
            ورود
          </Button>

          <p className="text-xs text-softUI-textSecondary pt-2">
            حساب کاربری ندارید؟{' '}
            <Button variant="softUILink" size="sm" className="text-xs p-0 font-semibold !text-softUI-primary hover:!underline">
               ثبت نام کنید!
            </Button>
          </p>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
