
import React from 'react';
import { APP_TITLE } from '../constants';

interface FooterProps {
  currentTheme?: 'cosmic' | 'home' | 'versace' | 'softUI' | 'autumnGrays' | 'userPanel' | 'foodieHome';
}

const Footer: React.FC<FooterProps> = ({ currentTheme = 'cosmic' }) => {
  const isSoftUI = currentTheme === 'softUI';
  const isHome = currentTheme === 'home'; // Original dark home
  const isAutumnGrays = currentTheme === 'autumnGrays';
  const isUserPanel = currentTheme === 'userPanel';
  const isFoodieHome = currentTheme === 'foodieHome'; // New light home

  let footerBgClass = 'bg-surface-cosmicPanel/60 border-t border-border-cosmicDefault/60';
  let textColorClass = 'text-text-cosmicSecondary';
  let subTextColorClass = 'opacity-80';

  if (isFoodieHome) {
    footerBgClass = 'bg-foodieTheme-cardBg/70 border-t border-foodieTheme-inputBorder/70 backdrop-blur-sm';
    textColorClass = 'text-foodieTheme-textSecondary';
    subTextColorClass = 'opacity-75';
  } else if (isSoftUI) {
    footerBgClass = 'bg-softUI-inputBg border-t border-softUI-inputBorder';
    textColorClass = 'text-softUI-textSecondary';
    subTextColorClass = 'opacity-70';
  } else if (isHome) {
    footerBgClass = 'bg-brand-home-bg/80 border-t border-brand-home-cardBorder/30 backdrop-blur-sm';
    textColorClass = 'text-brand-home-textSecondary';
    subTextColorClass = 'opacity-75';
  } else if (isAutumnGrays) {
    footerBgClass = 'bg-autumnGrays-bgPage/80 border-t border-autumnGrays-border/50 backdrop-blur-sm';
    textColorClass = 'text-autumnGrays-textSecondary';
    subTextColorClass = 'opacity-75';
  } else if (isUserPanel) {
    footerBgClass = 'bg-userPanel-bgGradientTo/80 border-t border-userPanel-iconContainerBg/30 backdrop-blur-sm';
    textColorClass = 'text-userPanel-textSecondary';
    subTextColorClass = 'opacity-75';
  }
  // Default Cosmic styles are applied if none of the above conditions are met.


  return (
    <footer className={`${footerBgClass} ${textColorClass} p-6 text-center mt-auto`}>
      <p>&copy; {new Date().getFullYear()} {APP_TITLE}. تمامی حقوق محفوظ است.</p>
      <p className={`text-xs mt-1 ${subTextColorClass}`}>با شور و اشتیاق برای علاقه‌مندان به تورنومنت ساخته شده است.</p>
    </footer>
  );
};

export default Footer;
