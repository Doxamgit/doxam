
import React, { useState, useEffect } from 'react';
import type { BannedUser } from '../types';
import Button from './Button';
import Input from './Input';
import TrashIcon from './TrashIcon';
import BanIcon from './BanIcon';
import ConfirmationModal from './ConfirmationModal';

interface AdminBanListPanelProps {
  bannedUsers: BannedUser[];
  onAddBannedUser: (platoUsername: string, adminUsername?: string, reason?: string) => boolean;
  onRemoveBannedUser: (platoUsername: string) => boolean;
  banListError: string | null;
  clearBanListError: () => void;
  onClose?: () => void;
  currentAdminUsername?: string; 
  currentTheme?: 'softUI';
}

const AdminBanListPanel: React.FC<AdminBanListPanelProps> = ({
  bannedUsers,
  onAddBannedUser,
  onRemoveBannedUser,
  banListError,
  clearBanListError,
  onClose,
  currentAdminUsername,
  currentTheme = 'softUI'
}) => {
  const [platoUsernameInput, setPlatoUsernameInput] = useState('');
  const [reasonInput, setReasonInput] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [userToRemove, setUserToRemove] = useState<BannedUser | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  useEffect(() => {
    if (banListError) {
      setLocalError(banListError);
    }
  }, [banListError]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    clearBanListError();
    setLocalError(null);
    setSuccessMessage(null);
    if (!platoUsernameInput.trim()) {
      setLocalError("نام کاربری پلاتو برای مسدود کردن نمی‌تواند خالی باشد.");
      return;
    }
    const success = onAddBannedUser(platoUsernameInput, currentAdminUsername, reasonInput);
    if (success) {
      setPlatoUsernameInput('');
      setReasonInput('');
      setSuccessMessage("کاربر با موفقیت به لیست مسدودی اضافه شد.");
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };
  
  const handleDeleteRequest = (user: BannedUser) => {
    setUserToRemove(user);
    setIsDeleteModalOpen(true);
  };

  const confirmRemoveUser = () => {
    if (userToRemove) {
      clearBanListError();
      setLocalError(null);
      onRemoveBannedUser(userToRemove.platoUsername);
    }
    setIsDeleteModalOpen(false);
    setUserToRemove(null);
  };


  const panelClasses = "bg-softUI-card rounded-xl shadow-soft-ui-card border border-softUI-inputBorder";
  const titleTextClass = "text-softUI-textPrimary";
  const titleIconClass = "text-softUI-primary";
  const inputTheme = "softUI";
  const formBgClass = "bg-softUI-bgPage rounded-lg border border-softUI-inputBorder";
  const sectionTitleClass = "text-softUI-textPrimary";
  const itemBgClass = "bg-softUI-bgPage rounded-lg shadow-sm border border-softUI-inputBorder";
  const itemTextClass = "text-softUI-textSecondary";
  const itemStrongTextClass = "text-softUI-textPrimary font-semibold";
  const buttonPrimaryVariant = "softUIPrimary";
  const buttonSecondaryVariant = "custom";
  const softUIButtonSecondaryClass = "!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder";
  const errorTextClass = "text-red-600";
  const errorBgClass = "bg-red-100 border-red-300";
  const successTextClass = "text-green-600";
  const successBgClass = "bg-green-100 border-green-300";
  const textareaClass = "block w-full px-4 py-2.5 bg-softUI-inputBg border border-softUI-inputBorder rounded-xl shadow-sm placeholder-softUI-inputPlaceholder focus:outline-none focus:ring-2 focus:ring-softUIFocus focus:border-softUIFocus sm:text-sm text-softUI-textPrimary font-medium transition-colors duration-150";
  const labelClass = "text-softUI-textSecondary";


  return (
    <>
      <div className={`max-w-2xl mx-auto p-6 md:p-8 animate-fadeIn ${panelClasses}`}>
        <div className="flex justify-between items-center mb-8">
          <h2 className={`text-2xl sm:text-3xl font-bold flex items-center ${titleTextClass}`}>
            <BanIcon className={`w-7 h-7 sm:w-8 sm:h-8 rtl:ml-3 ltr:mr-3 ${titleIconClass}`} />
            مدیریت لیست کاربران مسدود
          </h2>
          {onClose && 
              <Button onClick={onClose} variant={buttonSecondaryVariant as any} size="sm" className={`!rounded-lg ${softUIButtonSecondaryClass}`}>
                  بازگشت
              </Button>
          }
        </div>

        {localError && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${errorTextClass} ${errorBgClass}`}>{localError}</p>}
        {successMessage && <p className={`p-3 rounded-lg mb-4 text-sm text-center ${successTextClass} ${successBgClass}`}>{successMessage}</p>}

        <form onSubmit={handleAddSubmit} className={`space-y-5 mb-10 p-6 ${formBgClass}`}>
          <h3 className={`text-xl font-semibold ${sectionTitleClass} mb-4`}>افزودن کاربر به لیست مسدودی</h3>
          <Input
            label="نام کاربری پلاتو"
            id="ban-plato-username"
            value={platoUsernameInput}
            onChange={(e) => setPlatoUsernameInput(e.target.value)}
            placeholder="نام کاربری پلاتو برای مسدود کردن"
            required
            theme={inputTheme}
            className="font-semibold"
          />
           <div>
            <label htmlFor="ban-reason" className={`block text-sm font-medium mb-1.5 ${labelClass}`}>
              دلیل مسدودیت (اختیاری)
            </label>
            <textarea
              id="ban-reason"
              value={reasonInput}
              onChange={(e) => setReasonInput(e.target.value)}
              placeholder="توضیحی مختصر در مورد دلیل مسدودیت..."
              rows={3}
              className={textareaClass}
            />
          </div>
          <Button type="submit" variant={buttonPrimaryVariant as any} size="md" className="!rounded-lg">
            افزودن به لیست مسدودی
          </Button>
        </form>

        <h3 className={`text-xl sm:text-2xl font-semibold ${sectionTitleClass} mb-6 mt-8 pt-6 border-t border-softUI-inputBorder`}>
          لیست کاربران مسدود شده
        </h3>
        {bannedUsers.length === 0 ? (
          <p className={`${itemTextClass} text-center py-4`}>در حال حاضر کاربری در لیست مسدودی وجود ندارد.</p>
        ) : (
          <div className={`space-y-3 max-h-[50vh] overflow-y-auto pr-2 soft-ui-theme-active`}>
            {bannedUsers.map(user => (
              <div key={user.platoUsername} className={`p-3 sm:p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 ${itemBgClass}`}>
                <div className="flex-grow">
                  <p className={`${itemStrongTextClass} text-md`}>{user.platoUsername}</p>
                  <p className={`${itemTextClass} text-xs mt-0.5`}>
                    مسدود شده در: {new Date(user.timestamp).toLocaleString('fa-IR')}
                    {user.bannedBy && <span> (توسط: {user.bannedBy})</span>}
                  </p>
                   {user.reason && <p className={`${itemTextClass} text-xs mt-1 italic`}>دلیل: {user.reason}</p>}
                </div>
                <Button 
                    onClick={() => handleDeleteRequest(user)} 
                    variant="custom" 
                    size="sm" 
                    aria-label={`حذف ${user.platoUsername} از لیست مسدودی`}
                    className={`!p-2 !rounded-md !bg-red-100 !text-red-600 hover:!bg-red-200 !border-red-300 shrink-0 mt-2 sm:mt-0`}
                >
                  <TrashIcon className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
      {userToRemove && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setUserToRemove(null);
          }}
          onConfirm={confirmRemoveUser}
          title="تأیید حذف از لیست مسدودی"
          message={
            <p>
              آیا از حذف کاربر <strong className="text-softUI-primary">{userToRemove.platoUsername}</strong> از لیست مسدودی مطمئن هستید؟
            </p>
          }
          theme="softUI"
        />
      )}
    </>
  );
};

export default AdminBanListPanel;
