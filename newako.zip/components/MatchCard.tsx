
import React from 'react';
import type { Match, Participant, Player } from '../types';
import CrownIcon from './CrownIcon';
import UsersGroupIcon from './UsersGroupIcon'; // For team icon

interface ParticipantDisplayProps {
  participant: Participant | null;
  isWinner: boolean;
  canSelect: boolean;
  onClick?: () => void;
  isPlaceholder?: boolean;
  currentTheme: 'default' | 'versace' | 'softUI' | 'userPanel';
}

interface MatchCardProps {
  match: Match;
  isAdmin: boolean;
  onSelectWinner?: (winner: Participant) => void;
  isCompletedTournament?: boolean;
  currentTheme?: 'default' | 'versace' | 'softUI' | 'userPanel';
}

const ParticipantDisplay: React.FC<ParticipantDisplayProps> = ({ 
  participant, 
  isWinner, 
  canSelect, 
  onClick, 
  isPlaceholder, 
  currentTheme 
}) => {
  
  const isVersaceTheme = currentTheme === 'versace';
  const isSoftUITheme = currentTheme === 'softUI';
  const isUserPanelTheme = currentTheme === 'userPanel';
  let baseClasses = `p-3 transition-all duration-200 ease-in-out flex flex-col items-start justify-center text-sm min-h-[52px] shadow-sm border interactive-tap w-full`; // text-right for main name
  let winnerTextColor = ''; 
  let teamNameClass = 'font-semibold';
  let teamMemberClass = 'text-xs opacity-80 mt-0.5';

  const isTeam = participant && participant.members && participant.members.length > 0;

  if (isSoftUITheme) {
    baseClasses += " rounded-lg"; 
    teamNameClass += " text-softUI-textPrimary";
    teamMemberClass += " text-softUI-textSecondary";
    if (isPlaceholder) {
      baseClasses += " bg-softUI-inputBg border-softUI-inputBorder text-softUI-textSecondary italic items-center"; 
    } else if (canSelect && participant) {
      baseClasses += " cursor-pointer bg-softUI-card border-softUI-inputBorder hover:border-softUI-primary hover:bg-blue-50";
    } else {
      baseClasses += " bg-softUI-card border-softUI-inputBorder"; 
    }
    if (isWinner) {
      baseClasses = `p-3 rounded-lg transition-all duration-200 ease-in-out flex flex-col items-start justify-center text-sm min-h-[52px] shadow-md bg-softUI-primary border-softUI-primary text-softUI-textOnPrimary font-semibold interactive-tap w-full`;
      winnerTextColor = 'text-softUI-textOnPrimary';
      teamNameClass = "font-semibold text-softUI-textOnPrimary"; // Override for winner
      teamMemberClass = "text-xs text-softUI-textOnPrimary opacity-90 mt-0.5"; // Override for winner
    }
  } else if (isVersaceTheme) {
    baseClasses += " rounded-md"; 
    teamNameClass += " text-versaceTheme-white";
    teamMemberClass += " text-versaceTheme-gray";
    if (isPlaceholder) {
      baseClasses += " bg-versaceTheme-black border-versaceTheme-gray/50 text-versaceTheme-gray italic items-center"; 
    } else if (canSelect && participant) {
      baseClasses += " cursor-pointer bg-versaceTheme-black border-versaceTheme-gray hover:border-versaceTheme-white hover:bg-versaceTheme-gray/10";
    } else {
      baseClasses += " bg-versaceTheme-black border-versaceTheme-gray"; 
    }
    if (isWinner) {
      baseClasses = `p-3 rounded-md transition-all duration-200 ease-in-out flex flex-col items-start justify-center text-sm min-h-[52px] shadow-md bg-versaceTheme-white border-versaceTheme-white text-versaceTheme-black font-semibold interactive-tap w-full`;
      winnerTextColor = 'text-versaceTheme-black';
      teamNameClass = "font-semibold text-versaceTheme-black";
      teamMemberClass = "text-xs text-versaceTheme-black opacity-90 mt-0.5";
    }
  } else if (isUserPanelTheme) {
    baseClasses += " rounded-lg";
    teamNameClass += " text-userPanel-textPrimary";
    teamMemberClass += " text-userPanel-textSecondary";
    if (isPlaceholder) {
        baseClasses += " bg-userPanel-cardBg/70 border-userPanel-iconContainerBg/30 text-userPanel-textSecondary italic items-center";
    } else if (canSelect && participant) {
        baseClasses += " cursor-pointer bg-userPanel-cardBg border-userPanel-iconContainerBg/50 hover:border-userPanel-iconContainerBg hover:bg-userPanel-cardHoverBg";
    } else {
        baseClasses += " bg-userPanel-cardBg border-userPanel-iconContainerBg/50";
    }
    if (isWinner) {
        baseClasses = `p-3 rounded-lg transition-all duration-200 ease-in-out flex flex-col items-start justify-center text-sm min-h-[52px] shadow-lg bg-userPanel-iconContainerBg border-userPanel-iconContainerBg text-userPanel-iconColor font-semibold interactive-tap w-full`;
        winnerTextColor = 'text-userPanel-iconColor';
        teamNameClass = "font-semibold text-userPanel-iconColor";
        teamMemberClass = "text-xs text-userPanel-iconColor opacity-90 mt-0.5";
    }
  }
  else { // Cosmic Theme (Default)
    baseClasses += " rounded-lg";
    teamNameClass += " text-text-cosmicPrimary";
    teamMemberClass += " text-text-cosmicPlaceholder";
    if (isPlaceholder) {
      baseClasses += " bg-surface-cosmicInput border-border-cosmicDefault/50 text-text-cosmicPlaceholder italic items-center"; 
    } else if (canSelect && participant) {
      baseClasses += " cursor-pointer bg-surface-cosmicInput border-border-cosmicDefault hover:border-brand-cosmicAccentOrange hover:bg-brand-cosmicAccentOrange/10";
    } else {
      baseClasses += " bg-surface-cosmicInput border-border-cosmicDefault"; 
    }
    if (isWinner) {
      baseClasses = `p-3 rounded-lg transition-all duration-200 ease-in-out flex flex-col items-start justify-center text-sm min-h-[52px] shadow-lg bg-brand-cosmicAccentOrange border-brand-cosmicAccentOrange text-text-cosmicOnAccent font-semibold interactive-tap w-full`;
      winnerTextColor = 'text-yellow-300'; 
      teamNameClass = "font-semibold text-text-cosmicOnAccent";
      teamMemberClass = "text-xs text-text-cosmicOnAccent opacity-90 mt-0.5";
    }
  }

  const mainName = participant ? participant.name : (isPlaceholder ? 'برنده از مسابقه قبلی' : 'نامشخص');
  const memberNames = isTeam ? participant.members?.map(m => m.name).join(' و ') : null;

  return (
    <div 
      className={baseClasses} 
      onClick={participant && canSelect ? onClick : undefined} 
      role={canSelect && participant ? "button" : undefined} 
      tabIndex={canSelect && participant ? 0 : undefined} 
      onKeyDown={ (e) => { if (e.key === 'Enter' || e.key === ' ') { onClick?.(); } }}
      aria-label={participant ? `${isTeam ? 'تیم: ' : 'شرکت‌کننده: '}${participant.name}${memberNames ? ` (بازیکنان: ${memberNames})` : ''}${isWinner ? ', برنده' : ''}${canSelect ? ', برای انتخاب کلیک کنید' : ''}` : (isPlaceholder ? 'جایگاه برای برنده مسابقه قبلی' : 'شرکت‌کننده نامشخص')}
    >
      <div className="w-full flex justify-between items-center">
        <span className={`truncate pr-1 ${teamNameClass}`}>{mainName}</span>
        {isWinner && <CrownIcon className={`${winnerTextColor} rtl:ml-0 ltr:mr-0 animate-popIn w-4 h-4 shrink-0`} />}
      </div>
      {isTeam && memberNames && (
        <span className={`block w-full truncate pr-1 ${teamMemberClass}`}>{memberNames}</span>
      )}
      {isTeam && !isWinner && <UsersGroupIcon className={`w-3 h-3 absolute top-1 right-1 rtl:left-1 rtl:right-auto opacity-50 ${isSoftUITheme ? 'text-softUI-textSecondary' : 'text-text-cosmicSecondary'}`} />}
    </div>
  );
};


const MatchCard: React.FC<MatchCardProps> = ({ match, isAdmin, onSelectWinner, isCompletedTournament, currentTheme = 'default' }) => {
  const { participant1, participant2, winner } = match;
  const isVersaceTheme = currentTheme === 'versace';
  const isSoftUITheme = currentTheme === 'softUI';
  const isUserPanelTheme = currentTheme === 'userPanel';

  const handleSelect = (selectedParticipant: Participant | null) => {
    if (isAdmin && onSelectWinner && selectedParticipant && !isCompletedTournament && !match.winner) { 
      onSelectWinner(selectedParticipant);
    }
  };
  
  let cardBaseClass = `p-3.5 space-y-2.5 w-64 border animate-fadeIn`;
  let vsTextClass = '';

  if (isSoftUITheme) {
    cardBaseClass += ` bg-softUI-card rounded-xl shadow-soft-ui-card border-softUI-inputBorder`;
    vsTextClass = 'text-softUI-textSecondary';
  } else if (isVersaceTheme) {
    cardBaseClass += ` bg-versaceTheme-panelBg rounded-md shadow-lg border-versaceTheme-gray/70`;
    vsTextClass = 'text-versaceTheme-gray';
  } else if (isUserPanelTheme) {
    cardBaseClass += ` bg-userPanel-expandedContentBg rounded-xl shadow-lg border-userPanel-iconContainerBg/60`;
    vsTextClass = 'text-userPanel-textSecondary';
  }
  else { // Cosmic
    cardBaseClass += ` bg-surface-cosmicPanel rounded-xl shadow-lg border-border-cosmicDefault/70`;
    vsTextClass = 'text-text-cosmicSecondary';
  }
  

  if(match.isPlaceholder) {
    return (
      <div className={cardBaseClass}>
        <ParticipantDisplay participant={null} isWinner={false} canSelect={false} isPlaceholder={true} currentTheme={currentTheme} />
        <div className={`text-center text-xs py-1 ${vsTextClass}`}>مقابل</div>
        <ParticipantDisplay participant={null} isWinner={false} canSelect={false} isPlaceholder={true} currentTheme={currentTheme} />
      </div>
    );
  }

  const canSelectWinner = isAdmin && !isCompletedTournament;

  return (
    <div className={cardBaseClass}>
      <ParticipantDisplay
        participant={participant1}
        isWinner={!!winner && winner.id === participant1?.id}
        canSelect={canSelectWinner && !!participant1}
        onClick={() => participant1 && handleSelect(participant1)}
        currentTheme={currentTheme}
      />
      <div className={`text-center text-xs py-1 ${vsTextClass}`}>مقابل</div>
      <ParticipantDisplay
        participant={participant2}
        isWinner={!!winner && winner.id === participant2?.id}
        canSelect={canSelectWinner && !!participant2}
        onClick={() => participant2 && handleSelect(participant2)}
        currentTheme={currentTheme}
      />
    </div>
  );
};

export default MatchCard;
