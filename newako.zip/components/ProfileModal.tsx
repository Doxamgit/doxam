
import React, { useEffect, ReactNode } from 'react';
import Button from './Button';
import XMarkIcon from './XMarkIcon';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, title, children }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden'; // Prevent background scroll
      document.addEventListener('keydown', handleEsc);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm
                  transition-opacity duration-300 ease-out ${isOpen ? 'opacity-100 visible modal-overlay-shown' : 'opacity-0 invisible'}`}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="profile-modal-title"
    >
      <div
        className={`bg-userPanel-cardBg rounded-xl shadow-2xl w-full max-w-lg transform transition-all duration-300 ease-out
                    max-h-[90vh] flex flex-col border border-userPanel-iconContainerBg/50
                    ${isOpen ? 'animate-modal-enter modal-content-shown' : 'animate-modal-leave'}`}
        onClick={(e) => e.stopPropagation()} 
      >
        <div className="flex justify-between items-center p-4 sm:p-5 border-b border-userPanel-iconContainerBg/30">
          <h2 id="profile-modal-title" className="text-xl sm:text-2xl font-bold text-userPanel-textPrimary">
            {title}
          </h2>
          <Button
            onClick={onClose}
            variant="custom"
            className="p-1.5 rounded-full hover:bg-userPanel-iconContainerBg/20 focus:outline-none focus:ring-2 focus:ring-userPanel-iconContainerBg focus:ring-offset-2 focus:ring-offset-userPanel-cardBg"
            aria-label="بستن پنجره"
          >
            <XMarkIcon className="w-5 h-5 text-userPanel-textPrimary" />
          </Button>
        </div>

        <div className="overflow-y-auto p-4 sm:p-6">
          <div className="bg-userPanel-expandedContentBg p-4 sm:p-6 rounded-lg">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;
