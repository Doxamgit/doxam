
import React, { useEffect, useState } from 'react';
import Button from './Button';
import XMarkIcon from './XMarkIcon';
import ShieldCheckIcon from './ShieldCheckIcon'; 
import ClipboardCopyIcon from './ClipboardCopyIcon'; // Import new icon

interface UserCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCode: string;
}

const UserCodeModal: React.FC<UserCodeModalProps> = ({ isOpen, onClose, userCode }) => {
  const [copySuccessMessage, setCopySuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden'; 
      document.addEventListener('keydown', handleEsc);
    } else {
      document.body.style.overflow = '';
      setCopySuccessMessage(null); // Reset copy message when modal closes
    }
    return () => {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(userCode);
      setCopySuccessMessage('کد کپی شد!');
      setTimeout(() => setCopySuccessMessage(null), 2000); // Hide message after 2 seconds
    } catch (err) {
      console.error('Failed to copy code: ', err);
      setCopySuccessMessage('خطا در کپی کردن کد.');
      setTimeout(() => setCopySuccessMessage(null), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md
                  transition-opacity duration-300 ease-out ${isOpen ? 'opacity-100 visible modal-overlay-shown' : 'opacity-0 invisible'}`}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="user-code-modal-title"
    >
      <div
        className={`bg-userPanel-cardBg rounded-xl shadow-2xl w-full max-w-md transform transition-all duration-300 ease-out
                    max-h-[90vh] flex flex-col border-2 border-userPanel-iconContainerBg
                    ${isOpen ? 'animate-modal-enter modal-content-shown' : 'animate-modal-leave'}`}
        onClick={(e) => e.stopPropagation()} 
      >
        <div className="flex justify-between items-center p-4 sm:p-5 border-b border-userPanel-iconContainerBg/40">
          <h2 id="user-code-modal-title" className="text-xl sm:text-2xl font-bold text-userPanel-textPrimary flex items-center">
            <ShieldCheckIcon className="w-7 h-7 rtl:ml-2 ltr:mr-2 text-userPanel-iconContainerBg" />
            کد شناسایی شما
          </h2>
          <Button
            onClick={onClose}
            variant="custom"
            className="p-1.5 rounded-full hover:bg-userPanel-iconContainerBg/20 focus:outline-none focus:ring-2 focus:ring-userPanel-iconContainerBg focus:ring-offset-2 focus:ring-offset-userPanel-cardBg"
            aria-label="بستن پنجره"
          >
            <XMarkIcon className="w-5 h-5 text-userPanel-textPrimary" />
          </Button>
        </div>

        <div className="overflow-y-auto p-5 sm:p-6 text-center">
          <p className="text-userPanel-textSecondary text-sm sm:text-base mb-4">
            کاربر محترم، این کد شناسایی منحصر به فرد شماست.
          </p>
          <div className="relative flex items-center justify-center my-5">
            <div 
              className="text-4xl sm:text-5xl font-mono font-bold text-userPanel-iconContainerBg bg-userPanel-expandedContentBg p-4 rounded-lg tracking-widest border border-userPanel-iconContainerBg/50 select-all"
              aria-describedby="user-code-instructions"
            >
              {userCode}
            </div>
            <Button
              onClick={handleCopyCode}
              variant="custom"
              className="p-2 rounded-full bg-userPanel-iconContainerBg/20 hover:bg-userPanel-iconContainerBg/40 text-userPanel-textPrimary focus:outline-none focus:ring-2 focus:ring-userPanel-iconContainerBg focus:ring-offset-2 focus:ring-offset-userPanel-expandedContentBg absolute rtl:left-[-8px] ltr:right-[-8px] top-1/2 transform -translate-y-1/2"
              aria-label="کپی کردن کد"
              title="کپی کردن کد"
            >
              <ClipboardCopyIcon className="w-5 h-5" />
            </Button>
          </div>
          {copySuccessMessage && (
            <p className={`text-xs mb-3 ${copySuccessMessage.includes('خطا') ? 'text-red-400' : 'text-green-400'}`}>
              {copySuccessMessage}
            </p>
          )}
          <p id="user-code-instructions" className="text-userPanel-textSecondary text-sm sm:text-base leading-relaxed mb-6">
            لطفاً از این کد اسکرین شات بگیرید و آن را در مکانی امن نگهداری کنید. 
            <br />
            در مراجعات بعدی به این کد نیاز خواهید داشت.
          </p>
          
          <Button
            onClick={onClose}
            variant="custom"
            size="lg"
            className="!bg-userPanel-iconContainerBg !text-userPanel-iconColor hover:!opacity-90 !rounded-full w-full sm:w-auto px-8 py-2.5"
          >
            متوجه شدم
          </Button>
        </div>
      </div>
    </div>
  );
};

// Placeholder ShieldCheckIcon - This was already in the file, kept for completeness
const ShieldCheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622A11.99 11.99 0 0018.402 6a11.959 11.959 0 01-1.035-3.036m-4.123 1.21A2.25 2.25 0 0010.5 4.525h3A2.25 2.25 0 0014.658 5.711" />
  </svg>
);

export default UserCodeModal;
