import React, { useEffect } from 'react';
import Button from './Button';
import XMarkIcon from './XMarkIcon'; // Assuming you have this or a similar icon

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: React.ReactNode; // Allow JSX for message (e.g., bolding item name)
  confirmButtonText?: string;
  cancelButtonText?: string;
  theme?: 'softUI'; // For now, defaults to softUI styling
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmButtonText = "تأیید حذف",
  cancelButtonText = "انصراف",
  theme = 'softUI'
}) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      document.addEventListener('keydown', handleEsc);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // SoftUI specific styling
  const modalOverlayClass = "bg-softUI-modalOverlay backdrop-blur-sm";
  const modalContentClass = "bg-softUI-card rounded-xl shadow-xl border border-softUI-inputBorder";
  const titleTextClass = "text-softUI-textPrimary";
  const messageTextClass = "text-softUI-textSecondary";
  const closeButtonHoverBg = "hover:bg-softUI-inputBg";
  const confirmButtonVariant = "custom"; // Use custom to apply specific softUI danger styles
  const confirmButtonCustomClass = "!bg-red-500 hover:!bg-red-600 !text-white !border-red-500";
  const cancelButtonVariant = "custom"; // Use custom for softUI secondary
  const cancelButtonCustomClass = "!bg-softUI-inputBg !text-softUI-textPrimary !border-softUI-inputBorder hover:!bg-softUI-inputBorder";


  return (
    <div
      className={`fixed inset-0 z-[80] flex items-center justify-center p-4 
                  transition-opacity duration-300 ease-out ${modalOverlayClass} 
                  ${isOpen ? 'opacity-100 visible modal-overlay-shown' : 'opacity-0 invisible'}`}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirmation-modal-title"
    >
      <div
        className={`w-full max-w-md transform transition-all duration-300 ease-out ${modalContentClass}
                    ${isOpen ? 'animate-modal-enter modal-content-shown' : 'animate-modal-leave'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-5 border-b border-softUI-inputBorder">
          <h2 id="confirmation-modal-title" className={`text-xl font-semibold ${titleTextClass}`}>
            {title}
          </h2>
          <Button
            onClick={onClose}
            variant="custom"
            className={`p-1.5 rounded-full ${closeButtonHoverBg} focus:outline-none focus:ring-2 focus:ring-softUI-primary focus:ring-offset-2 focus:ring-offset-softUI-card`}
            aria-label="بستن"
          >
            <XMarkIcon className="w-5 h-5 text-softUI-textSecondary" />
          </Button>
        </div>

        <div className="p-6">
          <div className={`text-sm ${messageTextClass} mb-6 leading-relaxed`}>{message}</div>
          <div className="flex justify-end space-x-3 rtl:space-x-reverse">
            <Button
              onClick={onConfirm}
              variant={confirmButtonVariant as any}
              className={`!rounded-lg ${confirmButtonCustomClass}`}
              size="md"
            >
              {confirmButtonText}
            </Button>
            <Button
              onClick={onClose}
              variant={cancelButtonVariant as any}
              className={`!rounded-lg ${cancelButtonCustomClass}`}
              size="md"
            >
              {cancelButtonText}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
