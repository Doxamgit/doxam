
import React from 'react';
import FilledStarIcon from './FilledStarIcon';
import EmptyStarIcon from './EmptyStarIcon';

interface StarRatingInputProps {
  rating: number;
  setRating: (rating: number) => void;
  maxStars?: number;
  label?: string;
  starSize?: string;
  theme?: 'default' | 'softUI' | 'autumnGrays' | 'userPanelInput';
}

const StarRatingInput: React.FC<StarRatingInputProps> = ({
  rating,
  setRating,
  maxStars = 5,
  label,
  starSize = "w-7 h-7",
  theme = 'default'
}) => {
  const isSoftUI = theme === 'softUI';
  const isAutumnGrays = theme === 'autumnGrays';
  const isUserPanelInput = theme === 'userPanelInput';

  let labelColorClass = 'text-text-cosmicSecondary';
  let clearButtonColorClass = 'text-text-cosmicSecondary hover:text-brand-cosmicAccentOrange';
  let starActiveColor = 'text-yellow-400'; 
  let starInactiveColor = 'text-gray-400 hover:text-yellow-500';

  if (isSoftUI) {
    labelColorClass = 'text-softUI-textSecondary';
    clearButtonColorClass = 'text-softUI-textSecondary hover:text-softUI-primary';
    starActiveColor = 'text-yellow-500';
    starInactiveColor = 'text-gray-300 hover:text-yellow-400';
  } else if (isAutumnGrays) {
    labelColorClass = 'text-autumnGrays-textSecondary';
    clearButtonColorClass = 'text-autumnGrays-textSecondary hover:text-autumnGrays-textPrimary';
    starActiveColor = 'text-autumnGrays-textPrimary';
    starInactiveColor = 'text-autumnGrays-border hover:text-autumnGrays-textPrimary/70';
  } else if (isUserPanelInput) {
    labelColorClass = 'text-userPanel-textSecondary';
    clearButtonColorClass = 'text-userPanel-textSecondary hover:text-userPanel-textPrimary';
    starActiveColor = 'text-userPanel-iconContainerBg'; // Bright blue for active
    starInactiveColor = 'text-userPanel-textSecondary/50 hover:text-userPanel-iconContainerBg/70'; // Dimmer for inactive
  }


  return (
    <div>
      {label && <label className={`block text-sm font-medium mb-1.5 ${labelColorClass}`}>{label}</label>}
      <div className="flex items-center space-x-1 rtl:space-x-reverse">
        {[...Array(maxStars)].map((_, index) => {
          const starValue = index + 1;
          return (
            <button
              type="button"
              key={starValue}
              onClick={() => setRating(starValue)}
              className={`focus:outline-none transition-transform duration-150 ease-in-out hover:scale-110 ${starValue <= rating ? starActiveColor : starInactiveColor}`}
              aria-label={`امتیاز ${starValue} از ${maxStars}`}
            >
              {starValue <= rating ? (
                <FilledStarIcon className={starSize} />
              ) : (
                <EmptyStarIcon className={starSize} />
              )}
            </button>
          );
        })}
         {rating > 0 && (
            <button
                type="button"
                onClick={() => setRating(0)} 
                className={`ml-2 rtl:mr-2 text-xs focus:outline-none ${clearButtonColorClass}`}
                aria-label="پاک کردن امتیاز"
            >
                (پاک کردن)
            </button>
        )}
      </div>
    </div>
  );
};

export default StarRatingInput;
