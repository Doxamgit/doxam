
import React from 'react';

const ScaleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0012 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52l2.286-1.046a.75.75 0 00-.214-1.411l-2.286-.042a.75.75 0 00-.732.732v1.046A48.416 48.416 0 0018.75 4.97M5.25 4.97A48.416 48.416 0 0112 4.5c2.291 0 4.545.16 6.75.47m-13.5 0c-1.01.143-2.01.317-3 .52m3-.52l-2.286-1.046a.75.75 0 01.214-1.411l2.286-.042a.75.75 0 01.732.732v1.046A48.416 48.416 0 015.25 4.97m13.5 0v13.5" />
  </svg>
);

export default ScaleIcon;
