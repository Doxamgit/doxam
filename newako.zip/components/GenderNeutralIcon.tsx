import React from 'react';

const GenderNeutralIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path 
      fillRule="evenodd" 
      d="M12 2.25c-2.485 0-4.5 2.015-4.5 4.5s2.015 4.5 4.5 4.5 4.5-2.015 4.5-4.5S14.485 2.25 12 2.25zM8.25 15.75a3.75 3.75 0 00-3.75 3.75v.75h15v-.75a3.75 3.75 0 00-3.75-3.75h-7.5z" 
      clipRule="evenodd" 
    />
  </svg>
);

export default GenderNeutralIcon;